import java.io.*;

public class SortScore {

	public static void main(String[] args) {
		//String encoding = "GBK";
		//����ɼ���
		File input = new File("Score.html");
		MainOutPut MyGrade = new MainOutPut();
		MyGrade.processScoreTable(input);
	}
}


