import java.io.*;

import org.jsoup.*;
import org.jsoup.nodes.*;
import org.jsoup.select.Elements;

public class MainOutPut {
	private String[][] data = null;
	String FileName = null;
	String encoding = "gb2312";
	float totalCredit = 0;
	public void processScoreTable(File input){
		String FileName = input.getName();
		ReadHtml(FileName);
		SortScore();
		WriteTxt("SortedScore.txt");
	}
	
	//�����Ȩƽ����
	private float CalcWeightedAverageMark(){
		float WeightedAverageMark = 0;
		float totalCredit = 0;
		float sum = 0;
		for(int i = 1;i<data.length;i++){
			if(data[i][9].equals("")){
				continue;
			}
			sum += Float.parseFloat(data[i][9]) * Float.parseFloat(data[i][3]);
			totalCredit += Float.parseFloat(data[i][3]);
		}
		if(totalCredit != 0){
			WeightedAverageMark = sum / totalCredit;
		}
		return WeightedAverageMark;
		
	}
	
	//����GPA
	private float CalcGPA(){
		float GPA = 0;
		float totalCredit = 0;
		float sum = 0;
		for(int i = 1;i<data.length;i++){
			if(data[i][9].equals("")){
				continue;
			}
			float tempGrade = Float.parseFloat(data[i][9]);
			float tempScore = 0;
			if(tempGrade >= 90){
				tempScore = 4.0f;
			}else if(tempGrade >= 85){
				tempScore = 3.7f;
			}else if(tempGrade >= 82){
				tempScore = 3.3f;
			}else if(tempGrade >= 78){
				tempScore = 3.0f;
			}else if(tempGrade >=75){
				tempScore = 2.7f;
			}else if(tempGrade >= 72){
				tempScore = 2.3f;
			}else if(tempGrade >=68){
				tempScore = 2.0f;
			}else if(tempGrade >=64){
				tempScore = 1.5f;
			}else if(tempGrade >= 60){
				tempScore = 1.0f;
			}else{
				tempScore = 0f;
			}
			sum += tempScore * Float.parseFloat(data[i][3]);
			totalCredit += Float.parseFloat(data[i][3]);			
		}
		if(totalCredit != 0){
			GPA = sum/totalCredit;
		}
		return GPA;
	}
	
	//���ɼ�����
	private void SortScore(){
		for(int i=data.length-1; i > 0; i--){
			for(int j=i; j>1; j--){
				float latterNum = 0;
				float formerNum = 0;
				if(!data[j][9].equals("")){
					latterNum = Float.parseFloat(data[j][9]);
				}
				if(!data[j-1][9].equals("")){
					formerNum = Float.parseFloat(data[j-1][9]);
				}
				if(latterNum > formerNum){
					for(int k=0; k<data[j].length;k++){
						String temp = data[j][k];
						data[j][k] = data[j-1][k];
						data[j-1][k] = temp;
					}
				}
			}
		}
	}
	
	//�����з����Ŀγ���Ŀ
	private int CourseNum(){
		int CourseWithScore=0;
		for(int i=data.length-1; i > 0; i--){
			if(!data[i][9].equals("")){
				CourseWithScore++;
			}
		}
		return CourseWithScore;
	}
	
	//��ȡHtml�ļ�
	private void ReadHtml(String fileName){
		Document doc = null;
		data = null;
		try{
			File input = new File(fileName);
			doc = Jsoup.parse(input, encoding, "");
		}catch(IOException e){
			System.out.println("Can't load file!");
		}
		Elements tableContents = doc.getElementsByClass("listTable");
		
		int i = 0;
		for (Element tableContent : tableContents) {
			Elements trContents = tableContent.getElementsByTag("tr");
			data = new String[trContents.size()][];
			for(Element trContent : trContents){
				Elements tdContents = null;
				if(i==0){
					tdContents = trContent.getElementsByTag("th");
				}else{
					tdContents = trContent.getElementsByTag("td");
				}			
				data[i] = new String[tdContents.size()];
				int j = 0;
				for(Element tdContent : tdContents){
					data[i][j] = tdContent.text();
					j++;
				}
				i++;
			}
		}
	}

	//д��Txt�ļ�
	private void WriteTxt(String fileName){
		File file =new File(fileName);
		//�����ɼ����ļ�
		if(file.exists()){
			System.out.println("�Ѹ��³ɼ���");
		}else{
			try {
				file.createNewFile();
				System.out.println("�ɼ����Ѵ���");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		//д��ɼ�
		try {
			PrintWriter pw = new PrintWriter(file);
			// bufw = new BufferedWriter(fw);
			for(int k=0; k<=CourseNum(); k++){
				for(int w=0; w<data[0].length; w++){
						pw.print((data[k][w]));
				}
				pw.println();
			}
			pw.println("��Ȩƽ������"+CalcWeightedAverageMark());
			pw.println("GPA��"+CalcGPA());
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

