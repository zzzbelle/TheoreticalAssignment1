package TheoreticalAssignment1;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.Sheet;
import jxl.Workbook;
 
public class TheoreticalAssignment1 {
	public static void main(String[] args) throws Exception {
        
		   jxl.Workbook readwb = null;   
		   
	         
	  
	       
	  
	            //构建Workbook对象, 只读Workbook对象   
	  
	            //直接从本地文件创建Workbook   
	  
	         InputStream instream = new FileInputStream("Grade.xls");   
	  
	            readwb = Workbook.getWorkbook(instream);   
	  
	    
	  
	            //Sheet的下标是从0开始   
	  
	            //获取第一张Sheet表   
	  
	            Sheet sheet = readwb.getSheet(0);   
	  
	            //获取Sheet表中所包含的总列数   
	      
  
    String cells[][]=new String[24][11];
    int x=0,y=0;
    for(x=0;x<24;x++){
    	for(x=0;x<10;x++){
    		  cells[x][y] = sheet.getCell(y,x).getContents();
    	}
    }
    readwb.close();
    double jd=0.0;//绩点
    double q=0.0;//学分乘成绩
    double w=0.0;//绩点乘成绩
    double e=0.0;//绩点乘学分
    for(x=1;x<24;x++)
	{
    	q+=Double.valueOf(cells[x][3])*Double.valueOf(cells[x][9]);
    	if(Double.valueOf(cells[x][9])>=90 && Double.valueOf(cells[x][9])<=100)
			jd=4.0;
	    if(Double.valueOf(cells[x][9])>=85 && Double.valueOf(cells[x][9])<=89)
			jd=3.7;
	   if(Double.valueOf(cells[x][9])>=82 && Double.valueOf(cells[x][9])<=84)
			jd=3.3;
		if(Double.valueOf(cells[x][9])>=78 && Double.valueOf(cells[x][9])<=81)
			jd=3.0;
		if(Double.valueOf(cells[x][9])>=75 && Double.valueOf(cells[x][9])<=78)
			jd=2.7;
		if(Double.valueOf(cells[x][9])>=72 && Double.valueOf(cells[x][9])<=75)
			jd=2.3;
		if(Double.valueOf(cells[x][9])>=68 && Double.valueOf(cells[x][9])<=72)
			jd=2.0;
		if(Double.valueOf(cells[x][9])>=64 && Double.valueOf(cells[x][9])<=68)
			jd=1.5;
		if(Double.valueOf(cells[x][9])>=60 && Double.valueOf(cells[x][9])<=64)
			jd=1.0;
		else
			jd=0;
		w=w+jd*Double.valueOf(cells[x][9]);
		e=e+jd*Double.valueOf(cells[x][3]);
	}
    double jqpjf;
    double gpa;
    jqpjf=q/e/7;
    gpa=w/e/7;
	WritableWorkbook book_ex= Workbook.createWorkbook(new File("Grade-ex.xls"));   
	WritableSheet sheet_ex=book_ex.createSheet("1",0);
	//循环打印出结果
	for( x=0;x<24;x++)
	{
		for(y=0;y<10;y++)
		{
			sheet_ex.addCell(new Label(y,x,cells[x][y]));
		}
	}
	sheet_ex.addCell(new Label(1,24,"加权平均分"));
	sheet_ex.addCell(new Label(2,24,jqpjf+""));
	sheet_ex.addCell(new Label(1,25,"GPA"));
	sheet_ex.addCell(new Label(2,25,gpa+""));
    //排序
 String[] change;
    for( x=1;x<25;x++)
    {
      //里面的for循环控制比较次数
      for(y=1;y<25-x-1;y++)
      {
        //满足条件则交换数据
        if(Integer.valueOf(cells[y][9]) < Integer.valueOf(cells[y+1][9]))
        {
          change=cells[y];
          cells[y]=cells[y+1];
          cells[y+1]=change;
        }
      }
    }
    
	book_ex.write();
	book_ex.close();
}
}