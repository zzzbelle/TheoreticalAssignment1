import java.io.File;
import java.io.FileInputStream;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class MainOutPut {
	
	private static void processScoreTable(File mine ) throws IOException{
		InputStream chengjidan = new FileInputStream(mine);
		HSSFWorkbook wbone = new HSSFWorkbook(chengjidan);
		HSSFSheet stone = wbone.getSheetAt(0);//read the old excel
		HSSFWorkbook wbtwo = new HSSFWorkbook();
		HSSFSheet sttwo = wbtwo.createSheet();//write the new excel
		double Credits=0;
		for (int j = 0; j < 22; j++) {
			Credits += stone.getRow(j).getCell(3).getNumericCellValue();
		}//calculate the total credits
		
		double average = 0;
		for (int j = 0; j < 22; j++) {
			average += stone.getRow(j).getCell(3).getNumericCellValue()* stone.getRow(j).getCell(9).getNumericCellValue();
		}
		average = average/Credits;//calculate the average of the grade
		
		int xulie[] = new int[22];//排列成绩的顺序
		for(int m= 0; m<22; m++)
		{			xulie[m] = 0;
			for(int n= 0; n<22; n++)
			{		
				if(sttwo.getRow(m).getCell(9).getNumericCellValue()< sttwo.getRow(n).getCell(9).getNumericCellValue())
				{
					xulie[m]++;
				}
			}
			for(int s = 0; s<m; s++)
			{
				if(stone.getRow(m).getCell(9).getNumericCellValue() == stone.getRow(m).getCell(9).getNumericCellValue())
				{
				xulie[m]++;
				}
			}
		}

		for(int m= 0; m<22; m++)
	           for(int n = 0; n<10; n++)
				{
					changeValue(sttwo.getRow(m).getCell(n), sttwo.getRow(xulie[m]).getCell(n));
				}
		double jidian[]=new double [22];
		for(int a=0;a<22;a++ ){
			if(stone.getRow(a).getCell(9).getNumericCellValue() >= 90)
			{
				jidian[a] = 4.0;
			}
			else if(stone.getRow(a).getCell(9).getNumericCellValue() >= 85&stone.getRow(a).getCell(9).getNumericCellValue() <= 89)
			{
				jidian[a] = 3.7;
			}
			else if(stone.getRow(a).getCell(9).getNumericCellValue() >= 82& stone.getRow(a).getCell(9).getNumericCellValue() <= 84)
			{
				jidian[a] = 3.3;
			}
			else if(stone.getRow(a).getCell(9).getNumericCellValue() >= 78&stone.getRow(a).getCell(9).getNumericCellValue() <= 81)
			{
				jidian[a] = 3.0;
			}
			else if(stone.getRow(a).getCell(9).getNumericCellValue() >= 75&stone.getRow(a).getCell(9).getNumericCellValue() <= 77)
			{
				jidian[a] = 2.7;
			}
			else if(stone.getRow(a).getCell(9).getNumericCellValue() >= 72&stone.getRow(a).getCell(9).getNumericCellValue() <= 74)
			{
				jidian[a] = 2.3;
			}
			else if(stone.getRow(a).getCell(9).getNumericCellValue() >= 68&stone.getRow(a).getCell(9).getNumericCellValue() <= 71)
			{
				jidian[a] = 2.0;
			}
			else if(stone.getRow(a).getCell(9).getNumericCellValue() >= 64&stone.getRow(a).getCell(9).getNumericCellValue() <= 67)
			{
				jidian[a] = 1.5;
			}		
			else
			{
				jidian[a] = 0.0;
			}
		}//calculate the jidian of the subjects
		   
		double gpa=0;
		for(int b=0;b<22;b++){
			gpa+= jidian[b] * stone.getRow(b).getCell(3).getNumericCellValue()/Credits;			
		}//calculate gpa
		sttwo.getRow(23).getCell(0).setCellValue("加权平均分");
		sttwo.getRow(23).getCell(1).setCellValue(average);//set average
		sttwo.getRow(24).getCell(0).setCellValue("GPA");
		sttwo.getRow(24).getCell(1).setCellValue(gpa);//set gpa
		FileOutputStream out = new FileOutputStream("~/chengjidan2");		
		wbone.write(out);
		out.close();
		wbone.close();
		wbtwo.close();//output excel
		
		}
	public static void changeValue(HSSFCell oldCell, HSSFCell newCell) {
		if (oldCell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {
			newCell.setCellValue(oldCell.getNumericCellValue());
		} else if (oldCell.getCellType() == HSSFCell.CELL_TYPE_STRING) {
			newCell.setCellValue(oldCell.getStringCellValue());
		} else {
			System.out.println("!!!!");
		}
	}
	public static void main(String[] args) throws IOException {
        File mine =new File("~/chengjidan");
        processScoreTable(mine);
        System.out.println("!!!");
	}		
}
