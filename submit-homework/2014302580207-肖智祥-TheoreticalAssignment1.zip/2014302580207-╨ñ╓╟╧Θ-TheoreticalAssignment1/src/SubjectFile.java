
import java.io.BufferedReader;  
import java.io.BufferedWriter;  
import java.io.FileNotFoundException;  
import java.io.FileWriter;  
import java.io.IOException;  
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.util.ArrayList;  
import java.util.List;

//����SubjectFile�࣬���ڶ�дtxt�ĵ�
public class SubjectFile {
	public List<Subject> readFile(String path) throws Exception
	{//��ȡ
		List<Subject> subjectList = new ArrayList<Subject>();
		BufferedReader br = null;
		try
		{
			//��ֹ��������
			InputStreamReader isr = new InputStreamReader(new FileInputStream(path),"Unicode");
			br = new BufferedReader(isr);
			String line = null;
			Subject subject = null;
			while ((line = br.readLine()) != null)
			{
				subject = new Subject();
				//���ַ����ָ���ַ�������
				String[] subjectStr = line.split("	");
				
				subject.setSubjectId(subjectStr[0]);//��ͷ��
				subject.setSubjectName(subjectStr[1]);//�γ����� 
				subject.setSubjectType(subjectStr[2]);//�γ�����
				subject.setSubjectCredit(subjectStr[3]);//ѧ��
				subject.setSubjectTeacher(subjectStr[4]);//��ʦ
				subject.setSubjectDepartment(subjectStr[5]);//�ڿ�ѧԺ
				subject.setStudyType(subjectStr[6]);//ѧϰ����
				subject.setStudyYear(subjectStr[7]);//ѧ��
				subject.setStudyTerm(subjectStr[8]);//ѧ��
				subject.setSubjectScore(subjectStr[9]);//�ɼ�
				subjectList.add(subject);
				
			}
		}
		catch (FileNotFoundException e)
		{
			throw new Exception("Դ�ļ�δ�ҵ�", e);
		}
		catch (IOException e)
		{
			throw new Exception("��ȡ�ļ��쳣", e);
		}
		finally
		{
			if (br != null)
			{
				try
				{
					br.close();
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}
			}
		}
		return subjectList;
	}
	
	/**  
     *   
     * {�γ���Ϣд��Ŀ���ļ�}  
     * @param subjectList   
     * @throws Exception  
     *  
     */
	public void writeFile(List<Subject> subjectList, String dstpath) throws Exception
	{//д��
		BufferedWriter bw = null;
		try
		{
			bw = new BufferedWriter(new FileWriter(dstpath));
			if (subjectList != null && !subjectList.isEmpty())
			{
				for(Subject sub:subjectList)
				{
					bw.write(sub.getSubjectId() + "\t" + sub.getSubjectName() + "\t"
							+ sub.getSubjectType() + "\t" + sub.getSubjectCredit()
							+ "\t" + sub.getSubjectTeacher() + "\t" + sub.getSubjectDepartment()
							+ "\t" + sub.getStudyType() + "\t" + sub.getStudyYear()
							+ "\t" + sub.getStudyTerm() + "\t" + sub.getSubjectScore());
					bw.newLine();//����
				}
				bw.write("��Ȩƽ���֣�" + weightedAverage( subjectList));
				bw.newLine();
				bw.write("GPA:" + averageGpa(subjectList));
				bw.newLine();
			}
			bw.flush();//ǿ������������ݣ��������ݻ��棬����ļ�д�벻����
		}
		catch (IOException e)
		{
				throw new Exception("Ŀ���ļ�δ�ҵ�", e);
		}
		finally
		{//��Դ�ر�
			if (bw != null)
			{
				try
				{
					bw.close();
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}
			}
		}
	}

	private double averageGpa(List<Subject> subjectList) {
		// TODO �Զ����ɵķ������
		double averageGpa = 0;//GPA
		double sumCredit = 0;//��ѧ��
		double sumGpa = 0;//��GPA
		double singleCredit;//ĳһ��Ŀѧ��
		double singleGpa ;//ĳһ��ĿGPA
		double singleScore;//ĳһ��Ŀ����
		for (Subject sub : subjectList)
		{
			singleScore = Double.valueOf(sub.getSubjectScore());
			if (singleScore <= 100 && singleScore >= 90)
			{
				singleGpa = 4.0;
			}
			else if (singleScore >= 85)
			{
				singleGpa = 3.7;
			}
			else if (singleScore >= 82)
			{
				singleGpa = 3.3;
			}
			else if (singleScore >= 78)
			{
				singleGpa = 3.0;
			}
			else if (singleScore >= 75)
			{
				singleGpa = 2.7;
			}
			else if (singleScore >= 72)
			{
				singleGpa = 2.3;
			}
			else if (singleScore >= 68)
			{
				singleGpa = 2.0;
			}
			else if (singleScore >= 64)
			{
				singleGpa = 1.5;
			}
			else if (singleScore >= 60)
			{
				singleGpa = 1.0;
			}
			else { singleGpa = 0.0; }
			
			singleCredit = Double.valueOf(sub.getSubjectCredit());
			sumCredit = sumCredit + singleCredit;
			sumGpa = sumGpa + singleGpa * singleCredit;
		}
		averageGpa = sumGpa / sumCredit;
		return averageGpa;
	}

	private double weightedAverage(List<Subject> subjectList) {
		// TODO �Զ����ɵķ������
		double weightedAverage = 0;//��Ȩƽ����
		double sumCredit = 0;//��ѧ��
		double sumScore = 0;//�ܷ���
		double singleCredit;//����ѧ��
		for (Subject sub : subjectList)
		{
			singleCredit = Double.valueOf(sub.getSubjectCredit());
			sumCredit = sumCredit + singleCredit;
			sumScore = sumScore + Double.valueOf(sub.getSubjectScore()) * singleCredit;
		}
		weightedAverage = sumScore / sumCredit;
		return weightedAverage;
	}
}