import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.apache.poi.hssf.usermodel.*;

public class ExcelReader
{	
	private HSSFWorkbook wb;  //Ҫ��ȡ��Excel�ļ�
	private HSSFRow row; //��
	private HSSFSheet sht;//ҳ
	private HSSFCell[] content; //����
	private FileInputStream excel;
	
	public HSSFCell GetHSSFCell(int i)
	{
		return content[i];//��õ�i+1����Ԫ��ֵ
	}
	
	public HSSFRow GetHSSFRow()
	{
		return row;//��ȡ��
	}
	public void TurnOnInput() throws FileNotFoundException 
	{
		excel = new FileInputStream("GradeBefore.xls");//����
	}
	
	public void TurnOffInput() throws IOException
	{
		excel.close();//�ر�
	}

	
	public ExcelReader(int rowNumber) throws IOException 
	{
		excel = new FileInputStream("GradeBefore.xls");
		content=new HSSFCell[10];
		wb = new HSSFWorkbook(excel);
		sht = wb.getSheet("Sheet1");
		row = sht.getRow(rowNumber);
		for(int i=0;i<10;i++)
		{
			content[i] = row.getCell(i);
		}
		excel.close();
	}
	
}
