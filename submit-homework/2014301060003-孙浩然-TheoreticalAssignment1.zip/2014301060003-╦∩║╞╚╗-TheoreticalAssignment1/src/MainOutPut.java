import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainOutPut {
	
	public static void main(String[] args) throws IOException
	{
		File input = new File("input.txt");
		MainOutPut mop = new MainOutPut();
		
		//input original score list and output new score list
		mop.processScoreTable(input);
	}
	
	public void processScoreTable(File input) throws IOException{
		try{
			File output = new File("output.txt");
			
			//sort
			ArrayList<Subject> classInfo = getinfo(input);
			
			double averagescore = getAverageScore(classInfo);
			double averagegpa = getAverageGpa(classInfo);
			BufferedWriter bw = new BufferedWriter(new FileWriter(output,true));
			
			//output to file
			for(Subject i:classInfo)
			{
				bw.write(i.classId+"\t"+i.className+"\t"+i.classType+"\t"+
						i.credit+"\t"+i.teacher +"\t"+i.department+"\t"+i.type+"\t"+i.year+"\t"+
						i.semester+"\t"+i.score+"\r\n");
			}
			bw.write("��Ȩƽ���֣� "+averagescore+"\t\t"+"��ȨGPA: "+averagegpa);
			bw.close();
			}catch(Exception e){
				e.printStackTrace();
			}
	}
	
	public static ArrayList<Subject> getinfo(File input)
	{
		ArrayList<Subject> info = new ArrayList<Subject>();
		try{
			InputStreamReader isr = new InputStreamReader(new FileInputStream(input),"Unicode");
			BufferedReader br = new BufferedReader(isr);
			String s=null;
			
			//input a line and get separated items
			while((s=br.readLine())!=null)
			{
				//split different items
				String[] arr = s.split("\\t+");
				info.add(new Subject(arr[0],arr[1],arr[2],Double.parseDouble(arr[3]),arr[4],arr[5],arr[6],arr[7],arr[8],Double.parseDouble(arr[9])));
			}
			br.close();
		
			//sort
			Collections.sort(info,new SortByScore());			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return info;		
	}	
	
	public static double getAverageScore(ArrayList<Subject> al)
	{
		double averagescore;
		double sumcredit=0;
		double sumscore=0;
		double credit,score;
		for(Subject i:al){
			credit = i.getCredit();
			score = i.getScore();
			sumcredit = sumcredit + credit;
			sumscore = sumscore + score*credit;
		}
		averagescore = sumscore / sumcredit;
		return averagescore;
	}

	public static double getAverageGpa(ArrayList<Subject> al)
	{
		double averagegpa;
		double sumgpa = 0;
		double sumcredit=0;
		double gpa,credit,score;
		for(Subject i:al)
		{
			credit = i.getCredit();
			score = i.getScore();
			sumcredit = sumcredit + credit;
			if(score>=90) gpa = 4.0;
			else if(score>=85) gpa = 3.7;
			else if(score>=82) gpa = 3.3;
			else if(score>=78) gpa = 3.0;
			else if(score>=75) gpa = 2.7;
			else if(score>=72) gpa = 2.3;
			else if(score>=68) gpa = 2.0;
			else if(score>=64) gpa = 1.5;
			else if(score>=60) gpa = 1.0;
			else gpa = 0;
			sumgpa = sumgpa + gpa*credit;
		}
		averagegpa = sumgpa / sumcredit; 
		return averagegpa;
	}
}

class SortByScore implements Comparator{
	
	public int compare(Object o1,Object o2)
	{
		Subject sub1 = (Subject)o1;
		Subject sub2 = (Subject)o2;
		if(sub1.getScore()>sub2.getScore()) return -1;
		else if(sub1.getScore()<sub2.getScore()) return 1;
		return 0;
	}
}


class Subject{
	String classId;
	String className;
	String classType;
	double credit;
	String teacher;
	String department;
	String type;
	String year;
	String semester;
	double score;
	
	public double getScore()
	{
		return score;
	}
	public double getCredit()
	{
		return credit;
	}
	
	public Subject(String m_classId,
	String m_className,
	String m_classType,
	double m_credit,
	String m_teacher,
	String m_department,
	String m_type,
	String m_year,
	String m_semester,
	double m_score){
		this.classId = m_classId;
		this.className = m_className;
		this.classType = m_classType;
		this.credit = m_credit;
		this.teacher = m_teacher;
		this.department = m_department;
		this.type = m_type;
		this.year = m_year;
		this.semester = m_semester;
		this.score = m_score;
	}
}
