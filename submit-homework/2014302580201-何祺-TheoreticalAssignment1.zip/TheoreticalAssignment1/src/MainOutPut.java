import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class MainOutPut {
	public static void main(String[] args) throws IOException {
		processScoreTable("grade.xls");
	}
	
	public static void processScoreTable(String filename) throws IOException{
		//�����ųɼ���execl�ļ�
				File excelFile = new File(filename);
				FileInputStream input = new FileInputStream(excelFile);
				HSSFWorkbook wb = new HSSFWorkbook(input);
				//����sheet����,������ŵ�0��sheet������
				HSSFSheet sheet = wb.getSheetAt(0);
				//��ȡ��Ч����
				int rowCount = sheet.getPhysicalNumberOfRows();
				//����row����
				HSSFRow row1;
				HSSFRow row2;
				//����cell����
				HSSFCell cell1;
				HSSFCell cell2;
				//����averageGrade,averageGPA,total����,���������Ȩƽ�����Լ��ۺϼ�ȨGPA
				double averageGrade = 0;
				double averageGPA = 0;
				double total = 0;
				//��ð�����򷨽����������Գɼ�Ϊ�ؼ��ֽ�����ʾ
				for (int i = 1; i <= rowCount - 2; i++) {
					for (int j = 1; j <= rowCount - i - 1; j++) {
						row1 = sheet.getRow(rowCount - j);
						row2 = sheet.getRow(rowCount - j - 1);
						cell1 = row1.getCell(9);
						cell2 = row2.getCell(9);
						double value1 = cell1.getNumericCellValue();
						double value2 = cell2.getNumericCellValue();
						if (value1 > value2) {
							for (int k = 0; k <= 9; k++) {
								cell1 = row1.getCell(k);
								cell2 = row2.getCell(k);
								switch (cell1.getCellType()) {
								case HSSFCell.CELL_TYPE_STRING:
									String value3 = cell1.getStringCellValue();
									String value4 = cell2.getStringCellValue();
									cell2.setCellValue(value3);
									cell1.setCellValue(value4);
									break;
								case HSSFCell.CELL_TYPE_NUMERIC:
									double value5 = cell1.getNumericCellValue();
									double value6 = cell2.getNumericCellValue();
									cell2.setCellValue(value5);
									cell1.setCellValue(value6);
									break;
								}
							}
						}
					}
				}
				//�����Ȩƽ�����Լ��ۺϼ�ȨGPA
				for (int i = 1; i <= rowCount - 1; i++) {
					row1 = sheet.getRow(i);
					cell1 = row1.getCell(3);
					cell2 = row1.getCell(9);
					double value1 = cell1.getNumericCellValue();
					double value2 = cell2.getNumericCellValue();
					averageGrade = averageGrade + value1 * value2;
					if (value2 <= 100 && value2 >= 90) {
						averageGPA = averageGPA + 4.0 * value1;
					} else {
						if (value2 <= 89 && value2 >= 85) {
							averageGPA = averageGPA + 3.7 * value1;
						} else {
							if (value2 <= 84 && value2 >= 82) {
								averageGPA = averageGPA + 3.3 * value1;
							} else {
								if (value2 <= 81 && value2 >= 78) {
									averageGPA = averageGPA + 3.0 * value1;
								} else {
									if (value2 <= 77 && value2 >= 75) {
										averageGPA = averageGPA + 2.7 * value1;
									} else {
										if (value2 <= 74 && value2 >= 72) {
											averageGPA = averageGPA + 2.3 * value1;
										} else {
											if (value2 <= 71 && value2 >= 68) {
												averageGPA = averageGPA + 2.0 * value1;
											} else {
												if (value2 <= 67 && value2 >= 64) {
													averageGPA = averageGPA + 1.5 * value1;
												} else {
													if (value2 <= 63 && value2 >= 60) {
														averageGPA = averageGPA + 1.0 * value1;
													} else {
														if (value2 < 60) {
															averageGPA = averageGPA + 0 * value1;
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
					total = total + value1;

				}
				averageGrade = averageGrade / total;
				averageGPA = averageGPA / total;
				//����Ȩƽ���ֺ��ۺϼ�ȨGPA�Ա���С�������λ����ʽ���ӵ�������
				DecimalFormat df=new DecimalFormat("#.000");
				String strAverageGrade=df.format(averageGrade);
				String strAverageGPA=df.format(averageGPA);
				row1 = sheet.createRow(rowCount);
				row1.createCell(0).setCellValue("��Ȩƽ����");
				row1.createCell(1).setCellValue(strAverageGrade);
				row1.createCell(2).setCellValue("�ۺϼ�ȨGPA");
				row1.createCell(3).setCellValue(strAverageGPA);
				//�����Ҫ�ı���
				FileOutputStream fileOut = new FileOutputStream("gradesort.xls");
				wb.write(fileOut);
				fileOut.close();
			}
	}
