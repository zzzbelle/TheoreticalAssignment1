import java.io.*;
import java.util.Collections;
import java.util.Comparator;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import jxl.write.Number;
import jxl.write.WritableCellFormat;

import java.awt.Button;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.*;
import org.jsoup.*;
import org.jsoup.nodes.*;
import org.jsoup.select.Elements;
public class MainGui extends Frame implements MouseListener {
	/**
	 *��һ���� eclipse ��Ҫ�ӵ�һ�仰���ͱ�����ûʲô��ϵ��
	 */
	private static final long serialVersionUID = 1L;
	//������ť
	private Button read=new Button("read message");
	private Button write=new Button("write message");
	//����ͼƬ
	private Image bkimg=new ImageIcon("e.jpg").getImage();
	//�Զ�����һ��record�࣬��������һ�У�һ����Ŀ����������Ϣ����vector����all_record�������е���Ϣ��
	private Vector<record> all_record=new Vector<record>();
	//��������ÿһ�п��ȵ����顣
	private int[] labelWidths=new int[]{15,25,10,6,10,18,10,8,7,10,15,15,15};
	public MainGui(String str){
		super(str);
		initGui();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new MainGui("mainGui");
		
	}
	//����GUI����ķ���
	public void  initGui(){
		//�����򵥵�GUI���棬��Ϊ������ť���Ӽ�������
		setLayout(new FlowLayout());
		setSize(400,300);
		Dimension screenSize=Toolkit.getDefaultToolkit().getScreenSize();
		Dimension windowSize=getSize();
		int x=(screenSize.width-windowSize.width)/2;
		int y=(screenSize.height-windowSize.height)/2;
		setLocation(x,y);
		read.addMouseListener(this);
		write.addMouseListener(this);
		add(read);
		add(write);
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				setVisible(false);
				dispose();
				System.exit(0);
			}
		});
		setVisible(true);
	}
	//���ñ���ͼƬ
	public void paint(Graphics g){
		super.paint(g);
		g.drawImage(bkimg,0,0,null);
	}
	//read message from HTML and write the message to a excel,
	//then read message form the excel.
	//��ȡ��Ϣ�ķ���,��read message��ť��һ�ΰ��´˷��������á�
	//�ȴ�HTML�ļ��ж�ȡ��Ϣ��Ȼ����Ϣд���һ��excel�ļ��У�Ȼ������excel�ļ��ж�ȡ��Ϣ������all_record�С�
	public void read() throws IOException, RowsExceededException, WriteException, BiffException{
		//get message from myScore.html
		//���all_record�ĳ��ȣ�����Ϊ0����ֱ��������
		if(all_record.size()!=0){
			return;
		}
		//��HTML�ж�ȡ��Ϣ
		File input=new File("myScore.html");
		Document doc=Jsoup.parse(input,"GB2312","");
		Elements heads=doc.select("th");
		Elements dates=doc.select("td");
		//write message into a new excel
		//����һ��excel�ļ�
		WritableWorkbook wwb=Workbook.createWorkbook(new 
				File("../myScore.xls"));
		WritableSheet ws=wwb.createSheet("my score", 0);
		//�涨���еĿ���
		for(int index=0;index<13;index++)
		{
			ws.setColumnView(index, labelWidths[index]);
		}
		//�涨��¼����һ�еĵ�һ���ֿ���
		WritableCellFormat cF=new WritableCellFormat();
		cF.setAlignment(jxl.format.Alignment.RIGHT);
		int j=0;
		//д���һ��
		for(Element head:heads){
			String str=head.text();
			Label lb=new Label(j,0,str);
			if(j==0||j==3||j==7||j==9){
				lb.setCellFormat(cF);
			}
			ws.addCell(lb);
			j++;
		}
		//д��ʣ���С�
		int i=0;
		for(Element date:dates){
			int y=i/11+1;
			int x=i%11;
			String str=date.text();
			if((x==0|x==3||x==7||x==9)&&(!(str==null||str.length()<=0))){
				double d=Double.valueOf(str).doubleValue();
				Number laN=new Number(x,y,d);
				ws.addCell(laN);
			}else{
				Label lb=new Label(x,y,str);
				ws.addCell(lb);
			}
			i++;
		}
		wwb.write();
		wwb.close();
		//get all message from the excel
		//�Ӹոմ�����excel�ļ��ж�ȡ��Ϣ
		InputStream is=new FileInputStream("../myScore.xls");
		Workbook rwb=Workbook.getWorkbook(is);
		Sheet rst=rwb.getSheet(0);
		int rsRows=rst.getRows();
		//�ӵڶ��п�ʼ��ȡ��ÿһ�е�������Ϣ������һ��record�����У�Ȼ��record����������all_record�С�
		//��ѧ�ڿγ�û�гɼ����ڴ˾���ɸѡ�������롣
		for(int k=1;k<rsRows;k++){
			String str=rst.getCell(9,k).getContents();
			if(str==null||str.length()<=0){
				continue;
			}
			record r=new record();
			r.classNumber=rst.getCell(0, k).getContents();
			r.className=rst.getCell(1, k).getContents();
			r.classStyle=rst.getCell(2,k).getContents();
			r.classCredit=Double.valueOf(rst.getCell(3,k).getContents()).doubleValue();
			r.classTeacher=rst.getCell(4,k).getContents();
			r.teachSchool=rst.getCell(5,k).getContents();
			r.studyStyle=rst.getCell(6,k).getContents();
			r.studyYear=Integer.valueOf(rst.getCell(7,k).getContents()).intValue();
			r.studyTerm=rst.getCell(8,k).getContents();
			r.studyScore=Double.valueOf(rst.getCell(9,k).getContents()).doubleValue();
			all_record.add(r);
		}
		
	}
	//put the message in order and write the new message to another excel.
	//�����Ϣ�ķ�������write message ��ť������ʱ���á�
	public void write() throws IOException, RowsExceededException, WriteException{
		//���ݳɼ���all_record ��������
		Collections.sort(all_record,new Comparator<Object>(){
			public int compare(Object left,Object right){
				record l=(record)left;
				record r=(record)right;
				if(l.studyScore>r.studyScore){
					return -1;
				}else{
					return 1;
				}
			}
		});
		//���ݳɼ����ÿһ�ŵ�GPA���������ѧ�֡�
		double all_credits=0;
		for(int index=0;index<all_record.size();index++){
			all_credits+=all_record.get(index).classCredit;
			if(all_record.get(index).studyScore>=90){
				all_record.get(index).aveGPA=4;
			}else if(all_record.get(index).studyScore>=85){
				all_record.get(index).aveGPA=3.7;
			}else if(all_record.get(index).studyScore>=82){
				all_record.get(index).aveGPA=3.3;
			}else if(all_record.get(index).studyScore>=78){
				all_record.get(index).aveGPA=3.0;
			}else if(all_record.get(index).studyScore>=75){
				all_record.get(index).aveGPA=2.7;
			}else if(all_record.get(index).studyScore>=72){
				all_record.get(index).aveGPA=2.3;
			}else if(all_record.get(index).studyScore>=68){
				all_record.get(index).aveGPA=2.0;
			}else if(all_record.get(index).studyScore>=64){
				all_record.get(index).aveGPA=1.5;
			}else if(all_record.get(index).studyScore>=60){
				all_record.get(index).aveGPA=1.0;
			}else{
				all_record.get(index).aveGPA=0.0;
			}
		}
		//�����Ȩƽ���ֺͼ�ȨGPA����ͨ��ȥβ��������λС��
		double AveScore=0;
		double AveGPA=0;
		for(int index=0;index<all_record.size();index++){
			AveScore+=all_record.get(index).studyScore*all_record.get(index).classCredit/all_credits;
			AveGPA+=all_record.get(index).aveGPA*all_record.get(index).classCredit/all_credits;
		}
		AveScore=((double)((int)((AveScore-(int)AveScore)*100)))/100.00+(int)AveScore;
		AveGPA=((double)((int)((AveGPA-(int)AveGPA)*100)))/100.00+(int)AveGPA;
		//��read()���� ��ֱ�Ӷ�ȡHTML����Ϣ�������µ�excel�ļ���д���һ��
		File input=new File("myScore.html");
		Document doc=Jsoup.parse(input,"GB2312","");
		Elements heads=doc.select("th");
		WritableWorkbook wwbk=Workbook.createWorkbook(new 
				File("../reWrite.xls"));
		WritableSheet wst=wwbk.createSheet("reWrite",0);
		//�涨ÿһ�еĿ��ȡ�
		for(int index=0;index<13;index++)
		{
			wst.setColumnView(index, labelWidths[index]);
		}
		//�涨�����ֵ�һ�����ֿ������С�
		WritableCellFormat cF=new WritableCellFormat();
		cF.setAlignment(jxl.format.Alignment.RIGHT);
		int j=0;
		for(Element head:heads){
			String str=head.text();
			//��ʮһ�У���һ�У���Ϊ�����ƣǣУ�����
			if(j==10){
				Label lb=new Label(j,0,"����GPA");
				if(j==0||j==3||j==7||j==9){
					lb.setCellFormat(cF);
				}
				wst.addCell(lb);
			}else{
				Label lb=new Label(j,0,str);
				if(j==0||j==3||j==7||j==9){
					lb.setCellFormat(cF);
				}
				wst.addCell(lb);
			}
			
			j++;
		}
		//�ֶ����ӵ�һ�е���Ϣ
		Label lbscore=new Label(11,0,"��Ȩƽ���ɼ�");
		lbscore.setCellFormat(cF);
		wst.addCell(lbscore);
		Label lbgpa=new Label(12,0,"��ȨGPA");
		lbgpa.setCellFormat(cF);
		wst.addCell(lbgpa);
		//�����Ȩƽ���ɼ��ͼ�Ȩ�ǣУ���
		Number aves=new Number(11,1,AveScore);
		Number gpa=new Number(12,1,AveGPA);
		wst.addCell(aves);
		wst.addCell(gpa);
		//���������е���Ϣ
		for(int index=0;index<all_record.size();index++){
			Number b1=new Number(0,index+1,Double.valueOf(all_record.get(index).classNumber).doubleValue());
			wst.addCell(b1);
			Label b2=new Label(1,index+1,all_record.get(index).className);
			wst.addCell(b2);
			Label b3=new Label(2,index+1,all_record.get(index).classStyle);
			wst.addCell(b3);
			Number b4=new Number(3,index+1,all_record.get(index).classCredit);
			wst.addCell(b4);
			Label b5=new Label(4,index+1,all_record.get(index).classTeacher);
			wst.addCell(b5);
			Label b6=new Label(5,index+1,all_record.get(index).teachSchool);
			wst.addCell(b6);
			Label b7=new Label(6,index+1,all_record.get(index).studyStyle);
			wst.addCell(b7);
			Number b8=new Number(7,index+1,all_record.get(index).studyYear);
			wst.addCell(b8);
			Label b9=new Label(8,index+1,all_record.get(index).studyTerm);
			wst.addCell(b9);
			Number b10=new Number(9,index+1,all_record.get(index).studyScore);
			wst.addCell(b10);
			Number b11=new Number(10,index+1,all_record.get(index).aveGPA);
			wst.addCell(b11);
			
		}
		wwbk.write();
		wwbk.close();
		
	}
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		//�����������ť����Ӧ������
		if(e.getSource()==read){
			try {
				read();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (RowsExceededException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (WriteException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (BiffException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			JOptionPane.showMessageDialog(null,"message has benn got,you can open mySocre.xls to confirm.","ok",JOptionPane.INFORMATION_MESSAGE);
		}else if(e.getSource()==write){
			try {
				write();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (RowsExceededException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (WriteException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			JOptionPane.showMessageDialog(null,"message has benn reWrite,you can open reWrite.xls to confirm.","ok",JOptionPane.INFORMATION_MESSAGE);
		}
	}
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
//�Զ����record��
class record{
	public String classNumber;
	public String className;
	public String classStyle;
	public double classCredit;
	public String classTeacher;
	public String teachSchool;
	public String studyStyle;
	public int studyYear;
	public String studyTerm;
	public double studyScore;
	public double aveScore;
	public double aveGPA;
	public record(String a,String b,String c,double d,String e,String f,
			String g,int h,String i,double j,double k,double l){
		classNumber=a;
		className=b;
		classStyle=c;
		classCredit=d;
		classTeacher=e;
		teachSchool=f;
		studyStyle=g;
		studyYear=h;
		studyTerm=i;
		studyScore=j;
		aveScore=k;
		aveGPA=l;
	}
	public record() {
		// TODO Auto-generated constructor stub
	}
}