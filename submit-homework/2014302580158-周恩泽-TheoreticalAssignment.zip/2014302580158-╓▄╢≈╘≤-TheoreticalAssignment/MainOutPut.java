package chengji;

import java.io.File;
import java.io.IOException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class MainOutPut {
	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		processScoreTable("D:/chengji.xls");
	}
	//��ȡ���޸�Ecel�ķ���Change
	public static void processScoreTable(String filePath){
		try {
			Workbook book = Workbook.getWorkbook(new File(filePath));
			 Sheet sheet = book.getSheet(0);
			 
			 int rows = sheet.getRows();
			 int cols = sheet.getColumns();
			 //get (0,0) cell
			 String cellcontent [][] =new String[cols][rows];//����һ����ά�����¼�¶�������ÿ�������
			 double score[] = new double[rows];//����һ���ɼ�����
			 double g[] = new double[rows];//����һ��ѧ�����飻
			 
			 for (int i = 0; i <sheet.getColumns(); i++) {
					// sheet.getColumns()���ظ�ҳ��������
					for (int j = 0; j<sheet.getRows(); j++) {
						cellcontent[i][j] = sheet.getCell(i, j).getContents();
						
					}
				}
				
				
				
				//�ȼ����Ȩƽ��ֵ
				double total=0;
				double num1=0;
				double weightaverage;
				for(int p=1;p<sheet.getRows(); p++){
					score[p]=Double.parseDouble(cellcontent[9][p]);
					g[p]=Double.parseDouble(cellcontent[3][p]);
					if(score[p]<60){
						g[p]=0;
					}
					total+=score[p]*g[p];
					num1+=g[p];
				}
				weightaverage=total/num1;
				String w=String.valueOf(weightaverage);
				
				//����GPA��
				 double GPA[]=new double[rows];
				 double gpa;
				 double num2=0;
				 double num3=0;
				 for(int i =1; i<rows;i++)
				 {
					 if(score[i] >= 90 ) GPA[i] = 4.0;
						else if(score[i] >= 85) GPA[i] = 3.7;
						else if(score[i] >= 82) GPA[i] = 3.3;
						else if(score[i] >= 78) GPA[i] = 3.0;
						else if(score[i] >= 75) GPA[i] = 2.7;
						else if(score[i] >= 72) GPA[i] = 2.3;
						else if(score[i] >= 68) GPA[i] = 2.0;
						else if(score[i] >= 64) GPA[i] = 1.5;
						else if(score[i] >= 60) GPA[i] = 1.0;
						else GPA[i] = 0;
					 if(score[i]<60){
							g[i]=0;
						}
					    num2+=GPA[i]*g[i];
					    num3+=g[i];
				 }
				
				 gpa=num2/num3;
				 String g1=String.valueOf(gpa);
				 
				//�ɼ�����(ð������)
					
					String T=null;
					for(int i=1;i<sheet.getRows();i++){
						for(int j=i+1;j<sheet.getRows();j++){
							score[i]=Double.parseDouble(cellcontent[9][i]);//���»�ȡ�ı��ķ���ֵ
							if(score[i]<score[j]){
								
								for(int k=0;k<sheet.getColumns();k++){
									T=cellcontent[k][i];
									cellcontent[k][i]=cellcontent[k][j];
									cellcontent[k][j]=T;
								}
							}
						}
					}
				 
				 //����һ���±������źõ����뵽�ñ���
					
					WritableWorkbook newbook  =  Workbook.createWorkbook( new  File(filePath),
	                    book);
				  WritableSheet sheet1  =  newbook.createSheet( " testpaixu " ,  1 );
				  sheet1.addCell( new  Label( 10,  0 ,  "��Ȩƽ���ɼ� ��" ));
				  sheet1.addCell( new  Label( 10,  1 ,  w ));
				  sheet1.addCell( new  Label( 10,  2 ,  "��Ȩƽ��GPA�� " ));
				  sheet1.addCell( new  Label( 10,  3 ,  g1));
				  for(int i = 0; i<=9; i++)
					 {
						 for(int j = 0;j <rows; j++)
						 {
							 sheet1.addCell( new  Label( i,  j , cellcontent[i][j] ));
						 }
					 }
				  newbook.write();
		           newbook.close();
		           book.close();
				
		} catch (BiffException | IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		} catch (RowsExceededException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		} catch (WriteException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	
	


}
