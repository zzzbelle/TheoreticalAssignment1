package jimmy;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import java.io.IOException;
import java.io.FileOutputStream;  
  
import org.apache.poi.hssf.usermodel.HSSFCell;  
import org.apache.poi.hssf.usermodel.HSSFCellStyle;  
import org.apache.poi.hssf.usermodel.HSSFRow;  
import org.apache.poi.hssf.usermodel.HSSFSheet;  
import org.apache.poi.hssf.usermodel.HSSFWorkbook;  

public class JimmyGrade 
{
	public static void main(String[] args) throws IOException
	{
		// TODO Auto-generated method stub
		String[][] arr = new String[40][40];//�ɼ�������Ԫ����ɶ�ά����
		double[] credit = new double[25];//ѧ������
		double creditSum = 0.0;//ѧ�ֺ�
		double[] grade = new double[25];//�ɼ�����
		double gradeSum = 0;//�ɼ���
		double gradeAve = 0;//��Ȩƽ���ɼ�
		double[] gpa = new double[25];//GPA����
		double gpaSum = 0;//GPA��
		double gpaAve = 0;//��Ȩƽ��GPA
		//��ȡ�ɼ���
		String url ="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Tue%20Oct%2006%202015%2013:08:22%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		Document doc = Jsoup.connect(url).header("Cookie","JSESSIONID=0ADBC6DAA7436F3EF5A6F548EB163980.tomcat2").get();
		Elements trs = doc.select("table").select("tr");
        //��<td><tr>��ǩΪ��־��ȡ����
		for(int j = 0;j<trs.size();j++)
        {
            Elements tds = trs.get(j).select("td");
            for(int k = 0;k<tds.size();k++)
            {
            	arr[j][k] = tds.get(k).text();
            }
        }
		//ȡ��ÿ��ѧ�ֺͳɼ�
        for(int a = 1;a < 25;a++)
        {
        	credit[a-1] = Double.parseDouble(arr[a][3]);
        	creditSum += credit[a-1];
        	grade[a-1] = Double.parseDouble(arr[a][9]);
        	
        }
        //GPA����
        for(int b = 0;b < 25; b++)
        {
        	if(grade[b] < 60)
        	{
        		gpa[b] = 0.0;
        	}
        	if(grade[b] >= 60 && grade[b] <= 63)
        	{
        		gpa[b] = 1.0;
        	}
        	if(grade[b] >= 64 && grade[b] <= 67)
        	{
        		gpa[b] = 1.5;
        	}
        	if(grade[b] >= 68 && grade[b] <= 71)
        	{
        		gpa[b] = 2.0;
        	}
        	if(grade[b] >= 72 && grade[b] <= 74)
        	{
        		gpa[b] = 2.3;
        	}
        	if(grade[b] >= 75 && grade[b] <= 77)
        	{
        		gpa[b] = 2.7;
        	}
        	if(grade[b] >= 78 && grade[b] <= 81)
        	{
        		gpa[b] = 3.0;
        	}
        	if(grade[b] >= 82 && grade[b] <= 84)
        	{
        		gpa[b] = 3.3;
        	}
        	if(grade[b] >= 85 && grade[b] <= 89)
        	{
        		gpa[b] = 3.7;
        	}
        	if(grade[b] >= 90 && grade[b] <= 100)
        	{
        		gpa[b] = 4.0;
        	}
        	gpaSum += gpa[b]*credit[b];
        	gradeSum += grade[b]*credit[b];
        }
        gpaAve = gpaSum / creditSum;
        gradeAve = gradeSum / creditSum;

        	
        String[] temp = new String[10];
        double t;
        for (int i = 24; i > 0; --i)
        {
            for (int j = 0; j < i; ++j)
            {
                if (grade[j + 1] > grade[j])
                {
                    t = grade[j];
                    grade[j] = grade[j + 1];
                    grade[j + 1] = t;
                    for(int c = 1;c < 10;c++)
                    {
                    	temp[c] = arr[j + 1][c];
                    	arr[j + 1][c] = arr[j + 2][c];
                    	arr[j + 2][c] = temp[c];
                    }
                }
            }
        }	
        //����һ��webbook����Ӧһ��Excel�ļ�  
        HSSFWorkbook wb = new HSSFWorkbook();  
        //��webbook������һ��sheet,��ӦExcel�ļ��е�sheet  
        HSSFSheet sheet = wb.createSheet("�ɼ���");  
        //��sheet�����ӱ�ͷ��0��
        HSSFRow row = sheet.createRow((int) 0);  
        //������Ԫ�񣬲�����ֵ��ͷ ���ñ�ͷ����  
        HSSFCellStyle style = wb.createCellStyle();  
        style.setAlignment(HSSFCellStyle.ALIGN_CENTER); // ����һ�����и�ʽ  
  
        HSSFCell cell = row.createCell((short) 0);  
        cell.setCellValue("��ͷ��");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 1);  
        cell.setCellValue("�γ�����");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 2);  
        cell.setCellValue("�γ�����");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 3);  
        cell.setCellValue("ѧ��");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 4);  
        cell.setCellValue("��ʦ");  
        cell.setCellStyle(style);
        cell = row.createCell((short) 5);  
        cell.setCellValue("�ڿ�ѧԺ");  
        cell.setCellStyle(style);
        cell = row.createCell((short) 6);  
        cell.setCellValue("ѧϰ����");  
        cell.setCellStyle(style);
        cell = row.createCell((short) 7);  
        cell.setCellValue("ѧ��");  
        cell.setCellStyle(style);
        cell = row.createCell((short) 8);  
        cell.setCellValue("ѧ��");  
        cell.setCellStyle(style);
        cell = row.createCell((short) 9);  
        cell.setCellValue("�ɼ�");  
        cell.setCellStyle(style);
        cell = row.createCell((short) 10);  
        cell.setCellValue("GPA");  
        cell.setCellStyle(style);
        cell = row.createCell((short) 11);  
        cell.setCellValue("��Ȩƽ����");  
        cell.setCellStyle(style);
  
        //д��ʵ������
        for (int i = 1; i < 25; i++)  
        {  
            row = sheet.createRow((int) i + 1);    
            // ������Ԫ�񣬲�����ֵ  
            row.createCell((short) 0).setCellValue((String) arr[i][0]);  
            row.createCell((short) 1).setCellValue((String) arr[i][1]);  
            row.createCell((short) 2).setCellValue((String) arr[i][2]);  
            row.createCell((short) 3).setCellValue((String) arr[i][3]); 
            row.createCell((short) 4).setCellValue((String) arr[i][4]); 
            row.createCell((short) 5).setCellValue((String) arr[i][5]); 
            row.createCell((short) 6).setCellValue((String) arr[i][6]); 
            row.createCell((short) 7).setCellValue((String) arr[i][7]); 
            row.createCell((short) 8).setCellValue((String) arr[i][8]); 
            row.createCell((short) 9).setCellValue((String) arr[i][9]);  
        }  
        row.createCell((short) 10).setCellValue((double) gpaAve);
        row.createCell((short) 11).setCellValue((double) gradeAve);
        // ���ļ��浽ָ��λ��  
        try  
        {  
            FileOutputStream fout = new FileOutputStream("D:/JimmyGrade.xls");  
            wb.write(fout);  
            fout.close();  
        }  
        catch (Exception e)  
        {  
            e.printStackTrace();  
        }  
    }  
}
