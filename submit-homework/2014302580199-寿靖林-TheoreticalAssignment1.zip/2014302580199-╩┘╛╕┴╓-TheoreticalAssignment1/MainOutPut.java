import java.io.*;
import java.text.DecimalFormat;


public class MainOutPut {
	
	private String data[] = new String[40];
	private int grade[] = new int[40];
	private double credit[] = new double[40];
	private double GPA[] = new double[40];
	private int i = 0;  //�м�������
	
	public void processScoreTable(File input) throws IOException
	{
		FileReader fr = new FileReader(input);
		BufferedReader br = new BufferedReader(fr);
		
		data[i] = br.readLine(); //��ȡһ�е�����
		//���ж�ȡshuju
		while(data[i] != null)
		{
			i++;
			if(i>=40)
				break;
			data[i] = br.readLine();
			
		}
		
		br.close();
		fr.close();
		
		//sort
		sort();
		
		//�������ļ�
		File myFilePath = new File("TherreticalAssignment1_1.txt");   
		try {   
		    if (!myFilePath.exists()) {   
		        myFilePath.createNewFile();   
		    }   
		  //������д���ļ�
		    String strLine = System.getProperty("line.separator"); 
			try {   
			    FileWriter fw = new FileWriter(myFilePath); 
			    for(int j =0;j<i;j++)
			    {
			    	fw.write(data[j]);
			    	fw.write(strLine);
			    }
			    //���������̬
			    DecimalFormat df = new DecimalFormat( "0.0000 ");
			    //�����Ȩƽ����
			    fw.write("��Ȩƽ���֣�");
			    fw.write(String.valueOf(df.format(WeightedAverage())));
			    fw.write(strLine);
			    //����ۺ�gpa
			    fw.write("�ۺ�GPA�� ");
			    fw.write(String.valueOf(df.format(calculateGPA())));
			    fw.write(strLine);
			    
			    fw.flush();  
			    fw.close();    
			} catch (IOException e) {   
			    e.printStackTrace();   
			}   
		}   
		catch (Exception e) {   
		    System.out.println("�½��ļ���������");   
		    e.printStackTrace();   
		}    
		
		  
		
	}
	//����
	private void sort()
	{
		//get the grade of every lesson
		for(int j =0;j<i;j++)
		{
			int length = data[j].length();
			grade[j] = 
					Integer.valueOf(data[j].substring(length-2, length));
		}
		//sort
		for(int x=0;x<grade.length;x++)
		{
			for(int y = x+1;y<grade.length;y++)
			{
				if(grade[x]<grade[y])
				{
					int temp1;
					String temp2;
					//�����ɼ�
					temp1 = grade[x];
					grade[x] = grade[y];
					grade[y] = temp1;
					//�����ı�����
					temp2 = data[x];
					data[x] = data[y];
					data[y] = temp2;
				}
			}
		}
	}
	//�����Ȩƽ����
	private double WeightedAverage()
	{
		//get the credit of every lesson
		for(int j=0;j<i;j++)
		{
			int x=0;
			int k = 0;
			String sCredit = "";
			while(k<data[j].length())
			{
				char item = data[j].charAt(k);
				if(' ' == item || '\t' == item)
				{
					x++;
					while(' ' == item || '\t' == item)
					{
						k++;
						item = data[j].charAt(k);
					}
				}
				else k++;
				
				if(3 == x)
				{
					while(' ' != item && '\t' != item)
					{
						sCredit  = sCredit + item;
						k++;
						item = data[j].charAt(k);
					}
					credit[j] = Double.valueOf(sCredit);
				    break;
				}
			}
		}
		//�����
		double allCredit = 0;
		double sum = 0;
		for(int j =0;j<i;j++)
		{
			allCredit += credit[j];
			sum += credit[j]*grade[j];
		}
		return sum/allCredit;
	}
	//�����ۺϼ�ȨGPA
	private double calculateGPA()
	{
		double allGPA = 0;
		double allCredit = 0;
		for(int j =0;j<i;j++)
		{
			if(grade[j] >= 90)
				GPA[j] = 4.0;
			else if(grade[j] < 90 && grade[j] >= 85)
				GPA[j] = 3.7;
			else if(grade[j] < 85 && grade[j] >= 82)
				GPA[j] = 3.3;
			else if(grade[j] < 82 && grade[j] >= 78)
				GPA[j] = 3.0;
			else if(grade[j] < 78 && grade[j] >= 75)
				GPA[j] = 2.7;
			else if(grade[j] < 75 && grade[j] >= 72)
				GPA[j] = 2.3;
			else if(grade[j] < 72 && grade[j] >= 68)
				GPA[j] = 2.0;
			else if(grade[j] < 68 && grade[j] >= 64)
				GPA[j] = 1.5;
			else if(grade[j] < 64 && grade[j] >= 60)
				GPA[j] = 1.0;
			else if(grade[j] < 60)
				GPA[j] = 0;
		}
		for(int j=0;j<i;j++)
		{
			allGPA += credit[j] * GPA[j];
			allCredit += credit[j];
		}
		return allGPA / allCredit;
	}

}
