
import java.io.File;
import java.io.IOException;


public class MainPut {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
       MainOutPut outPut = new MainOutPut();
       String str = "theoreticalAssignment1.txt";
       File file = new File(str);
       outPut.processScoreTable(file);
	}

}
