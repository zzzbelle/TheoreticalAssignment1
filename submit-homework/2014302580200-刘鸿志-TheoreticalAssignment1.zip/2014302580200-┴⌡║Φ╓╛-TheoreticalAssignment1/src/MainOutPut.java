import java.io.File; 
import java.io.FileOutputStream;  
import java.io.IOException;  
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import java.io.*;
import jxl.*;
import jxl.write.*;

import org.jsoup.Jsoup;  
import org.jsoup.nodes.Document;  
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class MainOutPut 
{
	public static void main(String[] args) throws IOException
	{
		String fName ="scores.html";
		// TODO Auto-generated method stub
		/*
		* String url = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Fri%20Oct%2002%202015%2017:53:26%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		*HttpRequest response=HttpRequest.post(url).header("cookie","JSESSIONID=756AEB9EFE3CD093B7CC6B2EDA17E57C.tomcat2");
		*response.receive(new File(fName));
		*ע�͵Ĵ���Ϊԭ������cookies����ȡhtml�ļ��Ĵ��룬�����ļ��������ϴ���ҵ���µ�html�ļ���Ϊ����cookies���ڶ���Ҫ�������õ��鷳���ʽ���δ���ע�͵�
		*/
		processScoreTabel(new File(fName));
		
	}
	
	
	public static void processScoreTabel(File input) throws IOException
	{
		//��jsoup��html��ȡ�ɼ�
		input = new File("scores.html");
		Document doc = Jsoup.parse(input,"gb2312");
		Elements contentth = doc.getElementsByTag("th");
		Elements contenttd = doc.getElementsByTag("td");
		ArrayList<String> lesson = new ArrayList<String> ();
		ArrayList<String> scores = new ArrayList<String> ();
		ArrayList<String> grades = new ArrayList<String> ();
		
		for(int k = 0 ; k <= 285 ; k = k+11 )
		{ 
			lesson.add(contenttd.get(k+1).text());	
			scores.add(contenttd.get(k+3).text());
			grades.add(contenttd.get(k+9).text());
		}
		
		//�������ߵ�����
		ArrayList<Double> grade =  new ArrayList<Double> ();
		for(int k = 0 ; k<=25 ; k++)
		{
			grade.add(Double.parseDouble(grades.get(k)));
		}
		for(int p = 0 ; p <= 25 ; p++)
		{
			for(int k = 0 ; k <= 24 ; k++)
			{
				if(grade.get(k) - grade.get(k+1) < 0)
				{
					double change = grade.get(k);
					grade.set(k, grade.get(k+1));
					grade.set(k+1, change);
					
					String change1 = lesson.get(k);
					lesson.set(k, lesson.get(k+1));
					lesson.set(k+1, change1);
					
					String change2 = scores.get(k);
					scores.set(k, scores.get(k+1));
					scores.set(k+1, change2);
					
					String change3 = grades.get(k);
					grades.set(k, grades.get(k+1));
					grades.set(k+1, change3);
				}
			}
		}
		
		//��������Ϊgpa
		for(int k = 0;k<=25;k++)
		{
			if(grade.get(k)<= 100 && grade.get(k)>= 90)
			{
				grade.set(k, 4.0);
			}
			else if(grade.get(k) >= 85)
			{
				grade.set(k, 3.7);
			}
			else if(grade.get(k) >= 82)
			{
				grade.set(k, 3.3);
			}
			else if(grade.get(k) >= 78)
			{
				grade.set(k, 3.0);
			}
			else if(grade.get(k) >= 75)
			{
				grade.set(k, 2.7);
			}
			else if(grade.get(k) >= 72)
			{
				grade.set(k, 2.3);
			}
			else if(grade.get(k) >= 68)
			{
				grade.set(k, 2.0);
			}
			else if(grade.get(k) >= 64)
			{
				grade.set(k, 1.5);
			}
			else if(grade.get(k) >= 60)
			{
				grade.set(k, 1.0);
			}
			else
			{
				grade.set(k, 0.0);
			}
		}
		
		
		//����excel�ļ�
		try
		{
		WritableCellFormat wcf = new WritableCellFormat();  
	    wcf.setAlignment(Alignment.LEFT);//��ˮƽ���뷽ʽָ��Ϊ����
		WritableWorkbook book = Workbook.createWorkbook(new File("�ɼ���.xls"));
		WritableSheet sheet1=book.createSheet("�ɼ���",0);
		sheet1.mergeCells(0, 0, 2, 0);
		sheet1.addCell(new Label(0,0,contentth.get(1).text()));
		sheet1.addCell(new Label(3,0,contentth.get(3).text()));
		sheet1.addCell(new Label(4,0,contentth.get(9).text()));
		sheet1.addCell(new Label(5,0,"GPA"));
		for(int row = 1 ; row <= 26 ;row ++)
		{
			sheet1.mergeCells(0, row, 2, row);
			sheet1.addCell(new Label(0,row,lesson.get(row-1)));
			sheet1.addCell(new Label(3,row,scores.get(row-1)));
			sheet1.addCell(new Label(4,row,grades.get(row-1)));
			sheet1.addCell(new jxl.write.Number(5,row,grade.get(row-1)));	
		}
		sheet1.mergeCells(0, 27, 2, 27);
		sheet1.addCell(new Label(0,27,"��Ȩƽ��(ѧ��Ϊ��ѧ��)"));
		double sumofscores = 0.0;
		for(int k = 0 ; k <= 25 ; k++)
		{
			sumofscores = sumofscores + Double.parseDouble(scores.get(k));
		}
		sheet1.addCell(new jxl.write.Number(3,27,sumofscores,wcf));
		double weightedAverage = 0.0;
		for(int k = 0 ; k <= 25 ; k++)
		{
			weightedAverage = weightedAverage + Double.parseDouble(grades.get(k)) * Double.parseDouble(scores.get(k));
		}
		weightedAverage = weightedAverage / sumofscores;
		sheet1.addCell(new jxl.write.Number(4, 27, weightedAverage,wcf));
		double averageGPA = 0.0;
		for(int k = 0 ; k <= 25 ; k++)
		{
			averageGPA = averageGPA + grade.get(k) * Double.parseDouble(scores.get(k));
		}
		averageGPA = averageGPA / sumofscores;
		sheet1.addCell(new jxl.write.Number(5, 27, averageGPA));
				
		
		book.write();
		book.close();
		}catch(Exception e)
		{
		System.out.println(e);
		}
		
	}
}
	

