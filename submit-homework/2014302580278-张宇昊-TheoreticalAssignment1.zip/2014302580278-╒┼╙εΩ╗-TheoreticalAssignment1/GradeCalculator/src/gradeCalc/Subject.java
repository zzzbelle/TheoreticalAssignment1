package gradeCalc;

//����ѧ����
public class Subject {
	public String id; //��ͷ��
	public String subName; //�γ�����
	public String subType; //�γ�����
	public String credit; //ѧ��
	public String teaName; //��ʦ
	public String school; //�ڿ�ѧԺ
	public String stuType; //�ڿ�����
	public String year; //ѧ��
	public String term; //ѧ��
	public String score; //�ɼ�
	
	//���캯��
	public Subject(String a, String b, String c, String d, String e, String f, String g, String h, String i, String j){
		id = a;
		subName = b;
		subType = c;
		credit = d;
		teaName = e;
		school = f;
		stuType = g;
		year = h;
		term = i;
		score = j;
	}
	
	public String getSubName(){
		return subName;
	}
	public String getCredit(){
		return credit;
	}
	public String getScore(){
		return score;		
	}
	
	@Override
    public String toString()
    {
        return "id: " + id +
        	   "; subject: " + subName + 
        	   "; type: " + subType + 
        	   "; credit: " + credit + 
        	   "; teacher: " + teaName + 
        	   "; school: " + school + 
        	   "; study type: " + stuType + 
        	   "; year: " + year + 
        	   "; term: " + term + 
        	   "; score: " + score;
    }

}
