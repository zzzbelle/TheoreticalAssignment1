package gradeCalc;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class Parse {
	//�ֱ𴴽���Ч��Ŀ����Ч��Ŀ��ûѧ�꣩������
	public static ArrayList<Subject> list = new ArrayList<Subject>();
	public static ArrayList<Subject> listNull = new ArrayList<Subject>();

	public static Subject subHeader;//��ͷ
	
	//��ȡ��ҳ�еı��񣬽���Ŀ���浽Subject���������
	public static int parseTab(String fileName) throws IOException{
		
		Subject sub;
		
		//��ȡ��ҳ
		File file = new File(fileName);
		Document document = Jsoup.parse(file,"GB2312");
		
		//��ȡ����
        Element myTable = document.select("table[class=table listTable]").first();

        //��ȡ��ͷ����Ϊһ��Subject�����subHeader
        Iterator<Element> titleIte = myTable.select("th").iterator();
        subHeader = new Subject(titleIte.next().text(), titleIte.next().text(), titleIte.next().text(),
                titleIte.next().text(), titleIte.next().text(), titleIte.next().text(), titleIte.next().text(),
                titleIte.next().text(), titleIte.next().text(), titleIte.next().text());
        
        //��ȡ��Ŀ
        Iterator<Element> subjectIte = myTable.select("td").iterator();
        for(;subjectIte.hasNext();)
        {
            sub = new Subject(subjectIte.next().text(), subjectIte.next().text(), subjectIte.next().text(),
                    subjectIte.next().text(), subjectIte.next().text(), subjectIte.next().text(), subjectIte.next().text(),
                    subjectIte.next().text(), subjectIte.next().text(), subjectIte.next().text());
            
            if(sub.getScore().equals(""))
            	listNull.add(sub);
            else
            	list.add(sub);

            //�������İ�ť
            subjectIte.next();
        }
		return 0;
    }
	
}
