package gradeCalc;

import java.util.ArrayList;

public class Calc {
	
	//���ɼ�������ð���㷨
	public static int rank(ArrayList<Subject> list){
		for(int i = list.size() - 1; i > 0; --i){
			for(int j = 0; j < i; ++j){
				if(Double.parseDouble(list.get(j).getScore()) < Double.parseDouble(list.get(j+1).getScore())){
					Subject temp;
					temp = list.get(j);
					list.set(j, list.get(j+1));
					list.set(j + 1, temp);
				}
			}
		}
		return 0;
	}
	
	//�����Ȩƽ���ɼ�
	public static double averageScore(){
		double total = 0;
		double cre = 0;
		for(int i = 0; i < Parse.list.size(); i++){
			total += Double.parseDouble(Parse.list.get(i).getScore()) * Double.parseDouble(Parse.list.get(i).getCredit());
			cre += Double.parseDouble(Parse.list.get(i).getCredit());
		}
		return total / cre;
		
	}
	
	//����GPA
	public static double gpa(){
		double total = 0;
		double score = 0;
		double cre = 0;
		double gpa = 0;
		for(int i = 0; i < Parse.list.size(); i++){
			cre += Double.parseDouble(Parse.list.get(i).getCredit());
			score = Double.parseDouble(Parse.list.get(i).getScore());
			
			if(score>=90&&score<=100)
			{
				gpa = 4.0;
			}
			if(score>=85&&score<=89)
			{
				gpa = 3.7;
			}
			if(score>=82&&score<=84)
			{
				gpa = 3.3;
			}
			if(score>=78&&score<=81)
			{
				gpa = 3.0;
			}
			if(score>=75&&score<=77)
			{
				gpa = 2.7;
			}
			if(score>=72&&score<=74)
			{
				gpa = 2.3;
			}
			if(score>=68&&score<=71)
			{
				gpa = 2.0;
			}
			if(score>=64&&score<=67)
			{
				gpa = 1.5;
			}
			if(score>=60&&score<=63)
			{
				gpa = 1.0;
			}
			if(score<60)
			{
				gpa = 0;
			}
			total += gpa * Double.parseDouble(Parse.list.get(i).getCredit());
		}	
			return total / cre;
		
	}
	public static void doIt(){
		try{
			Parse.parseTab("table.html");
		}catch (Exception e){
			
		}
		
		try{
			MainOutPut.newXls("unprocessedTable.xls");
		}catch(Exception e){
			
		}
	}

	}

