package gradeCalc;

import java.io.File;
import java.io.FileOutputStream;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class MainOutPut {
	public static File unprocessedTable;
	
	//����processScoreTable�������ɴ������excel 
	public void processScoreTable (File input){
		Parse.list.clear();
		try{
			Parse.parseTab("table.html");
		}catch (Exception e){
			
		}
		
		Calc.rank(Parse.list);
		try{
			MainOutPut.newXls("processedTable.xls");
		}catch(Exception e){
			
		}
	}
		public static void newXls(String xlsName) throws Exception {
		//������һ��excelҳ��
		WritableWorkbook myXls = Workbook.createWorkbook(new FileOutputStream(xlsName));
        WritableSheet s1 = myXls.createSheet("table", 0);
	
        //����subHeader¼������һ��
        Label label1 = new Label(0,0,"��ͷ��");
		Label label2 = new Label(1,0,"�γ�����");
		Label label3 = new Label(2,0,"�γ�����");
		Label label4 = new Label(3,0,"ѧ��");
		Label label5 = new Label(4,0,"�γ̽�ʦ");
		Label label6 = new Label(5,0,"�ڿ�ѧԺ");
		Label label7 = new Label(6,0,"ѧϰ����");
		Label label8 = new Label(7,0,"ѧ��");
		Label label9 = new Label(8,0,"ѧ��");
		Label label0 = new Label(9,0,"����");
		
		s1.addCell(label1);
		s1.addCell(label2);
		s1.addCell(label3);
		s1.addCell(label4);
		s1.addCell(label5);
		s1.addCell(label6);
		s1.addCell(label7);
		s1.addCell(label8);
		s1.addCell(label9);
		s1.addCell(label0);

		//¼�����гɼ���ѧ������
        for (int i = 1; i < Parse.list.size(); i++)
        {
            Label label11 = new Label(0,i,Parse.list.get(i-1).id);
			Label label12 = new Label(1,i,Parse.list.get(i-1).subName);
			Label label13 = new Label(2,i,Parse.list.get(i-1).subType);
			Label label14 = new Label(3,i,Parse.list.get(i-1).credit);
			Label label15 = new Label(4,i,Parse.list.get(i-1).teaName);
			Label label16 = new Label(5,i,Parse.list.get(i-1).school);
			Label label17 = new Label(6,i,Parse.list.get(i-1).stuType);
			Label label18 = new Label(7,i,Parse.list.get(i-1).year);
			Label label19 = new Label(8,i,Parse.list.get(i-1).term);
			Label label20 = new Label(9,i,Parse.list.get(i-1).score);
				
			s1.addCell(label11);
			s1.addCell(label12);
			s1.addCell(label13);
			s1.addCell(label14);
			s1.addCell(label15);
			s1.addCell(label16);
			s1.addCell(label17);
			s1.addCell(label18);
			s1.addCell(label19);
			s1.addCell(label20);
        }

        //�����Ȩƽ����
        Label myLabel1 = new Label(0, Parse.list.size() , "��Ȩƽ����");
        s1.addCell(myLabel1);
        Label l1 = new Label(1, Parse.list.size() , Double.toString(Calc.averageScore()));
        s1.addCell(l1);

        //����GPA
        Label myLabel2 = new Label(0, Parse.list.size() + 1, "GPA");
        s1.addCell(myLabel2);
        Label l2 = new Label(1, Parse.list.size() + 1, Double.toString(Calc.gpa()));
        s1.addCell(l2);
				
		myXls.write();
		myXls.close();
			
			
	}
	}

