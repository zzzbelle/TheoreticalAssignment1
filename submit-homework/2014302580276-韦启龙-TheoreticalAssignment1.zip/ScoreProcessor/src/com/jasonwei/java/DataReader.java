package com.jasonwei.java;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;

/**
 * Created by Jason_Wei on 2015/10/2.
 */
public class DataReader
{
    private static DataReader reader = null;

    private DataReader() {}

    //Singleton pattern here
    public static DataReader getInstance()
    {
        if (reader == null)
        {
            reader = new DataReader();
            return reader;
        }
        else
            return reader;
    }

    public void processScores(String HTMLFile) throws Exception
    {
        //parse data from html fle
        readDataFromHTML(HTMLFile);

        //remove subjects which have a score (because the final exam hasn't come yet
        removeSubjectWithNoScore(Data.data);

        //rank from high to low
        descendingOrder(Data.data);

        //calculate average score and GPA, then store them in class Data
        calculateAverageScore(Data.data);
        calculateGPA(Data.data);
    }

    private void readDataFromHTML(String HTMLFile) throws Exception
    {
        //parse html file
        File file = new File(HTMLFile);
        Document document = Jsoup.parse(file, "GB2312");

        //parse table
        Element table = document.select("table[class=table listTable]").first();

        //parse titles of table
        Iterator<Element> titleIte = table.select("th").iterator();
        Data.title = new Subject(titleIte.next().text(), titleIte.next().text(), titleIte.next().text(),
                titleIte.next().text(), titleIte.next().text(), titleIte.next().text(), titleIte.next().text(),
                titleIte.next().text(), titleIte.next().text(), titleIte.next().text());

        //parse subjects
        Iterator<Element> subjectIte = table.select("td").iterator();
        while (subjectIte.hasNext())
        {
            Subject subject = new Subject(subjectIte.next().text(), subjectIte.next().text(), subjectIte.next().text(),
                    subjectIte.next().text(), subjectIte.next().text(), subjectIte.next().text(), subjectIte.next().text(),
                    subjectIte.next().text(), subjectIte.next().text(), subjectIte.next().text());

            Data.data.add(subject);  //store subject

            subjectIte.next();   //skip button in table
        }
    }

    private void removeSubjectWithNoScore(ArrayList<Subject> data)
    {
        ArrayList<Subject> temp = new ArrayList<>();

        Iterator<Subject> iterator = Data.data.iterator();
        while (iterator.hasNext())
        {
            Subject subject = iterator.next();
            if (subject.getScore().equals(""))
                continue;
            else
                temp.add(subject);
        }

        Data.data = temp;  //update data
    }

    private void calculateAverageScore(ArrayList<Subject> data)
    {
        DecimalFormat decimalFormat = new DecimalFormat("#.0000");

        double creditSum = 0.0, scoreSum = 0.0;

        Iterator<Subject> iterator = data.iterator();

        while (iterator.hasNext())
        {
            Subject subject = iterator.next();
            creditSum += Double.parseDouble(subject.getCredit());
            scoreSum += Double.parseDouble(subject.getScore()) * Double.parseDouble(subject.getCredit());
        }

        if (creditSum != 0.0)
            Data.averageScore = decimalFormat.format(scoreSum / creditSum);
    }

    private void calculateGPA(ArrayList<Subject> data)
    {
        DecimalFormat decimalFormat = new DecimalFormat("#.0000");

        double creditSum = 0.0, allCredit = 0.0;

        Iterator<Subject> iterator = data.iterator();

        while (iterator.hasNext())
        {
            Subject subject = iterator.next();
            if (Double.parseDouble(subject.getScore()) >= 90.0)
            {
                creditSum += 4.0 * Double.parseDouble(subject.getCredit());
                allCredit += Double.parseDouble(subject.getCredit());
            }
            else if (Double.parseDouble(subject.getScore()) >= 85.0 & Double.parseDouble(subject.getScore()) <= 89.0)
            {
                creditSum += 3.7 * Double.parseDouble(subject.getCredit());
                allCredit += Double.parseDouble(subject.getCredit());
            }
            else if (Double.parseDouble(subject.getScore()) >= 82.0 & Double.parseDouble(subject.getScore()) <= 84.0)
            {
                creditSum += 3.3 * Double.parseDouble(subject.getCredit());
                allCredit += Double.parseDouble(subject.getCredit());
            }
            else if (Double.parseDouble(subject.getScore()) >= 78.0 & Double.parseDouble(subject.getScore()) <= 81.0)
            {
                creditSum += 3.0 * Double.parseDouble(subject.getCredit());
                allCredit += Double.parseDouble(subject.getCredit());
            }
            else if (Double.parseDouble(subject.getScore()) >= 75.0 & Double.parseDouble(subject.getScore()) <= 77.0)
            {
                creditSum += 2.7 * Double.parseDouble(subject.getCredit());
                allCredit += Double.parseDouble(subject.getCredit());
            }
            else if (Double.parseDouble(subject.getScore()) >= 72.0 & Double.parseDouble(subject.getScore()) <= 74.0)
            {
                creditSum += 2.3 * Double.parseDouble(subject.getCredit());
                allCredit += Double.parseDouble(subject.getCredit());
            }
            else if (Double.parseDouble(subject.getScore()) >= 68.0 & Double.parseDouble(subject.getScore()) <= 71.0)
            {
                creditSum += 2.0 * Double.parseDouble(subject.getCredit());
                allCredit += Double.parseDouble(subject.getCredit());
            }
            else if (Double.parseDouble(subject.getScore()) >= 64.0 & Double.parseDouble(subject.getScore()) <= 67.0)
            {
                creditSum += 1.5 * Double.parseDouble(subject.getCredit());
                allCredit += Double.parseDouble(subject.getCredit());
            }
            else if (Double.parseDouble(subject.getScore()) >= 60.0 & Double.parseDouble(subject.getScore()) <= 63.0)
            {
                creditSum += 1.0 * Double.parseDouble(subject.getCredit());
                allCredit += Double.parseDouble(subject.getCredit());
            }
            else if (Double.parseDouble(subject.getScore()) < 60.0)
            {
                creditSum += 0.0 * Double.parseDouble(subject.getCredit());
                allCredit += Double.parseDouble(subject.getCredit());
            }
        }

        Data.GPA = decimalFormat.format(creditSum / allCredit);
    }

    private void descendingOrder(ArrayList<Subject> data)
    {
        data.sort(new SubjectComparator());
    }


    //define a comparator, it will be used to rank scores
    class SubjectComparator implements Comparator<Subject>
    {
        @Override
        public int compare(Subject subject1, Subject subject2)
        {
            if (Double.parseDouble(subject1.getScore()) < Double.parseDouble(subject2.getScore()))
                return 1;
            return -1;
        }
    }
}
