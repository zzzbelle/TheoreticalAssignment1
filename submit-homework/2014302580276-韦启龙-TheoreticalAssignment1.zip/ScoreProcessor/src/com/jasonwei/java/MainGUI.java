package com.jasonwei.java;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

/**
 * Created by Jason_Wei on 2015/10/2.
 */
public class MainGUI
{
    public static void main(String[] args)
    {

        JFrame window = new JFrame("ScoreProcessor v0.0.1");

        window.setResizable(false);  //window's size can't change

        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setSize(500, 500);

        try
        {
            window.setIconImage(ImageIO.read(new File("resources/icon.png")));   //set icon
        } catch (IOException e)
        {
            e.printStackTrace();
        }

        window.setVisible(true);
        window.setLayout(null);   //absolute layout

        JPanel bgContainer = new JPanel();
        window.add(bgContainer);
        bgContainer.setBounds(0, 0, 500, 500);
        JLabel bg = new JLabel(new ImageIcon("resources/background.png"));   //add background
        bgContainer.add(bg);
        bg.setBounds(0, 0, 500, 500);

        JButton calc = new JButton();
        calc.setText("Process Scores Now");
        bgContainer.add(calc);
        calc.setBounds(162, 190, 170, 50);
        calc.setFocusPainted(false);

        JButton output = new JButton();
        output.setText("Save To Excel Now");
        bgContainer.add(output);
        output.setBounds(162, 280, 170, 50);
        output.setFocusPainted(false);
        output.setEnabled(false);


        //click the button to calculate scores
        calc.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent event)
            {
                try
                {
                    DataReader.getInstance().processScores("./Scores.html");
                } catch (Exception e)
                {
                    e.printStackTrace();
                }
                output.setEnabled(true);

                JOptionPane.showConfirmDialog(null, "You have processed scores data successfully, now you can save it",
                        "Message", JOptionPane.CANCEL_OPTION);
            }
        });


        //click the button to save the result to xls file
        output.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent event)
            {
                try
                {
                    DataWriter.getInstance().writeDataToExcel(Data.data, "./OrderedScores.xls");
                } catch (Exception e)
                {
                    e.printStackTrace();
                }

                JOptionPane.showConfirmDialog(null, "Your data have been saved to \"OrderedScores.xls\", see root of your project directory",
                        "Message", JOptionPane.CANCEL_OPTION);
            }
        });
    }
}
