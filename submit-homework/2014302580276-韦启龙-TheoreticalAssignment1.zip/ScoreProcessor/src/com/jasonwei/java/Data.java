package com.jasonwei.java;

import java.util.ArrayList;

/**
 * Created by Jason_Wei on 2015/10/2.
 */
public class Data
{
    //data storage

    public static ArrayList<Subject> data = new ArrayList<>();
    public static Subject title = null;

    public static String averageScore = "";
    public static String GPA = "";
}
