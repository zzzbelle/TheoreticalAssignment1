package com.jasonwei.java;

/**
 * Created by Jason_Wei on 2015/10/2.
 */
public class Subject
{
    String[] item = new String[10];

    public Subject(String id, String name, String type, String credit, String teacher, String academy, String learnType,
            String year, String semester, String score)
    {
        item[0] = id;
        item[1] = name;
        item[2] = type;
        item[3] = credit;
        item[4] = teacher;                //init here
        item[5] = academy;
        item[6] = learnType;
        item[7] = year;
        item[8] = semester;
        item[9] = score;
    }

    public String getScore()
    {
        return item[9];
    }

    public String getCredit()
    {
        return item[3];
    }

    @Override
    public String toString()
    {
        return "id=" + item[0] + "&name=" + item[1] + "&type=" + item[2] + "&credit=" + item[3] + "&teacher=" + item[4] + "&academy=" +
                item[5] + "&learnType=" + item[6] + "&year=" + item[7] + "&semester=" + item[8] + "&score=" + item[9];
    }
}
