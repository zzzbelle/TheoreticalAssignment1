package com.jasonwei.java;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import java.io.FileOutputStream;
import java.util.ArrayList;

/**
 * Created by Jason_Wei on 2015/10/2.
 */
public class DataWriter
{
    private static DataWriter writer = null;

    private DataWriter() {}

    //Singleton pattern here
    public static DataWriter getInstance()
    {
        if (writer == null)
        {
            writer = new DataWriter();
            return writer;
        }
        else
            return writer;
    }

    public void writeDataToExcel(ArrayList<Subject> data, String xlsName) throws Exception
    {

        //create a new xls file
        WritableWorkbook workbook = Workbook.createWorkbook(new FileOutputStream(xlsName));
        WritableSheet sheet = workbook.createSheet("SHEET", 0);

        //add titles of all items
        for (int i = 0; i < 10; i++)
        {
            Label label = new Label(i, 0, Data.title.item[i]);
            sheet.addCell(label);
        }

        //add subjects and their child item
        for (int i = 1; i < data.size(); i++)
        {
            for (int j = 0; j < 10; j++)
            {
                Label label = new Label(j, i, data.get(i).item[j]);
                sheet.addCell(label);
            }
        }

        //add average score to xls file
        Label label1 = new Label(8, data.size() + 2, "加权平均分");
        sheet.addCell(label1);
        Label averageScoreLabel = new Label(9, data.size() + 2, Data.averageScore);
        sheet.addCell(averageScoreLabel);

        //add GPA to xls file
        Label label2 = new Label(8, data.size() + 3, "GPA");
        sheet.addCell(label2);
        Label GPALabel = new Label(9, data.size() + 3, Data.GPA);
        sheet.addCell(GPALabel);

        workbook.write();
        workbook.close();
    }
}
