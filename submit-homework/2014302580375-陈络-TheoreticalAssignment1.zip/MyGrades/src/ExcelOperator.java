import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;  
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WriteException;

public class ExcelOperator {

	public ExcelOperator() {
	}
	
	public static void operate()throws IOException, BiffException, WriteException{
		jxl.Workbook readwb=null;
		String path="grades.xls"; 
		InputStream instream = new FileInputStream(path); 
		readwb = Workbook.getWorkbook(instream);
		Sheet readsheet = readwb.getSheet(0); //获取第一页sheet
		
		//获取表格中除分数外所有信息
		String[][] m_imformation = new String[25][9];
		for(int i=0;i<25;i++){
			for(int j=0;j<9;j++){
				Cell cell=readsheet.getCell(j,i+1);
				m_imformation[i][j] = cell.getContents();
				/*String m=cell.getContents();
				System.out.println(m);*/
				
			}
		}
		//获取分及学分，grades[][0]储存分数，grades[][1]储存学分,grades[][2]储存gpa
		double[][] grades=new double[25][3];
		for(int i=0;i<25;i++){
			Cell cell=readsheet.getCell(9,i+1);
			grades[i][0] = Double.valueOf(cell.getContents()).doubleValue();
			cell=readsheet.getCell(3,i+1);
			grades[i][1] = Double.valueOf(cell.getContents()).doubleValue();
		}
		
	
		
		//通过分数对信息进行排序
		for(int i=0;i<25;i++){
			for(int j=0;j<24-i;j++){
				if(grades[j][0]<grades[j+1][0]){
					double bottle1=grades[j][0];
					double bottle2=grades[j][1];
					grades[j][0]=grades[j+1][0];
					grades[j][1]=grades[j+1][1];
					grades[j+1][0]=bottle1;
					grades[j+1][1]=bottle2;
					for(int num=0;num<9;num++){
						String bottle=m_imformation[j][num];
						m_imformation[j][num]=m_imformation[j+1][num];
						m_imformation[j+1][num]=bottle;
					}
					
				}
			}
		}
		
		//排序完毕再计算GPA
				for(int i=0;i<25;i++){
					if(grades[i][0]>=90)
						grades[i][2]=4.0;
					else if(grades[i][0]>=85)
						grades[i][2]=3.7;
					else if(grades[i][0]>=82)
						grades[i][2]=3.3;
					else if(grades[i][0]>=78)
						grades[i][2]=3.0;
					else if(grades[i][0]>=75)
						grades[i][2]=2.7;
					else if(grades[i][0]>=72)
						grades[i][2]=2.3;
					else if(grades[i][0]>=68)
						grades[i][2]=2.0;
					else if(grades[i][0]>=64)
						grades[i][2]=1.5;
					else if(grades[i][0]>=60)
						grades[i][2]=1.0;
					else if(grades[i][0]<60)
						grades[i][2]=0;
				}
		//计算加权平均分以及综合加权GPA
		double ave=0;//加权平均分
		double aveGPA=0;//加权GPA计算
		double sum1=0;
		double sum2=0;
		for(int i=0;i<25;i++){
			sum1+=grades[i][0]*grades[i][1];
			sum2+=grades[i][1];
		}
		ave=sum1/sum2;
		sum1=0;//将sum1中数据清零，sum2不需要改变
		for(int i=0;i<25;i++){
			sum1+=grades[i][2]*grades[i][1];			
		}
		aveGPA=sum1/sum2;
		
		
		//将重新排序获得的数据写入新建的Excel文件中
		
		/*OutputStream os = null;
		WritableWorkbook workbook = Workbook.createWorkbook(os);//创建工作簿
		WritableSheet ws = workbook.createSheet("Test Sheet 1",0);//创建表单
		*/
		jxl.write.WritableWorkbook wwb = Workbook.createWorkbook(new File(   
				  
                "grades(输出结果).xls"), readwb);
		jxl.write.WritableSheet ws = wwb.getSheet(0); //读取第一张工作表  
		/*jxl.write.WritableCell wc = ws.getWritableCell(0, 0); //获得第一个单元格对象
		if (wc.getType() == CellType.LABEL)    
			  
        {   

            Label l = (Label) wc;   

            l.setString("新姓名");   

        }   
        */
		
		
		for(int i=0;i<8;i++){
			for(int j=1;j<25;j++){
				Label label = new Label(i,j,m_imformation[j][i]); 
				ws.addCell(label); 
			}
		}
		for(int i=0;i<25;i++){
			String str;
			str = ""+grades[i][0];
			Label label = new Label(9,i+1,str); 
			ws.addCell(label); 
		}
		
		Label label2 = new Label(11,0,"加权平均分"); 
		ws.addCell(label2);
		String str1 = null;
		str1 = ""+ave;
		Label label3 = new Label(11,1,str1); 
		ws.addCell(label3);
		
		Label label4 = new Label(11,2,"加权GPA"); 
		ws.addCell(label4);
		String str2;
		str2 = ""+aveGPA;
		Label label5 = new Label(11,3,str2); 
		ws.addCell(label5);
		
         wwb.write();   
		  
         wwb.close();  
		
		/*workbook.write();
		*/
		
		
		/*for(int i=0;i<25;i++){
			for(int j=0;j<9;j++){
				System.out.print(m_imformation[i][j]+" ");
			}
			System.out.print(grades[i][0]+" ");
			System.out.print(grades[i][2]);
			System.out.println();
		}
		*/
		/*Cell cell=readsheet.getCell(0,0);
		String m = cell.getContents();
		
		System.out.println(m);*///
		
		
		
		
		
		
		
		/*System.out.println(rsColumns);
		System.out.println(rsRows);
		System.out.println(ave);
		System.out.println(aveGPA);
		*/
	}
}
