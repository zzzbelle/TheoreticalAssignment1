import java.io.File;
import java.io.IOException;

public class ReadMyGrade {

	public static void main(String[] args) throws IOException {
		// TODO �Զ����ɵķ������
//		File myGrade = new File("D:/Java/workspace/OOP-JAVA-CLASSTEST01/myGrade.xls");
		File myGrade = new File("./myGrade.xls");
		MainOutPut mainOutFile = new MainOutPut();
		mainOutFile.processScoreTable(myGrade);
		System.out.println("ok");
	}


	

}
