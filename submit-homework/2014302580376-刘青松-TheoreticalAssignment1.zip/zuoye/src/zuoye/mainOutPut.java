package zuoye;
import java.io.FileInputStream;  
import java.io.IOException;  
import java.io.InputStream;  

import jxl.Cell;  
import jxl.Sheet;  
import jxl.Workbook;  
import jxl.read.biff.BiffException;  

import java.io.*;

import jxl.CellType;  
import jxl.Workbook;  
import jxl.format.Alignment;  
import jxl.format.Border;  
import jxl.format.BorderLineStyle;  
import jxl.format.CellFormat;
import jxl.format.Colour;  
import jxl.format.ScriptStyle;  
import jxl.format.UnderlineStyle;  
import jxl.format.VerticalAlignment;  
import jxl.read.biff.BiffException;  
import jxl.write.Blank;  
import jxl.write.DateFormat;  
import jxl.write.DateFormats;  
import jxl.write.DateTime;  
import jxl.write.Formula;  
import jxl.write.Label;  
import jxl.write.Number;  
import jxl.write.NumberFormat;  
import jxl.write.WritableCell;  
import jxl.write.WritableCellFeatures;  
import jxl.write.WritableCellFormat;  
import jxl.write.WritableFont;  
import jxl.write.WritableHyperlink;  
import jxl.write.WritableImage;  
import jxl.write.WritableSheet;  
import jxl.write.WritableWorkbook;  
import jxl.write.WriteException;  
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.Label;
import jxl.write.Number;


  
public class mainOutPut {

	public static void main(String[] args)   throws  BiffException,IOException {
		// TODO �Զ����ɵķ������
		
		 String bookpath = "1.xls";  
		  InputStream bookstream = new FileInputStream(bookpath); 
		  Workbook book = Workbook.getWorkbook(bookstream);
		     book.getNumberOfSheets();  
		 Sheet sheet = book.getSheet(0);

		 int rows = sheet.getRows();//ȷ������
		 int columns =sheet.getColumns();//ȷ������
		 Cell cell = null;

		 
		 String[][] data = new String[rows][columns];//��ά����  
		 for(int i=0;i<rows-1;i++){
			 for(int j = 0; j<columns-1;j++){
				 cell = sheet.getCell(j,i);
				 data[i][j]= cell.getContents();
				 }}// ����  ���ݴ������ˣ�����
		 String[] temp = new String[columns];
		 int com;
		 for(int i=0;i<rows-1;i++){
			 for(int j =1;i+j<rows-1;j++){
				 com = data[i][9].compareTo(data[i+j][9]);
				 if(com<0){
					 for(int k=0;k<columns-1;k++){
					 temp [k]=data[i][k];
					 data[i][k]=data[i+j][k];
					 data[i+j][k]=temp[k];
					 }
					 
					 
				 }
				 
			 }
			 
		 }
		double [] xuefen = new double[rows];
		 double [] chengji = new double [rows];
		 double[] he = new double[rows];
		 for(int i = 0;i<24;i++){
		 chengji [i] = Double.parseDouble(data[i][9]);
		 xuefen [i] = Double.parseDouble(data[i][3]);
		he[i]=chengji[i]*xuefen[i];
		 }
		 double add= 0;double yes=0;double jqpjf=0;double gpa =0;
		 for(int i = 0;i<24;i++){
			 add = he[i]+add;
			 yes = xuefen [i]+yes;
		 }
		 jqpjf = add/yes;
		 gpa = jqpjf*4/100;
		 try {  
       
             String filePath = "2.xls";  
        
             WritableWorkbook wwb;  
 
             OutputStream os = new FileOutputStream(filePath);  
             wwb=Workbook.createWorkbook(os);   
      
             WritableSheet sheet1 = wwb.createSheet("1", 0);  
             Label label;  
           
        
        for(int a=0;a<24;a++){
        	for(int b=0;b<10;b++){
              label = new Label(b,a,data[a][b]);  
             sheet1.addCell(label);  
        	}
        	}
        String ak = "��Ȩƽ����="+jqpjf;
        String m4 = "gpa="+gpa;
           
          label = new Label(0,25,ak);
          sheet1.addCell(label);
          label = new Label(1,25,m4);
          sheet1.addCell(label);
     
      
               
        
            wwb.write();  
       
             wwb.close();  
  
         } catch (Exception e) {  
             System.out.println("---�����쳣---");  
              e.printStackTrace();  
        }  
 
	        
	        
	        System.out.println(gpa);
		
}}