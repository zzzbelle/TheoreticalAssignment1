
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.io.*;







//������ӿ�
public class MainOutPut {
	
	private static String path = "";
	private static File source,destination;
	private static ArrayList<Data>  data;
	
	public static void main(String [] args)
	{
		
	 try{
	 System.out.println("������html�ļ���:(1.html)");
		System.out.println(" ");
		
		 BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
	 path=in.readLine();
	 
	 }catch(IOException e){System.out.println("�����쳣");} 
	
	
	source = new File(path);
	processScoreTable(source);
	
	
	}
	//input �������html�ļ���
public static void processScoreTable(File input)
	{
	
	 
	     
		data = InOutPut.Input(input);
		InOutPut.sort(data);//����
		double Score[] = SortAndCalc.Calc(data);
		destination = new File("Myscores.xls");
		InOutPut.Output(data, destination);
		System.out.println("GPA="+Score[1]);
		System.out.println("��Ȩƽ����="+Score[0]);
	}
	
}
