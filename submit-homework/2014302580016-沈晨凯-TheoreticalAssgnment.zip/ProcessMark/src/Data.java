
public class Data {

	//���幹�췽��
	public Data(long numOfObject, String nameOfObject, String typeOfObject, double credit,
			String nameOfTeacher, String nameOfAcademy, String typeOfStudy, int year, String term,
			 double mark) 
	{
		// TODO Auto-generated constructor stub
		//����ʼֵ
		this.numOfObject = numOfObject;
		this.nameOfObject = nameOfObject;
		this.typeOfObject = typeOfObject;
		this.credit = credit;
		this.nameOfTeacher = nameOfTeacher;
		this.nameOfAcademy = nameOfAcademy;
		this.typeOfStudy = typeOfStudy;
		this.year = year;
		this.term = term;
		this.mark = mark;
	}
	
	/*
	 * ���ʮ�����ݵ�ֵ
	 */
	
	public double getMark() {
		return mark;
	}
	
	public long getNumOfObject() {
		return numOfObject;
	}
	
	public String getNameOfObject() {
		return nameOfObject;
	}
	
	public String getTypeOfObject(){
		return typeOfObject;
	}
	
	public double getCredit(){
		return credit;
	}
	
	public String getNameOfTeacher(){
		return nameOfTeacher;
	}
	
	public String getNameOfAcademy(){
		return nameOfAcademy;
	}
	
	public String getTypeOfStudy(){
		return typeOfStudy;
	}
	
	public int getYear(){
		return year;
	}
	
	public String getTerm(){
		return term;
	}
	
	
	private long numOfObject;				//��ͷ��
	private String nameOfObject;			//�γ�����
	private String typeOfObject;				//�γ�����
	private double credit;						//ѧ��
	private String nameOfTeacher;			//��ʦ
	private String nameOfAcademy;		//�ڿ�ѧԺ
	private String typeOfStudy;				//ѧϰ����
	private int year;								//ѧ��
	private String term;							//ѧ��
	private double mark;						//�ɼ�
}
