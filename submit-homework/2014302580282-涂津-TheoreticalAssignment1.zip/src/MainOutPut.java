/**
 * Created by terry on 15-10-5.
 */

import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.*;
import java.util.ArrayList;

public class MainOutPut {
    /**
     * 读取html文件内容*/
    private String readHtmlContent(String fileName) {
        InputStream is = null;
        String content = "";
        try {
            is = new FileInputStream(fileName);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"), 512);
            for (String line = reader.readLine(); line != null; line = reader.readLine()) {
                line = line.trim();
                content += line;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                if (is != null) {
                    is.close();
                    is = null;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return content;
    }

    /**
     * 计算单科绩点*/
    private double getGPA(double grade){
        if (grade >= 90)
            return 4.0;
        else if (grade <= 89 && grade >= 85)
            return 3.7;
        else if (grade <= 84 && grade >= 82)
            return 3.3;
        else if (grade <= 81 && grade >= 78)
            return 3.0;
        else if (grade <= 77 && grade >= 75)
            return 2.7;
        else if (grade <= 74 && grade >= 22)
            return 2.3;
        else if (grade <= 71 && grade >= 68)
            return 2.0;
        else if (grade <= 67 && grade >= 64)
            return 1.5;
        else if (grade <= 63 && grade >= 60)
            return 1.0;
        else
            return 0;
    }

    /**
     * 将html内容写入excel文件*/
    public void writeToExcel(String fileName, String excelName){
        /**
         * Jsoup解析*/
        //所有的课程
        ArrayList<ArrayList<String>> classes = new ArrayList<ArrayList<String>>();

        //表头
        ArrayList<String> firstRow = new ArrayList<String>();

        String result = readHtmlContent(fileName);
        Document doc = Jsoup.parse(result);
        Element table = doc.select("table").get(0);
        Elements rows = table.select("tr");
        Elements ths = rows.get(0).select("th");

        //excel中的第一行
        for (int i = 0; i != ths.size() - 1; i++){
            firstRow.add(ths.get(i).text());
        }

        //第一项不是课程，跳过
        for (int i = 1; i != rows.size(); i++){
            Element row = rows.get(i);
            Elements cols = row.select("td");
            ArrayList<String> temp = new ArrayList<String>();
            for (int j = 0; j < cols.size(); j++){
                temp.add(j, cols.get(j).text());
            }
            classes.add(temp);
        }

        //删除非本学期的课程
        ArrayList<ArrayList<String>> nullClasses = new ArrayList<ArrayList<String>>();
        for (int i = 0; i != classes.size(); i++){
            //System.out.println(i + ":" + classes.get(i).get(9));
            if (classes.get(i).get(9).length() == 0){
                nullClasses.add(classes.get(i));
            }
        }
        classes.removeAll(nullClasses);

        //根据分数排序
        for (int i = classes.size() - 1; i >= 0; i--){
            for (int j = 0; j != i; j++){
                if (Double.valueOf(classes.get(i).get(9)) > Double.valueOf(classes.get(j).get(9))){
                    ArrayList<String> temp = new ArrayList<String>();
                    temp = classes.get(i);
                    classes.set(i,classes.get(j));
                    classes.set(j,temp);
                }
            }
        }

        /**
         * excel操作*/
        try {
            //设置单元格居中
            WritableCellFormat cellFormat = new WritableCellFormat();
            cellFormat.setAlignment(jxl.format.Alignment.CENTRE);

            //新建excel
            WritableWorkbook book = Workbook.createWorkbook(new File(excelName));
            WritableSheet sheet = book.createSheet("first page",0);

            //写入第一行
            for (int i = 0; i != firstRow.size(); i++){
                //Label第一个参数是列，第二个参数是行
                Label label = new Label(i, 0, firstRow.get(i));
                label.setCellFormat(cellFormat);
                sheet.addCell(label);
            }

            //写入课程
            for (int i = 0; i != classes.size(); i++){
                for (int j = 0; j != classes.get(0).size(); j++){
                    Label label = new Label(j, i + 1, classes.get(i).get(j));
                    label.setCellFormat(cellFormat);
                    sheet.addCell(label);
                }
            }

            //保存Excel文件
            book.write();
            book.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (WriteException e) {
            e.printStackTrace();
        }
    }

    /**
     * 读取Excel内容并进行处理*/
    public void processScoreTable(File input){
        try {
            WritableCellFormat cellFormat = new WritableCellFormat();
            cellFormat.setAlignment(jxl.format.Alignment.CENTRE);

            Workbook wb = Workbook.getWorkbook(input);
            WritableWorkbook book = Workbook.createWorkbook(input, wb);
            WritableSheet sheet =book.getSheet(0);

            //总学分
            double totalStudyGrades = 0;
            //加权平均分
            double averageGrades = 0;
            //加权GPA
            double GPA = 0;
            //分数乘以学分的和
            double totalGrades = 0;
            //GPA乘以学分的和
            double temp = 0;
            for (int i = 1; i != sheet.getRows(); i++){
                totalStudyGrades += Double.valueOf(sheet.getCell(3,i).getContents());
                totalGrades += Double.valueOf(sheet.getCell(3,i).getContents()) * Double.valueOf(sheet.getCell(9,i).getContents());
                temp += Double.valueOf(sheet.getCell(3,i).getContents()) * getGPA(Double.valueOf(sheet.getCell(9,i).getContents()));
            }
            averageGrades = totalGrades / totalStudyGrades;
            GPA = temp / totalStudyGrades;


            Label label1 = new Label(sheet.getColumns() - 1, 0, "加权平均分");
            label1.setCellFormat(cellFormat);
            sheet.addCell(label1);
            Label label2 = new Label(sheet.getColumns() - 1, 1, String.valueOf(averageGrades));
            label2.setCellFormat(cellFormat);
            sheet.addCell(label2);
            Label label3 = new Label(sheet.getColumns(), 0, "综合加权GPA");
            label3.setCellFormat(cellFormat);
            sheet.addCell(label3);
            Label label4 = new Label(sheet.getColumns() - 1, 1, String.valueOf(GPA));
            label4.setCellFormat(cellFormat);
            sheet.addCell(label4);

            book.write();
            book.close();

            } catch (IOException e) {
                e.printStackTrace();
            } catch (BiffException e) {
                e.printStackTrace();
            } catch (WriteException e) {
                e.printStackTrace();
            }
    }
}