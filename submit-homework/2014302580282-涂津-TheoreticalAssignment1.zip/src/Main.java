import java.io.File;

/**
 * Created by terry on 15-10-7.
 */

public class Main {
    public static void main(String args[]){
        MainOutPut app = new MainOutPut();
        app.writeToExcel("result.html", "result.xls");
        app.processScoreTable(new File("result.xls"));
    }
}
