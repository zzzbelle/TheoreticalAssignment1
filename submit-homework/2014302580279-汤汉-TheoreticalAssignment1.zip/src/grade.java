import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.awt.font.ImageGraphicAttribute;
import java.io.*;
import java.net.URL;
import java.util.*;

import org.python.netty.util.IllegalReferenceCountException;
import org.python.util.*;
/**
 * Created by tanghan on 15-10-6.
 */
public class grade {
    public static void main(String args[]) throws IOException {
        //存储成绩的结构体。。。好怀恋C++
        class Course {
            public String courseHeaderNumber;
            public String courseName;
            public String courseType;
            public String courseCredits;
            public String courseTeacher;
            public String courseCollege;
            public String courseStudyType;
            public String courseYear;
            public String courseTerm;
            public String courseGrade;
            double getGPA() {
                double temp = Double.parseDouble(courseGrade);
                double gpa = 0;
                if (temp >= 90 && temp <= 100) gpa = 4.0;
                if (temp >= 85 && temp < 90) gpa = 3.7;
                if (temp >= 80 && temp < 85) gpa = 3.4;
                if (temp >= 75 && temp < 80) gpa = 3.1;
                if (temp >= 70 && temp < 75) gpa = 2.8;
                if (temp >= 60 && temp < 70) gpa = 2.5;
                return gpa;
            }

        }



        final String userAgent = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.36";
        //获取验证码，人工识别输入
        URL imgUrl = new URL("http://210.42.121.132/servlet/GenImg");
        HttpRequest imgReq = HttpRequest.get(imgUrl);
        //存放地址
        File img = new File("./captcha.jpg");
        imgReq.receive(img);
        String imgCookie = imgReq.header("Set-Cookie");
        String imgSessionId = imgCookie.substring(0, imgCookie.indexOf(";"));
        System.out.println(imgSessionId);
        //输入验证码号，POST入服务端
        Scanner picScanner = new Scanner(System.in);
        System.out.println("输入验证码(验证码图片名为captcha)：");
        String picData = picScanner.nextLine();
        //String picData = null;


        //使用HTTPRequest进行网页登录验证
        Map<String, String> data = new HashMap<String, String>();
        data.put("id", "2014302580279");
        data.put("pwd", "19940404");
        data.put("xdvfb", picData);
        URL loginUrl = new URL("http://210.42.121.132/servlet/Login");
        //提交获取验证码照片的cookie
        HttpRequest loginReq = HttpRequest.post(loginUrl).header("Cookie", imgSessionId).form(data);
        //精致重定向
        loginReq.followRedirects(false);
        loginReq.body();

        Connection.Response res = Jsoup.connect("http://210.42.121.132/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0")
                .header("Cookie", imgSessionId)
                .method(Connection.Method.GET).execute();

        //Jsoup  解析HTML文件
        File gradeHtml = new File("./grade.html");
        Document doc = Jsoup.parse(gradeHtml, "gb2312");
        doc.select("input").remove();
        //获取表头
        Elements th = doc.getElementsByTag("th");
        //String thead = th.html();
        ArrayList<String> tharr = new ArrayList<String>();
        int thcount = 1;
        for(Element m : th){
            if(thcount == 11){ break;}
            tharr.add(m.text());
            thcount ++;
        }

        Elements td = doc.getElementsByTag("td");
        td.select("tr").select("td.input").removeAttr("class");

        //读取数据存储
        ArrayList<Course> coursearr = new ArrayList<Course>();
        ArrayList<String> strarr = new ArrayList<String>();
        int i = 1;
        for (Element temp : td) {
            if (i <= 264) {
                strarr.add(temp.text());
                i++;
            }
        }
        //以对像形式保存
        for (int m = 0; m != 264; m++) {
            Course course = new Course();
            course.courseHeaderNumber = strarr.get(m);
            course.courseName = strarr.get(m + 1);
            course.courseType = strarr.get(m + 2);
            course.courseCredits = strarr.get(m + 3);
            course.courseTeacher = strarr.get(m + 4);
            course.courseCollege = strarr.get(m + 5);
            course.courseStudyType = strarr.get(m + 6);
            course.courseYear = strarr.get(m + 7);
            course.courseTerm = strarr.get(m + 8);
            course.courseGrade = strarr.get(m + 9);
            coursearr.add(course);
            m += 10;
        }
        //排序
        for (int m = 0; m != coursearr.size(); m++) {
            for (int n = 0; n != coursearr.size(); n++) {
                if (Double.valueOf(coursearr.get(m).courseGrade).doubleValue() >= Double.valueOf(coursearr.get(n).courseGrade).doubleValue()) {
                    Course temp = new Course();
                    temp = coursearr.get(m);
                    coursearr.set(m, coursearr.get(n));
                    coursearr.set(n, temp);
                }
            }
        }



        //计算加权GPA和平均分
        double totalCredit = 0;
        double gradeCredit = 0;
        double gpaCredit = 0;
        for (Course m : coursearr) {
            totalCredit += Double.valueOf(m.courseCredits).doubleValue();
            gradeCredit += Double.valueOf(m.courseCredits).doubleValue() * Double.valueOf(m.courseGrade).doubleValue();
            double gpa = m.getGPA();
            if (gpa >= 2.5) {
                gpaCredit += gpa * Double.valueOf(m.courseCredits).doubleValue();
            }else{ break;}
        }
        double averageCredit = gradeCredit / totalCredit;
        double averageGPA = gpaCredit/totalCredit;

        //创建一个excel文档对象
        HSSFWorkbook workbook = new HSSFWorkbook();
        HSSFSheet sheet= workbook.createSheet("grade");
        Map<String, Object[]> info = new HashMap<String,Object[]>();
        info.put(0+"", new Object[]{tharr.get(0),tharr.get(1),tharr.get(2),tharr.get(3),tharr.get(4),tharr.get(5),tharr.get(6),tharr.get(7),tharr.get(8),tharr.get(9)});
        int tempcount = 0;

        for(Course c : coursearr){
            info.put((tempcount+1)+"",new Object[]{c.courseHeaderNumber,c.courseName,c.courseType,c.courseCredits,c.courseTeacher,c.courseCollege,c.courseStudyType,c.courseYear,c.courseTerm,c.courseGrade});
            System.out.println(c.courseGrade);
            tempcount ++;
        }
        int maxrow = coursearr.size();
        int maxcol = 10;
        Row head = sheet.createRow(0);
        for(int j=0;j!=maxcol;j++){
            Cell cell = head.createCell(j);
            cell.setCellType(Cell.CELL_TYPE_STRING);
            cell.setCellValue(tharr.get(j));
        }
        for(int rownum=1;rownum<maxrow+2;rownum++) {
            Row row = sheet.createRow(rownum);
            int colcount = 0;
            if (rownum <= 23) {
                for (int j = 0; j != maxcol; j++) {
                    Cell cell = row.createCell(j);
                    cell.setCellType(Cell.CELL_TYPE_STRING);
                    switch (j) {
                        case 0:
                            cell.setCellValue(coursearr.get(rownum).courseHeaderNumber);
                            break;
                        case 1:
                            cell.setCellValue(coursearr.get(rownum).courseName);
                            break;
                        case 2:
                            cell.setCellValue(coursearr.get(rownum).courseType);
                            break;
                        case 3:
                            cell.setCellValue(coursearr.get(rownum).courseCredits);
                            break;
                        case 4:
                            cell.setCellValue(coursearr.get(rownum).courseTeacher);
                            break;
                        case 5:
                            cell.setCellValue(coursearr.get(rownum).courseCollege);
                            break;
                        case 6:
                            cell.setCellValue(coursearr.get(rownum).courseStudyType);
                            break;
                        case 7:
                            cell.setCellValue(coursearr.get(rownum).courseYear);
                            break;
                        case 8:
                            cell.setCellValue(coursearr.get(rownum).courseTerm);
                            break;
                        case 9:
                            cell.setCellValue(coursearr.get(rownum).courseGrade);
                            break;
                    }
                }
            }else{
                switch(rownum){
                    case 24:
                        Cell cell = row.createCell(0);
                        cell.setCellType(Cell.CELL_TYPE_STRING);
                        cell.setCellValue("平均分数");
                        Cell creditcell = row.createCell(1);
                        creditcell.setCellType(Cell.CELL_TYPE_STRING);
                        creditcell.setCellValue(averageCredit);
                        break;
                    case 25:
                        Cell gpacell = row.createCell(0);
                        gpacell.setCellType(Cell.CELL_TYPE_STRING);
                        gpacell.setCellValue("平均GPA");
                        Cell avercell = row.createCell(1);
                        avercell.setCellType(Cell.CELL_TYPE_STRING);
                        avercell.setCellValue(averageGPA);
                        break;
                }
            }
        }


        try {
            FileOutputStream out = new FileOutputStream(new File("./grade.xsl"));
            workbook.write(out);
            out.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}