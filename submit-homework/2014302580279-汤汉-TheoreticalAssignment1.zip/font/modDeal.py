import Image 
import os

for imgFile in os.listdir("."):
	if imgFile.endswith(".png"):
		temp = imgFile.replace(' ','')
		os.rename(imgFile,temp)
		print temp
