package excel;
import java.io.File;
import java.io.IOException;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.Number;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException; 
import jxl.format.UnderlineStyle;   
import jxl.write.*;   
 

public class MainOutPut {
    public MainOutPut(){
    	
    }
	public  void processScoreTable(File input) throws BiffException, IOException, RowsExceededException, WriteException {
		// TODO Auto-generated method stub
          Workbook wb= Workbook.getWorkbook(input);
          Sheet sheet1 = wb.getSheet(0);//��óɼ�����
          //int numCols = sheet1.getColumns();
          int numRows = sheet1.getRows(); 
          Information a[]=new Information[numRows-1]; //������������洢����
          for(int i=0;i<numRows-1;i++){
        	  a[i]=new Information();
          }
          for(int i=1;i<numRows;i++){                //����ѭ���洢���б�������
        	    Cell c0 = sheet1.getCell(0,i);
        	    a[i-1].num = c0.getContents();
        	    c0=null;
        	    
        	    Cell c1 = sheet1.getCell(1,i);
        	    a[i-1].name = c1.getContents();
        	    c1=null;
        	    
        	    Cell c2 = sheet1.getCell(2,i);
        	    a[i-1].lesson=c2.getContents();
        	    c2=null;
        	    
        	    Cell c3 = sheet1.getCell(3,i);
        	    a[i-1].credit=Double.parseDouble(c3.getContents());
        	    c3=null;
        	   
        	    Cell c4 = sheet1.getCell(4,i);
        	    a[i-1].teacher=c4.getContents();
        	    c4=null;
        	    
        	    Cell c5 = sheet1.getCell(5,i);
        	    a[i-1].place=c5.getContents();
        	    c5=null;
        	    
        	    Cell c6 = sheet1.getCell(6,i);
        	    a[i-1].type=c6.getContents();
        	    c6=null;
        	    
        	    Cell c7 = sheet1.getCell(7,i);
        	    a[i-1].year=Integer.parseInt(c7.getContents());
        	    c7=null;
        	    
        	    Cell c8 = sheet1.getCell(8,i);
        	    a[i-1].term=c8.getContents();
        	    c8=null;
        	    
        	    Cell c9 = sheet1.getCell(9,i);
        	    a[i-1].grade=Double.parseDouble(c9.getContents());
        	    c9=null;
        	    
        	    Cell c10 = sheet1.getCell(10,i);
        	    a[i-1].gpa=Double.parseDouble(c10.getContents());
        	    c10=null;
        	  
	      }
          int x,y,big;
          x=numRows-2;
          while(x>0){
        	  big=0;
        	  for(y=0;y<x;y++)
        		  if(a[y+1].grade>a[y].grade){
        			  Information b;
        			  b=a[y];a[y]=a[y+1];a[y+1]=b;b=null;
        			  big=y;
        		  }
        	  x=big;
          }
          //�����ѧ��
          double sigmaCredit=0;
          for(int i=0;i<numRows-1;i++){
        	  sigmaCredit+=a[i].credit;
          }
          //�����Ȩƽ����
          double sumGrade=0;
          for(int i=0;i<numRows-1;i++){
        	  sumGrade+=a[i].credit*a[i].grade;
          }
          sumGrade=sumGrade/sigmaCredit;
          //�����ȨGPA
          double sumGPA=0;
          for(int i=0;i<numRows-1;i++){
        	  sumGPA+=a[i].credit*a[i].gpa;
          }
          sumGPA=sumGPA/sigmaCredit;
          
           WritableWorkbook workbook = Workbook.createWorkbook(new File("output.xls"));
		   //����һ��Sheet��������������Ϊparam0;λ��Ϊparam1
		   WritableSheet sheet = workbook.createSheet("grade", 0);
		   
		   //����һ��Label��x����param0��y����param1������Ϊparam2
		   WritableFont times16font = new WritableFont(WritableFont.TIMES, 13, WritableFont.BOLD, false);//��Ԫ���ʽ
		   WritableCellFormat times16format = new WritableCellFormat (times16font);
		   
		   Label label0 = new Label(0,0, "��ͷ��",times16format);
		   Label label1 = new Label(1, 0, "�γ�����",times16format);
		   Label label2= new Label(2, 0, "�γ�����",times16format);
		   Label label3 = new Label(3, 0, "ѧ��",times16format);
		   Label label4 = new Label(4, 0, "��ʦ",times16format);
		   Label label5 = new Label(5, 0, "�ڿ�ѧԺ",times16format);
		   Label label6 = new Label(6, 0, "ѧϰ����",times16format);
		   Label label7 = new Label(7, 0, "ѧ��",times16format);
		   Label label8 = new Label(8, 0, "ѧ��",times16format);
		   Label label9 = new Label(9, 0, "�ɼ�",times16format);
		   Label label10 = new Label(10, 0, "GPA",times16format);
		   times16format.setAlignment(jxl.format.Alignment.CENTRE);//��Ԫ����ж���
		   
		   //����Label�������ݵ�sheet����
		   sheet.addCell(label0);label0=null;
		   sheet.addCell(label1);label1=null;
		   sheet.addCell(label2);label2=null;
		   sheet.addCell(label3);label3=null;
		   sheet.addCell(label4);label4=null;
		   sheet.addCell(label5);label5=null;
		   sheet.addCell(label6);label6=null;
		   sheet.addCell(label7);label7=null;
		   sheet.addCell(label8);label8=null;
		   sheet.addCell(label9);label9=null;
		   sheet.addCell(label10);label10=null;
		   
		   sheet.setColumnView(0, 12); // �����еĿ���
		   for(int i=1;i<numRows;i++){
			   Label num=new Label(0,i,a[i-1].num);
			   sheet.addCell(num);
			   num=null;
		   }
		   sheet.setColumnView(1, 22); // �����еĿ���
		   for(int i=1;i<numRows;i++){
			   Label name=new Label(1,i,a[i-1].name);
			   sheet.addCell(name);
			   name=null;
		   }
		   sheet.setColumnView(2, 11); // �����еĿ���
		   for(int i=1;i<numRows;i++){
			   
			   jxl.write.WritableFont wfcNav =new jxl.write.WritableFont(WritableFont.ARIAL,10);
		        WritableCellFormat wcfN=new WritableCellFormat(wfcNav);
		        wcfN.setAlignment(Alignment.CENTRE); //����ˮƽ����
		        
			   Label lesson=new Label(2,i,a[i-1].lesson,wcfN);
			   sheet.addCell(lesson);
			   lesson=null;
		   }
		   //����һ��Number��x����param0��y����param1����ֵΪparam2
		   sheet.setColumnView(3,6); // �����еĿ���
		   for(int i=1;i<numRows;i++){
			   Number credit=new Number(3,i,a[i-1].credit);
			   sheet.addCell(credit);
			   credit=null;
		   }
		   for(int i=1;i<numRows;i++){
			   Label teacher=new Label(4,i,a[i-1].teacher);
			   sheet.addCell(teacher);
			   teacher=null;
		   }
		   sheet.setColumnView(5, 12); // �����еĿ���
		   for(int i=1;i<numRows;i++){
				   Label place=new Label(5,i,a[i-1].place);
				   sheet.addCell(place);
				   place=null;
			   }
		   sheet.setColumnView(6,11); // �����еĿ���
		   for(int i=1;i<numRows;i++){
			   jxl.write.WritableFont wfcNav =new jxl.write.WritableFont(WritableFont.ARIAL,10);
		        WritableCellFormat wcfN=new WritableCellFormat(wfcNav);
		        wcfN.setAlignment(Alignment.CENTRE); //����ˮƽ����
		        
			   Label type=new Label(6,i,a[i-1].type,wcfN);
			   sheet.addCell(type);
			   type=null;
		   }
		   sheet.setColumnView(7,6); // �����еĿ���
		   for(int i=1;i<numRows;i++){
			   
			   jxl.write.WritableFont wfcNav =new jxl.write.WritableFont(WritableFont.ARIAL,10);
		        WritableCellFormat wcfN=new WritableCellFormat(wfcNav);
		        wcfN.setAlignment(Alignment.CENTRE); //����ˮƽ����
		        
			   Number year=new Number(7,i,a[i-1].year,wcfN);
			   sheet.addCell(year);
			   year=null;
		   }
		   sheet.setColumnView(8,6); // �����еĿ���
		   for(int i=1;i<numRows;i++){
			   
			   jxl.write.WritableFont wfcNav =new jxl.write.WritableFont(WritableFont.ARIAL,10);
		        WritableCellFormat wcfN=new WritableCellFormat(wfcNav);
		        wcfN.setAlignment(Alignment.CENTRE); //����ˮƽ����
		        
			   Label term=new Label(8,i,a[i-1].term,wcfN);
			   sheet.addCell(term);
			   term=null;
		   }
		   sheet.setColumnView(9,6); // �����еĿ���
		   for(int i=1;i<numRows;i++){
			   Number grade1=new Number(9,i,a[i-1].grade);
			   sheet.addCell(grade1);
			   grade1=null;
		   }
		   sheet.setColumnView(10,6); // �����еĿ���
		   for(int i=1;i<numRows;i++){
			   Number GPA=new Number(10,i,a[i-1].gpa);
			   sheet.addCell(GPA);
			   GPA=null;
		   }
		   
		       jxl.write.WritableFont wfcNav =new jxl.write.WritableFont(WritableFont.ARIAL,12, WritableFont.BOLD,false,UnderlineStyle.NO_UNDERLINE,jxl.format.Colour.BLACK);
		       WritableCellFormat wcfN=new WritableCellFormat(wfcNav);
		       wcfN.setBackground(jxl.format.Colour.YELLOW);
		       
		       Number sumGrade1=new Number(9,numRows,sumGrade,wcfN);
			   sheet.addCell(sumGrade1);
			   sumGrade1=null;
			   
			   jxl.write.WritableFont wfcNav1 =new jxl.write.WritableFont(WritableFont.ARIAL,12, WritableFont.BOLD,false,UnderlineStyle.NO_UNDERLINE,jxl.format.Colour.WHITE);
		       WritableCellFormat wcfN1=new WritableCellFormat(wfcNav);
		       wcfN1.setBackground(jxl.format.Colour.BLUE);
		       
		       Number sumGPA1=new Number(10,numRows,sumGPA,wcfN1);
			   sheet.addCell(sumGPA1);
			   sumGPA1=null;
			   
           workbook.write();
		   workbook.close();
          
		   
	}

}

