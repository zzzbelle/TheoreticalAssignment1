package excel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

import jxl.read.biff.BiffException;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

class CreateGui extends JFrame implements ActionListener {
private JButton jb = new JButton("����") ;
     CreateGui() {
     super("�ɼ�������") ;
     setBounds(200,200,400,300);
     this.add(jb) ;//���Ӱ�ť

    jb.addActionListener(this) ;//��ť�¼�����
    jb.setBounds(0,0,400,300);
    jb.setIcon(new ImageIcon("img/i.jpg"));
    
    //����
   //this.pack();
   this.setLayout(null);
   this.setVisible(true);//�ɼ�
   this.setResizable(false);//�����޸Ĵ�С
   this.setLocation(100, 100);//��ʼλ��
}

//��дActionListener�ӿ��е��¼���������

@Override
   public void actionPerformed(ActionEvent e) {
   if(e.getSource() == jb) {
	    MainOutPut x=new MainOutPut();
	    File grade=new File("src"+File.separator+"excel"+File.separator+"grade.xls");
	    try {
			x.processScoreTable(grade);
		} catch (RowsExceededException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (BiffException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (WriteException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
//�¼�����
}
}

}

