package excel;

public class Information {
       public String num;
       public String name;
       public String lesson;
       public double credit;
       public String teacher;
       public String place;
       public String type;
       public int year;
       public String term;
       public double grade;
       public double gpa;
       public Information() {
    	   
	}

}
