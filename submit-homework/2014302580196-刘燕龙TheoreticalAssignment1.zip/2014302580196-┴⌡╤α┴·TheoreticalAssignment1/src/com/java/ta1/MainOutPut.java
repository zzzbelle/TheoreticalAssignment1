package com.java.ta1;

import java.io.BufferedReader;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainOutPut {
	public void processScoreTable(File input) {
		//��list���洢ÿһ�ſγ̳ɼ�
		List<Transcript> list = null;
		
		//��Ӧ�Ĳ�����
		BufferedReader br = null;
		BufferedWriter bw = null;
		
		//��try����catch����finally��֤��Ӧ�����ر�
		try {
			//����Ŀ���ļ�
			File orderedTranscript = new File("orderedTranscript.txt");
			list = new ArrayList<Transcript>();
			br = new BufferedReader(new FileReader(input));
			bw = new BufferedWriter(new FileWriter(orderedTranscript));
			
			//���ַ��������洢�ļ�
			char[] c = new char[2000];
			br.read(c);
			
			//���������ļ����������е���Ϣ����list��
			int len = 0;
			int count = 0;
			String string = null;
			Transcript t = new Transcript();
			for (int i = 0; i < c.length; i++) {
				if (c[i] == '\0') {
					break;
				}
				if (c[i] != '\t' && c[i] != '\n') {
					len++;
				}
				if (c[i] == '\t' || c[i] == '\n') {
					string = new String(c, i - len, len);
					switch (count % 10) {
					case 0:
						t.setClassHead(string);
						break;
					case 1:
						t.setClassName(string);
						break;
					case 2:
						t.setClassType(string);
						break;
					case 3:
						t.setCredit(string);
						break;
					case 4:
						t.setTeacher(string);
						break;
					case 5:
						t.setTeachingInstitute(string);
						break;
					case 6:
						t.setLearningType(string);
						break;
					case 7:
						t.setYear(string);
						break;
					case 8:
						t.setSemester(string);
						break;
					case 9:
						t.setGrade(string);
						break;
					}
					count++;
					if (c[i] == '\n') {
						Transcript temp = new Transcript(t);
						list.add(temp);

					}
					len = 0;
				}
			}
			
			// ��ѧ��
			double sumCredit = 0;
			//ѧ����ɼ�֮��֮��
			double sumCC = 0;
			//ѧ����G��֮��֮��
			double sumGPA = 0;
			
			//���������Ե��ü���G��ķ���
			CountGPA cGPA = new CountGPA();

			Collections.sort(list);
			for (Transcript t1 : list) {
				bw.write(t1.classHead + "\t" + t1.className + "\t"
						+ t1.classType + "\t" + t1.credit + "\t" + t1.teacher
						+ "\t" + t1.teachingInstitute + "\t" + t1.learningType
						+ "\t" + t1.year + "\t" + t1.semester + "\t" + t1.grade
						+ "\n");
				bw.flush();
				sumCredit += Double.parseDouble(t1.credit);
				sumCC += Double.parseDouble(t1.credit)
						* Double.parseDouble(t1.grade);
				sumGPA += cGPA.getGPA(Double.parseDouble(t1.grade))
						* Double.parseDouble(t1.credit);
			}
			//��������ݸ�ʽ��д���ļ���
			java.text.DecimalFormat df = new java.text.DecimalFormat("#.00");
			bw.write("��Ȩƽ����" + "\t\t\t\t\t\t\t\t\t"
					+ df.format(sumCC / sumCredit) + "\n" + "��ȨGPA"
					+ "\t\t\t\t\t\t\t\t\t" + df.format(sumGPA / sumCredit));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			//�ر���Ӧ����
			if (bw != null) {
				try {
					bw.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
