package com.java.ta1;

import java.io.File;

//������
public class Handle {
	public static void main(String[] args) {
		MainOutPut m1 = new MainOutPut();
		File input = new File("transcript.txt");
		m1.processScoreTable(input);
	}
}
