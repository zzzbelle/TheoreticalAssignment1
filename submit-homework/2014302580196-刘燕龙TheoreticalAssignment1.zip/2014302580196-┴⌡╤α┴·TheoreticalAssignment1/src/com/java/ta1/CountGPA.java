package com.java.ta1;

//���ݳɼ�������Ӧ��GPA
public class CountGPA {
	public double getGPA(double d) {
		if(90 <= d && d <= 100) {
			return 4.0;
		}else if(85<=d&&d<=89) {
			return 3.7;
		}else if(82<=d&&d<=84) {
			return 3.3;
		}else if(75<=d&&d<=77) {
			return 2.7;
		}else if(72<=d&&d<=74) {
			return 2.3;
		}else if(68<=d&&d<=71) {
			return 2.0;
		}else if(64<=d&&d<=67) {
			return 1.5;
		}else if(60<=d&&d<=63) {
			return 1.0;
		}else {
			return 0;
		}
	}
}
