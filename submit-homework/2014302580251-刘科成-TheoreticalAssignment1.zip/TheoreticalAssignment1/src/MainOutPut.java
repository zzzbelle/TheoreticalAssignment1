import java.io.File;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.lang.String;

public class MainOutPut {
	
	
	
	public static void main(String[] args)throws Exception{
		
			//���ļ�
			String fileContent="";
		 	File f=new File("D:\\workspace\\TheoreticalAssignment1\\abc.txt");
		 	InputStreamReader read=new InputStreamReader(new FileInputStream(f),"utf-16");
		 	BufferedReader reader=new BufferedReader(read);
		 	String line;
	        while((line=reader.readLine())!=null){
	            fileContent+=line;
	            fileContent+="|";
	           
	        }
	        System.out.println(fileContent);
	        read.close();
	        //����γ̶�������
	        String sArr[]=fileContent.split("\\|");
	        Course[] cs=new Course[sArr.length];
	        for(int i=0;i<sArr.length;i++){
	        	String cn=sArr[i].split(":")[0];
	        	String scoreString=sArr[i].split(":")[1];
	        	int cm=Integer.parseInt(scoreString.split(",")[0]);
	        	double ch=Double.parseDouble(scoreString.split(",")[1]);
	        	MainOutPut p=new MainOutPut();
	        	cs[i]=p.new Course(cn, cm, ch);
	        	
	        }
	        //����
	        int n=cs.length;
			for(int i=0;i<n-1;i++){
				for(int j=0;j<n-i-1;j++){
					if((cs[n-j-1].courseMark)>(cs[n-j-2].courseMark)){
						MainOutPut m=new MainOutPut();
						Course temp=m.new Course(null,0,0);
						temp=cs[n-j-2];
						cs[n-j-2]=cs[n-j-1];
						cs[n-j-1]=temp;
					}
				}
			}
			
	        double average=getAverage(cs);
	        double finalGPA=getGPA(cs);
	        
	        
	        String newFileContent="";
	        for(int i=0;i<cs.length;i++)
	        	newFileContent=newFileContent+cs[i].courseName+" "+Integer.toString(cs[i].courseMark)+" "+Double.toString(cs[i].creditHour);
	        newFileContent+="��Ȩƽ����"+Double.toString(average);
	        newFileContent+="�ۺϼ�ȨGPA"+Double.toString(finalGPA);
	        writeFile("newFile.txt",newFileContent);
	       

	}
	
	//�����γ���
	class Course {
		public String courseName;	//�γ���
		public int courseMark;		//����
		public double creditHour;	//ѧ��
		
		public Course(String courseName,int courseMark,double creditHour){
			this.courseName=courseName;
			this.courseMark=courseMark;
			this.creditHour=creditHour;
			}
		
	
	}
	
	//���Ȩƽ����
	public static double getAverage(Course a[]){
		double allCredit=0;
		double allMark=0;
		for(int i=0;i<a.length;i++){
			allCredit+=a[i].creditHour;
			allMark+=a[i].creditHour*a[i].courseMark;
		}
		return allMark/allCredit;
	}
	
	//���ۺϼ�ȨGPA
	public static double getGPA(Course a[]){
		double sum=0;
		double allCredit=0;
		double GPA=0;
		for(int i=0;i<a.length;i++){
			if(a[i].courseMark<=100&&a[i].courseMark>=90)
				GPA=4.0;
			else if(a[i].courseMark<90&&a[i].courseMark>=85)
				GPA=3.7;
			else if(a[i].courseMark<85&&a[i].courseMark>=82)
				GPA=3.3;
			else if(a[i].courseMark<82&&a[i].courseMark>=78)
				GPA=3.0;
			else if(a[i].courseMark<78&&a[i].courseMark>=75)
				GPA=2.7;
			else if(a[i].courseMark<75&&a[i].courseMark>=72)
				GPA=2.3;
			else if(a[i].courseMark<72&&a[i].courseMark>=68)
				GPA=2.0;
			else if(a[i].courseMark<68&&a[i].courseMark>=64)
				GPA=1.5;
			else if(a[i].courseMark<64&&a[i].courseMark>=60)
				GPA=2.3;
			allCredit+=a[i].creditHour;
			sum+=a[i].creditHour*GPA;
		}
		return sum/allCredit;
	}
	
	//д���ļ�
	public static void writeFile(String fileName,String fileContent){
		
		try {
			File f=new File(fileName);
			OutputStreamWriter write=new OutputStreamWriter(new FileOutputStream(f),"utf-16");
			BufferedWriter writer=new BufferedWriter(write);
			write.write(fileContent);
			write.close();
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		
	}

}
