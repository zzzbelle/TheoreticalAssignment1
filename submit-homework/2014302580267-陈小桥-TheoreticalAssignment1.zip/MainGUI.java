import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

import jxl.write.WriteException;

public class MainGUI extends Frame{
	
	
	private static final long serialVersionUID = 1L;

	public static void main(String[]args) throws IOException{
		Button btn=new Button("���ɳɼ��ļ�") ;
		Frame fr=new Frame("�ɼ�");
		
		
		
		fr.setLayout(new FlowLayout(FlowLayout.CENTER,20,40));
		fr.add(btn);
		fr.setSize(200, 200);
		fr.setVisible(true);
		fr.addWindowListener(new WindowAdapter(){
			  public void windowClosing(WindowEvent e){
			   System.exit(0);
			   }
		});
		
		btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				GradeSort a=new GradeSort("C:/Users/cxq/Desktop/study/java/��ү/Assignment1/С��/��ҵ/�ɼ�-student1.html");
				try {
					a.input();
				} catch (WriteException | IOException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				
			}
		});
	}
		}





