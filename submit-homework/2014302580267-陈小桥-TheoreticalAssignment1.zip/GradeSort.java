
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;


public class GradeSort {
	private String ad;

	
	GradeSort(String a){
		this.ad=a;
	}
	
	
	public void input() throws RowsExceededException, WriteException, IOException{
		
		File input = new File(this.ad); 
		Document doc = Jsoup.parse(input,"GB2312");//����html�ļ�
		Elements trs=doc.getElementsByTag("tr");//��ȡ�����ж���trs
		String[][]s=new String[trs.size()][11];//�½��ַ������飬�����ģ������size��׼����ű�ͷ��Ԫ��
		String[]subject=new String[11];//�½��ַ������飬�����ģ������size��׼����ű�ͷ��Ԫ��
				
		Elements tds;
		int count=0;
		for(int i=0;i<trs.size();i++){
			if(i==0){
				tds=trs.get(0).getElementsByTag("th");//��ȡ��һ�����е�Ԫ�����tds
			}
			else{
				tds = trs.get(i).getElementsByTag("td");
			}
			for(int j=0;j<tds.size();j++){
				Element td=tds.get(j);
				subject[j]=td.text();
			}
			if(!(subject[9].equals(""))){
				for(int j=0;j<11;j++){
					s[i][j]=subject[j];
					
				}
				count++;
			}
		}
	
		
		
		boolean sorted=false;
		String temp;
		while(!sorted){
			sorted=true;
			for(int i=2;i<count;i++){
				if(s[i][9] == null || "".equals(s[i][9])){s[i][9] = "0.0";}
				if(Float.parseFloat(s[i-1][9])<(Float.parseFloat(s[i][9]))){
					for(int l=0;l<11;l++){
						temp=s[i][l];
						s[i][l]=s[i-1][l];
						s[i-1][l]=temp;
					}
					sorted=false;
				}
			}
		}
		
		
		float creditSum=0;
		
		double GPASum=0;
		double average=0;
		double GPA=0;
		float sum=0;
		double eachGPA;
		int notPass=0;
		DecimalFormat decimalFormat = new DecimalFormat("#0.0000");
		for(int i=1;i<count;i++){
			if(Float.parseFloat(s[i][9])>=60.0)
			creditSum=creditSum+Float.parseFloat(s[i][3]);
			else
				notPass++;
		}
		for(int i=1;i<count;i++){
			if(Float.parseFloat(s[i][9])>=60.0)
			sum=sum+Float.parseFloat(s[i][3])*Float.parseFloat(s[i][9]);
		}
		average=Double.parseDouble(decimalFormat.format(sum/creditSum));
		
		for(int i=1;i<count;i++){
			if(Float.parseFloat(s[i][9])<60)
				continue;
			else if(Float.parseFloat(s[i][9])>=60&&Float.parseFloat(s[i][9])<=63)
				eachGPA=1.0;
			else if(Float.parseFloat(s[i][9])>=64&&Float.parseFloat(s[i][9])<=67)
				eachGPA=1.5;
			else if(Float.parseFloat(s[i][9])>=68&&Float.parseFloat(s[i][9])<=71)
				eachGPA=2.0;
			else if(Float.parseFloat(s[i][9])>=72&&Float.parseFloat(s[i][9])<=74)
				eachGPA=2.3;
			else if(Float.parseFloat(s[i][9])>=75&&Float.parseFloat(s[i][9])<=77)
				eachGPA=2.7;
			else if(Float.parseFloat(s[i][9])>=78&&Float.parseFloat(s[i][9])<=81)
				eachGPA=3.0;
			else if(Float.parseFloat(s[i][9])>=82&&Float.parseFloat(s[i][9])<=84)
				eachGPA=3.3;
			else if(Float.parseFloat(s[i][9])>=85&&Float.parseFloat(s[i][9])<=89)
				eachGPA=3.7;
			else 
				eachGPA=4.0;
			GPASum=GPASum+eachGPA*Float.parseFloat(s[i][3]);
				
		}
		GPA=Double.parseDouble(decimalFormat.format(GPASum/creditSum));
		
		
		
		WritableWorkbook wwb=Workbook.createWorkbook(new File("C:/Users/cxq/Desktop/�ҵĳɼ���.xls"));
		WritableSheet sheet=wwb.createSheet("�ҵĳɼ���",0);
		
		for(int i=0;i<s.length;i++){
			for(int j=0;j<11;j++){
				Label label=new Label(j,i,s[i][j]);
				sheet.addCell(label);
			}
		}
		sheet.addCell(new Label(0,count,"����ѧ�֣�"));
		sheet.addCell(new Label(1,count,String.valueOf(creditSum)));
		sheet.addCell(new Label(0,count+1,"�������Ŀ����"));
		sheet.addCell(new Label(1,count+1,String.valueOf(notPass)));
		sheet.addCell(new Label(0,count+2,"��Ȩƽ����"));
		sheet.addCell(new Label(1,count+2,String.valueOf(average)));
		sheet.addCell(new Label(0,count+3,"GPA"));
		sheet.addCell(new Label(1,count+3,String.valueOf(GPA)));
		wwb.write();
		wwb.close();
	
	
	
	}
	
	
	public static void main(String[]args){
		
	}
}


