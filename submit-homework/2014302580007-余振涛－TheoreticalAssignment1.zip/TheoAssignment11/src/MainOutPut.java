import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;


public class MainOutPut {
	
	private static String [] [] str = new String[99] [99];
    private static float average;//加权平均分
    private static float gpa;//gpa
	private static float total=0;//分数总分
	private static float gpoint;
	private static float grademcredit= 0;
	private static float tocredit;//总学分

	public static List<String[][]> readExcel(File excelFile,int rowNum)
			throws BiffException,IOException{
						//创建list存储成绩数据
						List <String[][]>list = new ArrayList<String[][]>();
						Workbook rwb = null;
						//创建输入流
						InputStream stream = new FileInputStream(excelFile);
						//获取excel文件对象
						rwb = Workbook.getWorkbook(stream);
						//获取文件的指定工作表
						Sheet sheet = rwb.getSheet(0);
						//行数
						for(int i = rowNum-1;i<sheet.getRows();i++){
							for(int j = 0 ; j<sheet.getColumns();j++){
								str[i][j]=sheet.getCell(j,i).getContents();
							}
						}
						list.add(str);
						return list;
						}

	
	
	public static void processScoreTable(File input){

		
		try {
			List<String[][]>list = MainOutPut.readExcel(input, 1);
			for(int i = 0;i<list.size();i++){
			String[][] str = (String[][])list.get(i);
			//对分数进行排序 未出分数的成绩暂不记录
			//只对出分数的24门进行比较
			//直接选择排序
			for(int n=0;n<=23;n++){
				int index = 0;
				for(int j=0;j<=23-n;j++){
					if(Integer.valueOf(str[j][9])<Integer.valueOf(str[index][9]))
					{
						index = j;
					}
				}
				String[] temp = str[23-n];
				str[23-n] =str[index];
				str[index] = temp;
			}
			//计算加权平均分
			
			for(int k=0;k<24;k++){
				total= total+ Integer.valueOf(str[k][9]);
				}
			average = total/24; 
			}
			
			//计算gpa
			for(int l= 0;l<24;l++){
			if(Float.valueOf(str[l][9])>=90)
				gpoint = (float) 4.0;
			else if (Float.valueOf(str[l][9])>=85&&Float.valueOf(str[l][9])<90)
				gpoint = (float) 3.7;
			else if (Float.valueOf(str[l][9])>=82&&Float.valueOf(str[l][9])<85)
				gpoint = (float) 3.3;
			else if (Float.valueOf(str[l][9])>=78&&Float.valueOf(str[l][9])<82)
				gpoint = (float) 3.0;
			else if (Float.valueOf(str[l][9])>=75&&Float.valueOf(str[l][9])<78)
				gpoint = (float) 2.7;
			else if (Float.valueOf(str[l][9])>=72&&Float.valueOf(str[l][9])<75)
				gpoint = (float) 2.3;
			else if (Float.valueOf(str[l][9])>=68&&Float.valueOf(str[l][9])<72)
				gpoint = (float) 2.0;
			else if (Float.valueOf(str[l][9])>=64&&Float.valueOf(str[l][9])<68)
				gpoint = (float) 1.5;
			else if (Float.valueOf(str[l][9])>=60&&Float.valueOf(str[l][9])<64)
				gpoint = (float) 1.0;
			else if (Float.valueOf(str[l][9])<60)
				gpoint = 0;
			
			tocredit = tocredit + Float.valueOf(str[l][3]);
			grademcredit = grademcredit+ gpoint*Float.valueOf(str[l][3]);
			
			}
			gpa = grademcredit/tocredit;
			
		//将处理好的数据写入新的excel中	
			WritableWorkbook wwb = Workbook.createWorkbook(new File("grade.xls"));
			WritableSheet ws = wwb.createSheet("grade", 0);

			
			for(int i = 0;i<10;i++){
				for(int j=0;j<24;j++){
				 Label	label = new Label(i,j,str[j][i]);
		
					try {
						ws.addCell(label);
					} catch (WriteException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			
			}
			Label label1 = new Label(0,24,"平均分");
			try {
				ws.addCell(label1);
			} catch (WriteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Label label2 = new Label(1,24,String.valueOf(average));
			try {
				ws.addCell(label2);
			} catch (WriteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Label label3 = new Label(2,24,"绩点");
			try {
				ws.addCell(label3);
			} catch (WriteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Label label4 = new Label(3,24,String.valueOf(gpa));
			try {
				ws.addCell(label4);
			} catch (WriteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			wwb.write();
			try {
				wwb.close();
			} catch (WriteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (BiffException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
	}
		
public static void main(String args[]){
	
	File input = new File("chengji1.xls");
	processScoreTable(input);
	
}
}
