import java.io.*;
import java.lang.NumberFormatException;

import jxl.*;
import jxl.write.*;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;



public class ExcelTest {
	private static int [] gradeArray = new int[100];//Declare a integer array to store the grade.
	private static double sumCredit = 0;//Declare a double to store the sum of the credits.
	private static int sumGrade = 0;//Declare a integer to store the sum of the grades.
	private static double gpa = 0;
	private static double weightAverage = 0;
	private static double []creditArray = new double[100];

	public static void main(String[]args) throws BiffException, IOException{
		
		//Regard "File.separator" as "/" to read the path of its file.
		File input = new File("src"+File.separator+"excel"+File.separator+"myGrade.et");
		
		//Invoke the method to process the data in the file.
		processScoreTable(input);
		
	
	}
	
	//Declare a method to transfer string into integer.
	public static int turnIntoInt(String str){
		int grade = Integer.parseInt(str);
		return grade;
	}
	
	//Declare a method to calculate GPA.
	public static double calculateGPA(){
		int length = gradeArray.length;
		double GPA = 0;
		for(int i = 0;i<length;i++){
			if(gradeArray[i]>=90){
				GPA += 4.0*creditArray[i];
			}
			else if(gradeArray[i]>=85){
				GPA += 3.7*creditArray[i]; 
			}
			else if(gradeArray[i]>=82){
				GPA += 3.3*creditArray[i];
			}
			else if(gradeArray[i]>=78){
				GPA += 3.0*creditArray[i];
			}
			else if(gradeArray[i]>=75){
				GPA += 2.8*creditArray[i];
			}
			else if(gradeArray[i]>=72){
				GPA += 2.3*creditArray[i];
			}
			else if(gradeArray[i]>=68){
				GPA += 2.0*creditArray[i];
			}
			else if(gradeArray[i]>=64){
				GPA += 1.5*creditArray[i];
			}
			else if(gradeArray[i]>=60){
				GPA += 1.0*creditArray[i];
			}
			else{
				GPA += 0*creditArray[i];
			}
		}
		GPA = GPA/sumCredit;
		return GPA;
	}
	
	
	//Declare a method to sort the class information according to the grades from the largest one to the smallest one.
	public static void sortClassInfor(ClassInfor [] object){
		for(int i=0;i<gradeArray.length-1;i++){
			for(int j=0;j<gradeArray.length-i-1;j++){
				if(gradeArray[j]<gradeArray[j+1]){
					int temp = gradeArray[j];
					gradeArray[j] = gradeArray[j+1];
					gradeArray[j+1] = temp;
					
					String temp1 = object[j].classNumber;
					object[j].classNumber = object[j+1].classNumber;
					object[j+1].classNumber = temp1;
					
					String temp2 = object[j].className;
					object[j].className = object[j+1].className;
					object[j+1].className = temp2;
					
					String temp3 = object[j].classType;
					object[j].classType = object[j+1].classType;
					object[j+1].classType = temp3;
					
					String temp4 = object[j].classCredit;
					object[j].classCredit = object[j+1].classCredit;
					object[j+1].classCredit = temp4;
					
					String temp5 = object[j].classTeacher;
					object[j].classTeacher = object[j+1].classTeacher;
					object[j+1].classTeacher = temp5;
					
					String temp6 = object[j].classSchool;
					object[j].classSchool = object[j+1].classSchool;
					object[j+1].classSchool = temp6;
					
					String temp7 = object[j].studyType;
					object[j].studyType = object[j+1].studyType;
					object[j+1].studyType = temp7;
					
					String temp8 = object[j].classYear;
					object[j].classYear = object[j+1].classYear;
					object[j+1].classYear = temp8;
					
					String temp9 = object[j].classTerm;
					object[j].classTerm = object[j+1].classTerm;
					object[j+1].classTerm = temp9;
				}
			}
		}
	}
	
	public static void processScoreTable(File input){
		try{
			
			//Use a object of workbook class to get information of the file.
			Workbook wb = Workbook.getWorkbook(input);
			
			//Use a object of sheet class to store content of file.
			Sheet sheet1 = wb.getSheet(0);
			int numCols = sheet1.getColumns();//Obtain the number of columns.
			int numRows = sheet1.getRows();//Obtain the number of rows.
			
			
			ClassInfor [] classInfor = new ClassInfor[numRows-1];//Declare a class array to store all the information of one class.
			
			
			for(int i = 0;i<numRows;i++){
				//Initialize each object of the class. 
				if(i<numRows-1)
					classInfor[i] = new ClassInfor();
			
				//Gain the content of each cell in order and print them.
				for(int j=0;j<numCols;j++){
					Cell c00 = sheet1.getCell(j,i);
					String c00String = c00.getContents();
					
					
					
					//Put the grade into the array in order.
					if(j==9){
						if(i>=1){
							gradeArray[i-1] = turnIntoInt(c00String);
							sumGrade = sumGrade + gradeArray[i-1];
						}
					}
					
					//Calculate the sum of the credits.
					if(j==3){
						if(i>=1){
							creditArray[i-1] = Double.parseDouble(c00String);
							sumCredit = sumCredit + creditArray[i-1];
						}
					}
					
					//Put all the information of one class into the class array.
					if(i>=1){
					
						switch(j){
						case 0:
							classInfor[i-1].classNumber = c00String;
						case 1:
							classInfor[i-1].className = c00String;
						case 2:
							classInfor[i-1].classType = c00String;
						case 3:
							classInfor[i-1].classCredit = c00String;
						case 4:
							classInfor[i-1].classTeacher = c00String;
						case 5:
							classInfor[i-1].classSchool = c00String;
						case 6:
							classInfor[i-1].studyType = c00String;
						case 7:
							classInfor[i-1].classYear = c00String;
						case 8:
							classInfor[i-1].classTerm = c00String;
						}
					}
					
					
					//Print the content of the excel.
					System.out.print(c00String+"\t");
					
					
				}
				System.out.println();
				
				if(i>=1){
					weightAverage = weightAverage + gradeArray[i-1]*creditArray[i-1];
				}
			}
			
			sortClassInfor(classInfor);//Invoke the method to sort the class information.
			gpa = calculateGPA();//Invoke the method to calculation GPA;
			weightAverage = weightAverage/sumCredit;//Calculate the weightAverage;
			
			//Create an another excel file to store the sorted data.
			WritableWorkbook myBook = Workbook.createWorkbook(new File("myNewGrade.et"));//Create a file.
			WritableSheet mySheet = myBook.createSheet("��һҳ", 0);//Create a sheet.
			
			//Add the name of each column.
			Label lebel1 = new Label(0,0,"��ͷ��");
			Label lebel2 = new Label(1,0,"�γ�����");
			Label lebel3 = new Label(2,0,"�γ�����");
			Label lebel4 = new Label(3,0,"ѧ��");
			Label lebel5 = new Label(4,0,"�γ̽�ʦ");
			Label lebel6 = new Label(5,0,"�ڿ�ѧԺ");
			Label lebel7 = new Label(6,0,"ѧϰ����");
			Label lebel8 = new Label(7,0,"ѧ��");
			Label lebel9 = new Label(8,0,"ѧ��");
			Label lebel0 = new Label(9,0,"����");
			
			mySheet.addCell(lebel1);
			mySheet.addCell(lebel2);
			mySheet.addCell(lebel3);
			mySheet.addCell(lebel4);
			mySheet.addCell(lebel5);
			mySheet.addCell(lebel6);
			mySheet.addCell(lebel7);
			mySheet.addCell(lebel8);
			mySheet.addCell(lebel9);
			mySheet.addCell(lebel0);
			
			//Add the content of each cell.
			for(int i=1;i<numRows;i++){
				Label label1 = new Label(0,i,classInfor[i-1].classNumber);
				Label label2 = new Label(1,i,classInfor[i-1].className);
				Label label3 = new Label(2,i,classInfor[i-1].classType);
				Label label4 = new Label(3,i,classInfor[i-1].classCredit);
				Label label5 = new Label(4,i,classInfor[i-1].classTeacher);
				Label label6 = new Label(5,i,classInfor[i-1].classSchool);
				Label label7 = new Label(6,i,classInfor[i-1].studyType);
				Label label8 = new Label(7,i,classInfor[i-1].classYear);
				Label label9 = new Label(8,i,classInfor[i-1].classTerm);
				Label label0 = new Label(9,i,Integer.toString(gradeArray[i-1]));
				
				mySheet.addCell(label1);
				mySheet.addCell(label2);
				mySheet.addCell(label3);
				mySheet.addCell(label4);
				mySheet.addCell(label5);
				mySheet.addCell(label6);
				mySheet.addCell(label7);
				mySheet.addCell(label8);
				mySheet.addCell(label9);
				mySheet.addCell(label0);
			}
			
			//Add the additional content to the excel file.
			Label label11 = new Label(10,0,"��Ȩƽ����");
			Label label12 = new Label(10,1,Double.toString(weightAverage));
			Label label13 = new Label(11,0,"GPA");
			Label label14 = new Label(11,1,Double.toString(gpa));
			mySheet.addCell(label11);
			mySheet.addCell(label12);
			mySheet.addCell(label13);
			mySheet.addCell(label14);
			
			myBook.write();
			myBook.close();
		}
		catch(Exception e){
			System.out.println(e);
		}
	}


}



