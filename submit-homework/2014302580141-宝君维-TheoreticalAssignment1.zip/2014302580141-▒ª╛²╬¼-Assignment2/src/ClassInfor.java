
public class ClassInfor {
	String classNumber;
	String className;
	String classType;
	String classCredit;
	String classTeacher;
	String classSchool;
	String studyType;
	String classYear;
	String classTerm;
	
}
