import java.io.File;
import java.io.IOException;


public class Main {

	public static void main(String[] args) throws IOException {
		// TODO �Զ����ɵķ������
		File newGrade = new File("D:/Ѹ������/eclipse_4.5.0_XiaZaiBa/OOP-TEST1/GradeExcel.xls");
		Grade i = new Grade();
		i.processScoreTable(newGrade);
		System.out.println("Done!");
	}
}
