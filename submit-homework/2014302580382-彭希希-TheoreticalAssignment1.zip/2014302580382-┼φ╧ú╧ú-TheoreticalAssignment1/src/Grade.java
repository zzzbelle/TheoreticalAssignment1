import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

//import org.apache.poi.hssf.eventusermodel.HSSFRequest;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
//import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class Grade {

	public void processScoreTable(File input) throws IOException {
		// ��ȡԭ�����ļ�
		FileInputStream in = new FileInputStream(input);
		HSSFWorkbook oldWb = new HSSFWorkbook(in);
		HSSFSheet oldSheet = oldWb.getSheetAt(0);

		// д���±���
		HSSFWorkbook newWb = new HSSFWorkbook();
		HSSFSheet newSheet = newWb.createSheet();

		// ���ö���
		HSSFCellStyle cellStyle = newWb.createCellStyle();
		cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);

		// ��������к͵�Ԫ�񣬲������иߺ͵�Ԫ����ʽ
		for (int i = 0; i < 41; i++) {
			newSheet.createRow(i);
			newSheet.getRow(i).setHeight((short) 350);
			for (int j = 0; j < 10; j++) {
				newSheet.getRow(i).createCell(j).setCellStyle(cellStyle);
			}
		}
		// Ϊ��Ԫ���趨�п�
		newSheet.setColumnWidth(0, 10000);
		newSheet.setColumnWidth(1, 10000);
		newSheet.setColumnWidth(2, 10000);
		newSheet.setColumnWidth(4, 10000);
		newSheet.setColumnWidth(5, 10000);
		newSheet.setColumnWidth(6, 10000);
		newSheet.setColumnWidth(7, 10000);
		newSheet.setColumnWidth(8, 10000);
		newSheet.setColumnWidth(9, 10000);

		// ������ѧ��
		double totalCredits = 0;
		for (int j = 1; j < 24; j++) {
			totalCredits += oldSheet.getRow(j).getCell(3).getNumericCellValue();
		}

		// ���㵥�Ƽ���
		double gradePoint[] = new double[24];
		for (int j = 1; j < 24; j++) {
			if (oldSheet.getRow(j).getCell(9).getNumericCellValue() >= 90) {
				gradePoint[j] = 4.0;
			} else if (oldSheet.getRow(j).getCell(9).getNumericCellValue() >= 85
					&& oldSheet.getRow(j).getCell(9).getNumericCellValue() <= 89) {
				gradePoint[j] = 3.7;
			} else if (oldSheet.getRow(j).getCell(9).getNumericCellValue() >= 82
					&& oldSheet.getRow(j).getCell(9).getNumericCellValue() <= 84) {
				gradePoint[j] = 3.3;
			} else if (oldSheet.getRow(j).getCell(9).getNumericCellValue() >= 78
					&& oldSheet.getRow(j).getCell(9).getNumericCellValue() <= 81) {
				gradePoint[j] = 3.0;
			} else if (oldSheet.getRow(j).getCell(9).getNumericCellValue() >= 75
					&& oldSheet.getRow(j).getCell(9).getNumericCellValue() <= 77) {
				gradePoint[j] = 2.7;
			} else if (oldSheet.getRow(j).getCell(9).getNumericCellValue() >= 72
					&& oldSheet.getRow(j).getCell(9).getNumericCellValue() <= 74) {
				gradePoint[j] = 2.3;
			} else if (oldSheet.getRow(j).getCell(9).getNumericCellValue() >= 68
					&& oldSheet.getRow(j).getCell(9).getNumericCellValue() <= 71) {
				gradePoint[j] = 2.0;
			} else if (oldSheet.getRow(j).getCell(9).getNumericCellValue() >= 64
					&& oldSheet.getRow(j).getCell(9).getNumericCellValue() <= 67) {
				gradePoint[j] = 1.5;
			} else if (oldSheet.getRow(j).getCell(9).getNumericCellValue() >= 60
					&& oldSheet.getRow(j).getCell(9).getNumericCellValue() <= 63) {
				gradePoint[j] = 1.0;
			} else {
				gradePoint[j] = 0.0;
			}
		}

		// ����GPA
		double GPA = 0;
		for (int j = 1; j < 24; j++) {
			GPA += gradePoint[j]
					* oldSheet.getRow(j).getCell(3).getNumericCellValue();
		}
		GPA /= totalCredits;

		// �����Ȩƽ����
		double averagePoint = 0;
		for (int j = 1; j < 24; j++) {
			averagePoint += oldSheet.getRow(j).getCell(3).getNumericCellValue()
					* oldSheet.getRow(j).getCell(9).getNumericCellValue();
		}
		averagePoint /= totalCredits;

		// ���GPA
		newSheet.getRow(40).getCell(0).setCellValue("GPA��");
		newSheet.getRow(40).getCell(1).setCellValue(GPA);

		// �����Ȩƽ����
		newSheet.getRow(39).getCell(0).setCellValue("��Ȩƽ���֣�");
		newSheet.getRow(39).getCell(1).setCellValue(averagePoint);

		// ���ݷ����������У��ó�ԭ����������Ӧ���±�������
		int order[] = new int[24];
		for (int i = 1; i < 24; i++) {
			order[i] = 0;
			// ͳ�Ƹ�������ĸ�����ȷ���Ӵ�С��λ��
			for (int j = 1; j < 24; j++) {
				if (oldSheet.getRow(i).getCell(9).getNumericCellValue() < oldSheet
						.getRow(j).getCell(9).getNumericCellValue()) {
					order[i]++;
				}
			}
			// ���Ⲣ��
			for (int k = 1; k < i; k++) {
				if (oldSheet.getRow(i).getCell(9).getNumericCellValue() == oldSheet
						.getRow(k).getCell(9).getNumericCellValue()) {
					order[i]++;
				}
			}
		}

		// ����������˳�������������
		for (int i = 1; i < 39; i++) {
			if (i < 22) {
				for (int j = 0; j < 10; j++) {
					changeValue(oldSheet.getRow(i).getCell(j),
							newSheet.getRow(order[i]).getCell(j));
				}
			}
			if (i >= 24 && i < 39) {
				for (int j = 0; j < 9; j++) {
					changeValue(oldSheet.getRow(i).getCell(j),
							newSheet.getRow(i).getCell(j));
				}
			}
		}

		// ��������ļ�
		FileOutputStream out = new FileOutputStream(
				"D:/Ѹ������/eclipse_4.5.0_XiaZaiBa/OOP-TEST1/newGradeExcel.xls");
		newWb.write(out);
		out.close();
		oldWb.close();
		newWb.close();
	}

	// ��Ԫ��ֵ
	public static void changeValue(HSSFCell oldCell, HSSFCell newCell) {
		if (oldCell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {
			newCell.setCellValue(oldCell.getNumericCellValue());
		} else if (oldCell.getCellType() == HSSFCell.CELL_TYPE_STRING) {
			newCell.setCellValue(oldCell.getStringCellValue());
		} else {
			System.out.println("error!");
		}
	}
}
