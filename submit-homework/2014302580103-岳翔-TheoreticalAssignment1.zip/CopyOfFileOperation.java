import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.omg.CORBA.PUBLIC_MEMBER;

class MainOutPut
{
	//��Ȩƽ����
		public static double averageGrade(int bufferPoint[],float creditPoint[])
		{
			double sum=0;
			double creditPointSum=0;
			for(int w=0;w<bufferPoint.length;w++)
			{
				sum=sum+bufferPoint[w]*creditPoint[w];
				creditPointSum=creditPointSum+creditPoint[w];
			}
			double averageGradeNum=sum/creditPointSum;
			
			return averageGradeNum;
		}
		
		//�ۺϼ�ȨGPA

		public static double averageGPA(int bufferPoint[],float creditPoint[])
		{
			double curGPA=0;
			double sum=0;
			double creditPointSum=0;
			
			for(int r=0;r<bufferPoint.length;r++)
			{
				if(bufferPoint[r]>=90&&bufferPoint[r]<=100)
					curGPA=4.0;
				else if(bufferPoint[r]>=85&&bufferPoint[r]<=89)
					curGPA=3.7;
				else if(bufferPoint[r]>=82&&bufferPoint[r]<=84)
					curGPA=3.3;
				else if(bufferPoint[r]>=78&&bufferPoint[r]<=81)
					curGPA=3.0;
				else if(bufferPoint[r]>=75&&bufferPoint[r]<=77)
					curGPA=2.7;
				else if(bufferPoint[r]>=72&&bufferPoint[r]<=74)
					curGPA=2.3;
				else if(bufferPoint[r]>=68&&bufferPoint[r]<=71)
					curGPA=2.0;
				else if(bufferPoint[r]>=64&&bufferPoint[r]<=67)
					curGPA=1.5;
				else if(bufferPoint[r]>=60&&bufferPoint[r]<=63)
					curGPA=1.0;
				else 
					curGPA=0;
				
				sum=sum+curGPA*creditPoint[r];
				creditPointSum=creditPointSum+creditPoint[r];
			}
			
			double averageGPA=sum/creditPointSum;
			
			return averageGPA;
			
		}
		
		
	public static void processScoreTable(File input) throws IOException {
	
		//��ȡ�ļ�
		
	
		FileReader fr = new FileReader(input);
		BufferedReader br=new BufferedReader(fr);
		
		String bufferString[]=new String[28];
		int iCount=0;//������
		while ((bufferString[iCount] = br.readLine()) != null) {
			iCount++;
			}
		br.close();
		fr.close();
		
		
		int creditPointsGet[][] = new int[27][2];// ��ȡѧ��
		float creditPoints[] = new float[27];
		float creditPointsBuffer[]=new float[27];
		
		int grade[] = new int[27];// �ɼ�
		int gradebuffer[]=new int[27];//�ɼ��Ĵ���

		int index[] = new int[27];// ����index������

		// ��ȡÿ�Ƴɼ��������Ϣ��������ַ���

		int j = 0;
		for (int i = 0; i < 27; i++) {
			String regex = "\\d*";
			Pattern p = Pattern.compile(regex);
			Matcher m = p.matcher(bufferString[i]);
			while (m.find()) {
				if (!"".equals(m.group())) {
					if (j == 1) {
						creditPointsGet[i][0] = Integer.parseInt(m.group());// ��ȡ��ѧ��
					} else if (j == 2) {
						creditPointsGet[i][1] = Integer.parseInt(m.group());
					} else if (j == 4) {
						grade[i] = Integer.parseInt(m.group());
						j = 0;
						break;
					}
					j++;
				}
			}
		}

		for (int k = 0; k < 27; k++) {
			creditPoints[k] = Float.parseFloat(creditPointsGet[k][0] + "."
					+ creditPointsGet[k][1]);

			// System.out.print(k+"\t"+creditPoints[k]+"\t");
			// System.out.println(grade[k]);

		}
		
		for (int q = 0; q < 27; q++) {
			int maxNum = 0;
			for (int p = 0; p < 27; p++) {
				if (maxNum < grade[p]) {
					maxNum = grade[p];
					index[q] = p;
				}
			}
			gradebuffer[q]=maxNum;
			grade[index[q]]=0;//���ֵ���
			creditPointsBuffer[q]=creditPoints[index[q]];
		
			//System.out.println(index[q]+"\t"+creditPointsBuffer[q]+"\t"+gradebuffer[q]);
		}
		
		double myAveragrGrade=averageGrade(gradebuffer, creditPointsBuffer);
		double myAverageGPA = averageGPA(gradebuffer, creditPointsBuffer);
		
		FileWriter fw = new FileWriter("newGrade.txt");
		for (int i = 0; i <27;i++) {
			fw.write(bufferString[i] + "\r\n");
		}
		fw.write("\r\n");
		fw.write("��Ȩƽ����:"+Double.toString(myAveragrGrade)+ "\r\n");
		fw.write("��Ȩƽ��GPA:"+Double.toString(myAverageGPA)+ "\r\n");
		
		fw.close();
	}
}

public class CopyOfFileOperation {
	public static void main(String[] args) throws IOException {
		File myGradeFile=new File("MyGrade.txt");
		MainOutPut.processScoreTable(myGradeFile);
		
		
	}
	
}


