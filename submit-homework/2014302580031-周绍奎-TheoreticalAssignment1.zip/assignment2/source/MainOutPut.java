
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import jxl.Workbook;
import jxl.Cell;
import jxl.Sheet;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import java.io.File;
import java.io.IOException;
import java.lang.*;

import java.lang.Float;
import java.lang.System;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
public class MainOutPut{
    //解析html并写入excel
    private static void html2Excel(File html){
        try {
            //操作DOM获取整个dom结构赋值给doc
            Document doc = Jsoup.parse(html,"GBK","");
            //获取doc中的表格table部分
            Element table = doc.getElementsByTag("table").get(0);
            //获取table中每一行组成数组存入trs
            Elements trs = table.getElementsByTag("tr");
            //创建用来存储从html中解析的数据的excel
            WritableWorkbook gradeXLS = Workbook.createWorkbook(new File("./grade.xls"));
            //excel中建立一个工作表
            WritableSheet gradesheet = gradeXLS.createSheet("grade", 0);
            //两个嵌套循环遍历table中每一个td并存入excel中的各个单元格
            for (int i = 0;i<trs.size();i++){
                Element tr = trs.get(i);
                Elements tds;
                //因为表头是th不是td所以要做一下判断
                if (i==0){
                    tds = tr.getElementsByTag("th");
                }else{
                    tds = tr.getElementsByTag("td");
                }
                int z = 0;
                for (int j=0;j<tds.size();j++){
                    Element td = tds.get(j);
                    //创建单元格并存入对应table中td的数据
                    Label label = new Label(z,i,td.text());
                    gradesheet.addCell(label);
                    z++;
                }
            }
            gradeXLS.write();
            gradeXLS.close();
        }catch (RowsExceededException e){
            e.printStackTrace();
        }catch (WriteException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        };
    }
    //将排序好的二维数组写入一个excel中（和html2Excel方法差不多）并计算平均分以及平均GPA
    private static void sortedData2Excel(String[][] tableSorted){
        try {
            Float allScore=0.0f,allGpa=0.0f;
            Float aveScore=0.0f,aveGpa=0.0f;
            Float studyScore = 0.0f;
            int counter = 0;
            //创建要写入排序好的数据的excel
            WritableWorkbook gradeXLS = Workbook.createWorkbook(new File("./gradeSorted.xls"));
            //创建工作簿
            WritableSheet gradesheet = gradeXLS.createSheet("grade", 0);
            for (int i=1;i<tableSorted.length;i++){
                Float a = Float.parseFloat(tableSorted[i][9]);
                Float b = Float.parseFloat(tableSorted[i][3]);
                if (tableSorted[i][9]!="0"){
                    allScore=allScore+a*b;
                    studyScore = studyScore + Float.parseFloat(tableSorted[i][3]);

                    if (a>=90.0f){
                        allGpa+=4.0f*b;
                    }else if(a>=85.0f&&a<90.0f){
                        allGpa+=3.7f*b;
                    }else if(a>=82.0f&&a<85.0f){
                        allGpa+=3.3f*b;
                    }else if(a>=78.0f&&a<82.0f){
                        allGpa+=3.0f*b;
                    }else if(a>=75.0f&&a<78.0f){
                        allGpa+=2.7f*b;
                    }else if(a>=72.0f&&a<75.0f){
                        allGpa+=2.3f*b;
                    }else if(a>=68.0f&&a<71.0f){
                        allGpa+=2.0f*b;
                    }else if(a>=64.0f&&a<68.0f){
                        allGpa+=1.5f*b;
                    }else if(a>=60.0f&&a<63.0f){
                        allGpa+=1.0f*b;
                    }else{
                        allGpa+=0.0f;
                    }
                }
            }
            aveScore = allScore/studyScore;
            aveGpa = allGpa/studyScore;

            for (int i = 0;i<tableSorted.length;i++){
                int z = 0;
                for (int j=0;j<tableSorted[i].length;j++){
                    if (tableSorted[i][j]=="0"){
                        tableSorted[i][j]="";
                    }
                    String tdText = tableSorted[i][j];
                    Label label = new Label(z,i,tdText);
                    gradesheet.addCell(label);
                    z++;
                }
            }
            Label labelaveScore = new Label(11,1,aveScore+"");
            Label labelaveGpa = new Label(11, 2, aveGpa+"");
            gradesheet.addCell(labelaveScore);
            gradesheet.addCell(labelaveGpa);
            gradeXLS.write();
            gradeXLS.close();
        }catch (RowsExceededException e){
            e.printStackTrace();
        }catch (WriteException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        };
    }
    //从excel中读取数据到数组中并排序
    private static void processScoreTable(File input){
        //创建一个二维数组来存放excel中的数据
        String[][] tableList;
        try{
            //获取要读取数据的excel
            Workbook readGradexls = Workbook.getWorkbook(input);
            //获取相应工作簿
            Sheet sheet = readGradexls.getSheet(0);
            //初始化二维数组
            tableList = new String[sheet.getRows()][];
            for (int i=0;i<sheet.getRows();i++){
                tableList[i] = new String[sheet.getColumns()];
                //System.out.println(tableList[i].length);
            }
            //利用嵌套循环遍历excel中的每一个单元格并写入相应数组中的位置
            for (int i = 0;i<sheet.getRows();i++){
                for (int j = 0;j<sheet.getColumns();j++){
                    tableList[i][j] = sheet.getCell(j,i).getContents();
                }
            }
            //对二维数组中的元素按照成绩进行排序
            for (int i=1;i<sheet.getRows();i++){
                for (int m=1;m<sheet.getRows()-1;m++){
                    //创建字符串数组
                    String[] str=null;
                    //判断如果成绩那一栏没有成绩，是空字符串，就把成绩暂设为“0”，方便排序
                    if (tableList[m+1][9]==null || tableList[m+1][9].length()<=0){
                        tableList[m+1][9]="0";
                    }
                    //每一项都和其后所有的项比较，如果小就和其后的元素对换位置，实现降序排序
                    if(Float.parseFloat(tableList[m][9])<Float.parseFloat(tableList[m + 1][9])){
                        str = tableList[m];
                        tableList[m] = tableList[m+1];
                        tableList[m+1] = str;
                    }
                }
            }
            //将排序好的二维数组写入一个excel中
            sortedData2Excel(tableList);
            readGradexls.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }



    public static void main(String[] arg) throws IOException{
        File grade = new File("./grade.html");
        html2Excel(grade);
        File excelToRead = new File("./grade.xls");
        processScoreTable(excelToRead);
    }
}