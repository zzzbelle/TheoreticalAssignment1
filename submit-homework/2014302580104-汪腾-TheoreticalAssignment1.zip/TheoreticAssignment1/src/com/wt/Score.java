package com.wt;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.write.Label;

public class Score {
	int rsColumns;//sheet���е�������
	int rsRows;//sheet���е�������
	int counter = 0;//���з�����Ŀ��������
	public double GPA = 0.0;//ƽ������
	public double weightedAverage = 0.0;//��Ȩƽ��ֵ
	double []creditsOfScores = new double[40];
	Subject [] subject = new Subject[40];
	jxl.Workbook read = null;
	public Score(){
		for(int i = 0;i < 40;i++){
			subject[i] = new Subject();
		}
	}
	public void readExcelFile(String path){
		try{
			InputStream input = new FileInputStream(path);//�ӱ��ش���Workbook
			read = Workbook.getWorkbook(input);
			Sheet readSheet = read.getSheet(0);//sheet���±��Ǵ�0��ʼ�ģ�������һ��sheet��
			rsColumns = readSheet.getColumns();//��ȡsheet���е�������
			rsRows = readSheet.getRows();//��ȡsheet���е�������
			for(int i = 2;i < rsRows;i++){  //һ�����ǿ��кͱ���ͷ
				for(int j = 0;j < rsColumns;j++){
					Cell cell = readSheet.getCell(j, i);
					
					switch(j){
					case 0:
						subject[i-2].number = Long.parseLong(cell.getContents());
						break;
					case 1:
						subject[i-2].name = cell.getContents();
						break;
					case 2:
						subject[i-2].type = cell.getContents();
						break;
					case 3:
						subject[i-2].credits = Double.parseDouble(cell.getContents());
						break;
					case 4:
						subject[i-2].teacher = cell.getContents();
						break;
					case 5:
						subject[i-2].institute = cell.getContents();
						break;
					case 6:
						subject[i-2].type1 = cell.getContents();
						break;
					case 7:
						subject[i-2].year = Double.parseDouble(cell.getContents());
						break;
					case 8:
						subject[i-2].semester = cell.getContents();
						break;
					case 9:
						if(i < 27){
							subject[i-2].grade = Double.parseDouble(cell.getContents());
							counter++;
						}
						break;
					}
				}
			}
			getWeightedAverage();
			getGPA();
			Arrays.sort(subject);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void writeTxtFile(){
		try{
			File file = new File("grade1.txt");
			file.createNewFile();
			BufferedWriter write = new BufferedWriter(new FileWriter("grade1.txt"));
			String[] title = {"��ͷ��","�γ�����","�γ�����",	"ѧ��","��ʦ","�ڿ�ѧԺ","ѧϰ����","ѧ��","ѧ��","�ɼ�"}; 
			for (int i = 0; i < title.length; i++) { 
				write.write(title[i] + "\t");
			}
			write.newLine();
			for(int i = 1;i < 40;i++){
				for(int j = 0;j < 10;j++){
					switch(j){
					case 0:
						write.write(Long.toString(subject[i-1].number)+"\t");					
						break;
					case 1:					
						write.write(subject[i-1].name+"\t");
						break;
					case 2:
						write.write(subject[i-1].type+"\t");
						break;
					case 3:
						write.write(Double.toString(subject[i-1].credits)+"\t");
						break;
					case 4:
						write.write(subject[i-1].teacher+"\t");
						break;
					case 5:
						write.write(subject[i-1].institute+"\t");
						break;
					case 6:
						write.write(subject[i-1].type1+"\t");
						break;
					case 7:
						write.write(Double.toString(subject[i-1].year)+"\t");
						break;
					case 8:
						write.write(subject[i-1].semester+"\t");
						break;
					case 9:
						write.write(Double.toString(subject[i-1].grade)+"\t");
						break;
					}
				}
				write.newLine();
			
			}
			write.newLine();
			write.write("GPA" + GPA);
			write.write("    weightedAverage" + weightedAverage);
			write.close();
			System.out.println("�ɼ���������ɹ�");
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void getGPA(){
		double sum = 0.0;//���Ƽ���*ѧ���ܺ�
		double sumOfCredits = 0.0;//ѧ��֮��
		
		for(int i = 0;i < counter;i++){//����������ζ�Ӧ��ѧ��
			if(subject[i].grade<60.0) creditsOfScores[i] = 0.0;
			else if(subject[i].grade < 64.0) creditsOfScores[i] = 1.0;
			else if(subject[i].grade < 68.0) creditsOfScores[i] = 1.5;
			else if(subject[i].grade < 72.0) creditsOfScores[i] = 2.0;
			else if(subject[i].grade < 75.0) creditsOfScores[i] = 2.3;
			else if(subject[i].grade < 78.0) creditsOfScores[i] = 2.7;
			else if(subject[i].grade < 82.0) creditsOfScores[i] = 3.0;
			else if(subject[i].grade < 85.0) creditsOfScores[i] = 3.3;
			else if(subject[i].grade < 90.0) creditsOfScores[i] = 3.7;
			else  creditsOfScores[i] = 4.0;
		}
		for(int i = 0;i < counter;i++){
			sum += subject[i].credits * creditsOfScores[i];
			sumOfCredits += subject[i].credits; 
		}
		GPA = sum / sumOfCredits;
		System.out.println("�Ѽ����GPA");
	}
public void getWeightedAverage(){
		
		double sum = 0.0;//���Ʒ���*ѧ���ܺ�
		double sumOfCredits = 0.0;//ѧ��֮��
		for(int i = 0;i < counter;i++){
			sum += subject[i].grade * subject[i].credits;
			sumOfCredits += subject[i].credits; 
		}
		weightedAverage = sum / sumOfCredits;
		System.out.println("�ѳɹ��������Ȩƽ����");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Score score = new Score();
		String url = "grade.xls";
		score.readExcelFile(url);
		score.writeTxtFile();
	}

}


