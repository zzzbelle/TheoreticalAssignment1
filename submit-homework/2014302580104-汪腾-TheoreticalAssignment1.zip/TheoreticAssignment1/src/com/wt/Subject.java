package com.wt;

class Subject implements Comparable<Subject>{
	long number;//�γ̺�
	String name;//�γ�����
	String type;//�γ�����
	double credits;//ѧ��
	String teacher;//��ʦ
	String institute;//�ڿ�ѧԺ
	String type1;//ѧϰ����
	double year;//ѧ��
	String semester;//ѧ��
	double grade;//�ɼ�
	@Override
	public int compareTo(Subject subject) {
		// TODO Auto-generated method stub
		if(this.grade > subject.grade){
			return -1;
		}else if(this.grade<subject.grade){
			return 1;
		}else{
			if(this.credits>subject.credits){
				return 1;
			}else if(this.credits<subject.credits){
				return -1;
			}else{
				return 0;
			}
		}
	}	
	public Subject(
		long number,
		String name,
		String type,
		double credits,
		String teacher,
		String institute,
		String type1,
		double year,
		String semester,
		double grade){
			this.number = number;
			this.name = name;
			this.type = type;
			this.credits = credits;
			this.teacher = teacher;
			this.institute = institute;
			this.type1 = type1;
			this.year = year;
			this.semester = semester;
			this.grade = grade; 
		}
		public Subject() {
		// TODO Auto-generated constructor stub
		}
		public String toString(){
			return number+"\t"+name+"\t"+type+"\t"+credits+"\t"+teacher
			+"\t"+institute+"\t"+type1+"\t"+year+"\t"+semester+"\t"+grade;
		}
}	