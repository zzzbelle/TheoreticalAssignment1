/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package theoreticalassignment1;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import jxl.*;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.*;
import org.jsoup.select.*;


 /*
 * @author Pinckney Emiya
 *
 *File->html->doc->Elements->Element->text->Label->xls
 */
public class MainOutPut {
    public static void processScoreTable(File input)
    {
        /*
        Try to read the html
        */
        //File keyA = new File("233.html");
        Document doc = null;
        try {
            doc = Jsoup.parse(input,"gb2312");
        } catch (IOException ex) {
            Logger.getLogger(MainOutPut.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        int scoreL = 0,markL = 0;
        Elements courses=doc.select("tr");
        //Elements course=courses.select("td");
        Elements title=doc.select("tr").select("th");
        String titleGet[]=new String[100];
        String scoreGet[]=new String[100];
        String gpaGet[]=new String[100];
       //Element test=course.get(0);
        //Label titleLabel[]=new Label[10];

        
        
        
        try {
            //Set File
            File outputFile = new File("result.xls");
            
            WritableWorkbook workbook = Workbook.createWorkbook(outputFile);
            WritableSheet sheet = workbook.createSheet("Score",0);
            
            //Output
            for(int i = 0;i<title.size();i++)
            {
            titleGet[i]=title.get(i).text();
                
            Label outLabel=new Label(i,0,titleGet[i]);
            sheet.addCell(outLabel);
            //System.out.println(titleGet[i]);
            }
            for(int i=0;i<title.size();i++)
            {
                if (titleGet[i].equals("成绩"))
                {
                    scoreL=i;
                    System.out.println(scoreL);
                } 
                else if(titleGet[i].equals("学分"))
                {
                    markL=i;
                    System.out.println(markL);
                }
            }

            for (int i=0;i<courses.size();i++)
            {
                /*for(int j=0;j<title.size();j++)
                {
                    //courseGet[i][j]=course.get(i+j*title.size()).text();
                    //Label outLabel=new Label(i,j+1,courseGet[i][j]);
                    //sheet.addCell(outLabel);
                }*/
                Elements course=courses.get(i).select("td");
                for(int j=1;j<course.size();j++)
                {
                   Label outLabel=new Label(j,i+1,course.get(j).text());
                   sheet.addCell(outLabel);
                }
                //Label outLabel=new Label(tds,trs,course.get(i).text());
                
               
            }
            
            
            //Sort
            /*int maxC=courses.size();
            int courseNum[]=new int[maxC];
            int courseMark[]=new int[maxC];
            int courseScore[]=new int[maxC];
            
            for (int i=0;i<maxC;i++)
            {
                courseNum[i]=i;
                courseMark[i]=Integer.parseInt(courses.select("td").get(markL).text());
                courseScore[i]=Integer.parseInt(courses.select("td").get(scoreL).text());
                       
            }*/
            
            
            //Close Stream
            workbook.write();
            workbook.close();
        } catch (IOException ex) {
            Logger.getLogger(MainOutPut.class.getName()).log(Level.SEVERE, null, ex);
        } catch (WriteException ex) {
            Logger.getLogger(MainOutPut.class.getName()).log(Level.SEVERE, null, ex);
        }
         
    }
}
