import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainOutPut {
	
	public static void main(String[] args) throws IOException
	{
		File file = new File("newScoreList.txt");
		MainOutPut mop = new MainOutPut();
		mop.processScoreTable(file);
	}
	
	public void processScoreTable(File input) throws IOException{
		try{
			File file = new File("scorelist.txt");
			ArrayList<Subject> classInfo = getinfo(file);
			double averagescore = getAverageScore(classInfo);
			double averagegpa = getAverageGpa(classInfo);
			BufferedWriter bw = new BufferedWriter(new FileWriter(input,true));
			for(Subject i:classInfo)
			{
				bw.write(i.classId+"\t"+i.className+"\t"+i.classType+"\t"+
						i.credit+"\t"+i.teacher +"\t"+i.department+"\t"+i.type+"\t"+i.year+"\t"+
						i.semester+"\t"+i.score+"\r\n");
			}
			bw.write("��Ȩƽ���֣� "+averagescore+"\t\t"+"��ȨGPA: "+averagegpa);
			bw.close();
			}catch(Exception e){
				e.printStackTrace();
			}
	}
	
	public static ArrayList<Subject> getinfo(File file)
	{
		ArrayList<Subject> info = new ArrayList<Subject>();
		try{
			InputStreamReader isr = new InputStreamReader(new FileInputStream(file),"Unicode");
			BufferedReader br = new BufferedReader(isr);
			String s=null;
			while((s=br.readLine())!=null)
			{
				String[] arr = s.split("\\t+");
				info.add(new Subject(arr[0],arr[1],arr[2],Double.parseDouble(arr[3]),arr[4],arr[5],arr[6],arr[7],arr[8],Double.parseDouble(arr[9])));
			}
			br.close();
		
			//����
			Collections.sort(info,new SortByScore());			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return info;		
	}	
	
	public static double getAverageScore(ArrayList<Subject> al)
	{
		double averagescore;
		double sumcredit=0;
		double sumscore=0;
		for(Subject i:al){
			double credit = i.getCredit();
			double score = i.getScore();
			sumcredit = sumcredit + credit;
			sumscore = sumscore + score*credit;
		}
		averagescore = sumscore / sumcredit;
		return averagescore;
	}

	public static double getAverageGpa(ArrayList<Subject> al)
	{
		double sumgpa = 0;
		double averagegpa;
		double sumcredit=0;
		
		for(Subject i:al)
		{
			double gpa = 0;
			double credit = i.getCredit();
			double score = i.getScore();
			sumcredit = sumcredit + credit;
			
			if(score>=90&&score<=100)
			{
				gpa = 4.0;
			}
			if(score>=85&&score<=89)
			{
				gpa = 3.7;
			}
			if(score>=82&&score<=84)
			{
				gpa = 3.3;
			}
			if(score>=78&&score<=81)
			{
				gpa = 3.0;
			}
			if(score>=75&&score<=77)
			{
				gpa = 2.7;
			}
			if(score>=72&&score<=74)
			{
				gpa = 2.3;
			}
			if(score>=68&&score<=71)
			{
				gpa = 2.0;
			}
			if(score>=64&&score<=67)
			{
				gpa = 1.5;
			}
			if(score>=60&&score<=63)
			{
				gpa = 1.0;
			}
			if(score<60)
			{
				gpa = 0;
			}
			sumgpa = sumgpa + gpa*credit;
		}
		averagegpa = sumgpa / sumcredit; 
		return averagegpa;
	}
}

class SortByScore implements Comparator{
	
	public int compare(Object o1,Object o2)
	{
		Subject sub1 = (Subject)o1;
		Subject sub2 = (Subject)o2;
		if(sub1.getScore()>sub2.getScore())
		{
			return -1;
		}
		else if(sub1.getScore()<sub2.getScore())
		{
			return 1;
		}
		return 0;
	}
}


class Subject{
	String classId;
	String className;
	String classType;
	double credit;
	String teacher;
	String department;
	String type;
	String year;
	String semester;
	double score;
	
	public double getScore()
	{
		return score;
	}
	public double getCredit()
	{
		return credit;
	}
	
	public Subject(String m_classId,
	String m_className,
	String m_classType,
	double m_credit,
	String m_teacher,
	String m_department,
	String m_type,
	String m_year,
	String m_semester,
	double m_score){
		this.classId = m_classId;
		this.className = m_className;
		this.classType = m_classType;
		this.credit = m_credit;
		this.teacher = m_teacher;
		this.department = m_department;
		this.type = m_type;
		this.year = m_year;
		this.semester = m_semester;
		this.score = m_score;
	}
}