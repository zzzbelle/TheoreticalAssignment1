import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.util.CellRangeAddress;


public class MainOutPut {
	//��excel��Ԫ���л�ȡ����
	private static String getData(HSSFCell cell){
		String strCell = "";
		switch(cell.getCellType()){
		case HSSFCell.CELL_TYPE_STRING:
			strCell = cell.getStringCellValue();
			break;
		case HSSFCell.CELL_TYPE_NUMERIC:
			strCell = String.valueOf(cell.getNumericCellValue());
			break;
		case HSSFCell.CELL_TYPE_BOOLEAN:
			strCell = String.valueOf(cell.getBooleanCellValue());
			break;
		case HSSFCell.CELL_TYPE_BLANK:
			strCell = "";
			break;
		default:
			strCell = "";
			break;
		}
		if(strCell.equals("") || strCell == null){
			return "";
		}
		return strCell;
	}

	//�ѳɼ�ת���ɼ���
	private static double convertToCredit(HSSFCell cell){
		double value = Double.parseDouble(getData(cell));
		double credit;
		if(value <= 100 && value >= 90){
			credit = 4.0;
		}else if(value < 90 && value >= 85){
			credit = 3.7;
		}else if(value < 85 && value >= 82){
			credit = 3.3;
		}else if(value < 82 && value >= 78){
			credit = 3.0;
		}else if(value < 78 && value >= 75){
			credit = 2.7;
		}else if(value < 75 && value >= 72){
			credit = 2.3;
		}else if(value < 72 && value >= 68){
			credit = 2.0;
		}else if(value < 68 && value >= 64){
			credit = 1.5;
		}else if(value < 64 && value >= 60){
			credit = 1.0;
		}else{
			credit = 0;
		}
		return credit;
	}
	
	//����
	private static void sort(double array[]){
		for(int i = 0; i < array.length - 1;i++){
			for(int j = i + 1;j <= array.length - 1;j++){
				if(array[i] < array[j]){
					double m = array[i];
					array[i] = array[j];
					array[j] = m;
				}
			}
		}
	}
	
	@SuppressWarnings("resource")
	public static void processScoreTable(HSSFWorkbook input) throws FileNotFoundException, IOException{
		//ָ���õ��Ǳ�1����sheet1��
		HSSFSheet sheet = input.getSheetAt(0);
		//�����ܷ֡���ѧ�֡���GPA���ɼ�����
		double zongFen = 0.0;
		double zongCredit = 0.0;
		double zongGPA = 0.0;
		double[] jiangXu;
		jiangXu = new double[23];
		//�����Ȩƽ���ֺ��ۺϼ�ȨGPA
		for(int i = 1;i < 24;i++){
			HSSFRow row = sheet.getRow(i);
			if(row == null){
				continue;
			}
			HSSFCell cell0 = row.getCell(3);
			HSSFCell cell1 = row.getCell(9);
			double credit = convertToCredit(cell1);
			double value0 = Double.parseDouble(getData(cell0));
			double value1 = Double.parseDouble(getData(cell1));
			jiangXu[i - 1] = value1;
			zongCredit += value0;
			zongFen = zongFen + value0 * value1;
			zongGPA = zongGPA + value0 * credit;
		}
		double averageScore = zongFen / zongCredit;
		double averageGPA = zongGPA / zongCredit;
		//ʵ�ְ��ճɼ���������
		sort(jiangXu);
		for(int i = 0; i <= 22;i++){
			for(int j = 1;j < 24;j++){
				HSSFRow row = sheet.getRow(j);
				HSSFCell cell = row.getCell(9);
				double value = Double.parseDouble(getData(cell));
				if(value == jiangXu[i]){
					HSSFRow newRow = sheet.getRow(i+1);
					for(int k = 0;k <= 9;k++){
						HSSFCell cell00 = row.getCell(k);
						HSSFCell cell01 = newRow.getCell(k);
						String data00 = getData(cell00);
						String data01 = getData(cell01);
						cell00.setCellValue(data01);
						cell01.setCellValue(data00);
					}
				}
			}
		}
		//���������ӵ�������еĵ�Ԫ����ʽ
		HSSFCellStyle headstyle = input.createCellStyle();
		headstyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		headstyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
		headstyle.setLocked(true);
		//��ԭ���Ļ�����������һ����ʾ��Ȩƽ����
		HSSFRow footRow0 = sheet.createRow(24); 
		HSSFCell footRow0Cell0 = footRow0.createCell(0);
		footRow0Cell0.setCellValue(new HSSFRichTextString("��Ȩƽ����"));
		footRow0Cell0.setCellStyle(headstyle);
		HSSFCell footRowCell1 = footRow0.createCell(9);
		footRowCell1.setCellValue(averageScore);
		//�ϲ���Ԫ��
		CellRangeAddress range = new CellRangeAddress(24,24,0,8);
		sheet.addMergedRegion(range);
		//��ԭ���Ļ��������ӵڶ�����ʾ�ۺϼ�ȨGPA
		HSSFRow footRow1 = sheet.createRow(25); 
		HSSFCell footRow1Cell0 = footRow1.createCell(0);
		footRow1Cell0.setCellValue(new HSSFRichTextString("�ۺϼ�ȨGPA"));
		footRow1Cell0.setCellStyle(headstyle);
		HSSFCell footRow1Cell1 = footRow1.createCell(9);
		footRow1Cell1.setCellValue(averageGPA);
		//�ϲ���Ԫ��
		CellRangeAddress range1 = new CellRangeAddress(25,25,0,8);
		sheet.addMergedRegion(range1);
	}
	//������
	public static void main(String [] args) throws FileNotFoundException, IOException{
		//��ȡexcel�ļ�
		HSSFWorkbook zywb = new HSSFWorkbook(new FileInputStream
				(new File("E:/SophomoreShang/JAVA/TAPractice/TheoreticalAssignment01/ZYChengJiDan.xls")));
		processScoreTable(zywb);
		//���excel�ļ�
		FileOutputStream outputStream = new FileOutputStream("E:/SophomoreShang/JAVA/TAPractice/TheoreticalAssignment01/ZYChengJiDan.xls");
		zywb.write(outputStream);
		outputStream.flush();
		outputStream.close();
	}
}
