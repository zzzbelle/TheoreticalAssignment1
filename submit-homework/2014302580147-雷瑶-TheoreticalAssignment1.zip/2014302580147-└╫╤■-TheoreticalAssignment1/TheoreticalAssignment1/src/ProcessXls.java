import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;

public class ProcessXls {
	
	private static String xls = "MyGrades.xls";  
	
	public static List<Grade> readFromXLS(String filePath) {
        File excelFile = null;// Excel�ļ�����  
		InputStream myExcel = null;// ����������
        String cellStr = null;// ��Ԫ�����հ��ַ�������  
        List<Grade> gradeList = new ArrayList<Grade>();// ���ط�װ���ݵ�List  
        Grade grade = null;// ÿһ��ѧ����Ϣ����  
    	try {
    		excelFile = new File(filePath);
            InputStream myExcel1 = new FileInputStream(excelFile);// ��ȡ�ļ�������  
            HSSFWorkbook wb = new HSSFWorkbook(myExcel1);// ����Excel�ļ�����  
            HSSFSheet sheet = wb.getSheetAt(0);// ȡ����һ����������������0  
            // ��ʼѭ�������У���ͷ����������1��ʼ  
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {  
                grade = new Grade();// ʵ����Student����  
                HSSFRow row = sheet.getRow(i);// ��ȡ�ж���  
                if (row == null) {// ���Ϊ�գ�������  
                    continue;  
                }  
                //ѭ��������Ԫ��  
                for (int j = 0; j < row.getLastCellNum(); j++) {  
                    HSSFCell cell = row.getCell(j);// ��ȡ��Ԫ�����  
                    if (cell == null) {// ��Ԫ��Ϊ������cellStrΪ�մ�  
                        cellStr = "";  
                    } else if (cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {// ������ֵ�Ĵ���  
                        cellStr = cell.getNumericCellValue() + "";  
                    } else {// ���ఴ���ַ�������  
                        cellStr = cell.getStringCellValue();  
                    }  
                    //���水�����ݳ���λ�÷�װ��bean��  
                    if (j == 0) {  
                        grade.setId(new Double(cellStr).longValue());  
                    } else if (j == 1) {  
                        grade.setName(cellStr);  
                    } else if (j == 2) {  
                        grade.setType(cellStr);  
                    } else if (j == 3) {  
                        grade.setCredit(new Double(cellStr).doubleValue());  
                    } else if (j == 4){  
                        grade.setTeacher(cellStr);  
                    } else if (j == 5){
                    	grade.setInstitute(cellStr);
                    } else if (j == 6){
                    	grade.setStudy(cellStr);
                    } else if (j == 7){
                    	grade.setYear(new Double(cellStr).intValue());
                    } else if (j == 8){
                    	grade.setSemester(cellStr);
                    } else {
                    	grade.setScore(new Double(cellStr).intValue());
                    }
                }  
                gradeList.add(grade);// ����װ��List  
            }  
    } catch (IOException e) {  
            e.printStackTrace();  
        } finally {// �ر��ļ���  
            if (myExcel != null) {  
                try {
                    myExcel.close();     
                } catch (IOException e) {  
                    e.printStackTrace();  
                }  
            }  
        }  
        return gradeList;  
    }  
	
	
	//���ɼ�������
	public static void sort(List<Grade> grades){
		sortDown sd = new sortDown();
		Collections.sort(grades,sd);		
	}
	
	//���ÿ�Ƴɼ���Ӧ��GPA
	public static double GPA(Grade grade){
		double score = grade.getScore();
		if(score >= 90) return 4.0;
		else if(score >= 85) return 3.7;
		else if(score >= 82) return 3.3;
		else if(score >= 78) return 3.0;
		else if(score >= 75) return 2.7;
		else if(score >= 72) return 2.3;
		else if(score >= 68) return 2.0;
		else if(score >= 64) return 1.5;
		else if(score >= 60) return 1.0;
		else return 0.0;
	}
	
	//�����Ȩƽ����
	public static double GetWeiScore(List<Grade> grades){
		double weightedAverageScore = 0.0,totalCredits = 0.0;
				
		for(Grade grade:grades){
			totalCredits += grade.getCredit();
			weightedAverageScore += grade.getScore() * grade.getCredit();
		}
		weightedAverageScore  /= totalCredits;
		return weightedAverageScore;
	}
	
	//�����ȨGPA
	public static double GetWeiGPA(List<Grade> grades){
		double weightedGPA = 0.0,totalCredits = 0.0;
				
		for(Grade grade:grades){
			totalCredits += grade.getCredit();
			weightedGPA += GPA(grade) * grade.getCredit();
		}
		weightedGPA /= totalCredits;
		return weightedGPA;
	}
	
	//���³ɼ��������
	public static Boolean OutputExcel(){
		try{


	    HSSFWorkbook wb = null;
	    wb = new HSSFWorkbook();
		int columeCount = 10;
		//int rowCount = 28;
		HSSFSheet sheet = wb.createSheet("Sheet1");

		sheet.setColumnWidth(1,22*256);
		sheet.setColumnWidth(0,20*256);
		sheet.setDefaultRowHeight((short) (14 * 256)); //����Ĭ���и�
		sheet.setDefaultColumnWidth(11);    //����Ĭ���п�
		
		//��д��ͷ����
		HSSFRow headRow = sheet.createRow(0);
		String[] titleArray = {"��ͷ��", "�γ�����", "�γ�����", "ѧ��", "��ʦ",
				"�ڿ�ѧԺ", "ѧϰ����", "ѧ��", "ѧ��", "�ɼ�"};
		for(int m=0;m<=columeCount-1;m++)
		{
			HSSFCell cell = headRow.createCell(m);
			HSSFCellStyle style = wb.createCellStyle();
			style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			HSSFFont font = wb.createFont();
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			font.setFontHeightInPoints((short) 12);
			style.setFont(font);
			cell.setCellStyle(style);
			cell.setCellValue(titleArray[m]);
		}
		
		
		List<Grade> list = readFromXLS(xls); 
		sort(list);
		//д�밴�ɼ�����������
		int index = 0;
		for(Grade grade : list)
		{
			//logger.info("д��һ��");
			HSSFRow row = sheet.createRow(index+1);
			for(int n=0;n<=columeCount-1;n++)
				row.createCell(n);
				String myId = String.valueOf(grade.getId());
				row.getCell(0).setCellValue(myId);
				row.getCell(1).setCellValue(grade.getName());
				row.getCell(2).setCellValue(grade.getType());
				row.getCell(3).setCellValue(grade.getCredit());
				row.getCell(4).setCellValue(grade.getTeacher());
				row.getCell(5).setCellValue(grade.getInstitute());
				row.getCell(6).setCellValue(grade.getStudy());
				row.getCell(7).setCellValue(grade.getYear());
				row.getCell(8).setCellValue(grade.getSemester());
				row.getCell(9).setCellValue(grade.getScore());
				index++;
		}
		//���±��������Ȩƽ���֡���ȨGPA
		double MyScore = GetWeiScore(list);
		double MyGPA = GetWeiGPA(list);
		System.out.println(MyScore);
		System.out.println(MyGPA);
		
		HSSFRow rowScore = sheet.createRow(25);
		HSSFCell cellScore = rowScore.createCell(0);
		HSSFCell cellMyScore = rowScore.createCell(1);		
		cellScore.setCellValue("��Ȩƽ����");
		cellMyScore.setCellValue(MyScore);
		
		HSSFRow rowGPA = sheet.createRow(26);
		HSSFCell cellGPA = rowGPA.createCell(0);
		HSSFCell cellMyGPA = rowGPA.createCell(1);
		cellGPA.setCellValue("�ۺϼ�ȨGPA");
		cellMyGPA.setCellValue(MyGPA);	
		//���������ӵ������е���ʽ
		rowScore.setHeight((short) 500);
		rowGPA.setHeight((short) 500);
		HSSFCellStyle style2= wb.createCellStyle();
		style2.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		HSSFFont font2= wb.createFont();
		font2.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		font2.setFontHeightInPoints((short) 13);
		style2.setFont(font2);
		style2.setFillForegroundColor(HSSFColor.LIGHT_GREEN.index);
		style2.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		cellScore.setCellStyle(style2);
		cellMyScore.setCellStyle(style2);
		cellGPA.setCellStyle(style2);
		cellMyGPA.setCellStyle(style2);

		
		//����µĳɼ���NewGrades.xls
		FileOutputStream fileOutputStream = new FileOutputStream("NewGrades.xls");
		wb.write(fileOutputStream);
		wb.close();
		fileOutputStream.close();
		return true;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
}
