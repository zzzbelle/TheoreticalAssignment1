import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class BtnFrame extends JFrame{
	private JPanel buttonPanel;
	private static final int DEFAULT_WIDTH = 300;
	private static final int DEFAULT_HEIGHT = 200;
	public BtnFrame(){
		setSize(DEFAULT_WIDTH,DEFAULT_HEIGHT);
		Image img = new ImageIcon("e.png").getImage();
		setIconImage(img);
		
		//�����ť�������µĳɼ���
		JButton btn = new JButton("����");
		buttonPanel = new JPanel();
		buttonPanel.add(btn);
		add(buttonPanel);  //add panel to frame
			
		ClickAction excelAction = new ClickAction(); //create button action
		btn.addActionListener(excelAction);  //associate action with button
			
	}
	    
	private class ClickAction implements ActionListener{
		public void actionPerformed(ActionEvent event){
			ProcessXls.OutputExcel();
			
			System.exit(0);
		}
	}
	

}

