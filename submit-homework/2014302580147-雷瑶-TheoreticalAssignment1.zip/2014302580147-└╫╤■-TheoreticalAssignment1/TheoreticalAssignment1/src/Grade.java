
public class Grade {
    //��ͷ��
	private long id;
	//�γ�����
	private String name;
	//�γ�����
	private String type;
	//ѧ��
	private double credit;
	//��ʦ
	private String teacher;
	//�ڿ�ѧԺ
	private String institute; 
	//ѧϰ����
	private String study;
	//ѧ��
	private int year;
	//ѧ��
	private String semester; 
	//�ɼ�
	private int score;
	
    public Grade() {  
        super();  
    }
    //�ṩһ���в����Ĺ��췽�����������ɶ���д��Excel�ĵ�
    public Grade(long id,String name,String type,double credit,String teacher,
    		String institute,String study,int year,String semester,int score){
    	super();
    	this.id = id;
    	this.name = name;
    	this.type = type;
    	this.credit = credit;
    	this.teacher = teacher;
    	this.institute = institute;
    	this.study = study;
    	this.year = year;
    	this.semester = semester;
    	this.score = score;
    }
    //getter��setter����
    public long getId(){
    	return id;
    }
    public void setId(long id){
    	this.id = id;
    }
    
    public String getName(){
    	return name;
    }
    public void setName(String name){
    	this.name = name;
    }
    
    public String getType(){
    	return type;
    }
    public void setType(String type){
    	this.type = type;
    }
    
    public double getCredit(){
    	return credit;
    }
    public void setCredit(double credit){
    	this.credit = credit;
    }
    
    public String getTeacher(){
    	return teacher;
    }
    public void setTeacher(String teacher){
    	this.teacher = teacher;
    }
    
    public String getInstitute(){
    	return institute;
    }
    public void setInstitute(String institute){
    	this.institute = institute;
    }
    
    public String getStudy(){
    	return study;
    }
    public void setStudy(String study){
    	this.study = study;
    }
    
    public int getYear(){
    	return year;
    }
    public void setYear(int year){
    	this.year = year;
    }
    
    public String getSemester(){
    	return semester;
    }
    public void setSemester(String semester){
    	this.semester = semester;
    }
    
    public int getScore(){
    	return score;
    }
    public void setScore(int score){
    	this.score = score;
    }
    
    @Override  
    public String toString() {  
        return "Course [id=" + id + ", name=" + name + ", type=" + type  
                + ", credit=" + credit + ", teacher=" + teacher + ", institute=" 
        		+ institute + ", study=" + study + ", year=" + year + ", semester="
        		+ semester + ", score=" + score +"]";
    }  
}
