package Course;

public class Course {
	public Course(){
		
	}
	public static String sCourseNum = "";
	public static String sCourseName = "";
	public static String sCourseType = "";
	public static String sCredit = "";
	public static String sTeacher = "";
	public static String sAcademy = "";
	public static String sYear = "";
	public static String sTerm = "";
	public static String sScore = "";
	
	public String courseNum = "";
	public String courseName = "";
	public String courseType = "";
	public double credit = 0;
	public String teacher = "";
	public String academy = "";
	public String year = "";
	public String term = "";
	public double score = 0;
}
