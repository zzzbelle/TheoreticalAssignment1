package Course;

import java.util.Comparator;

public class CourseCompare implements Comparator<Object> {
	public int compare(Object o1, Object o2){
		Course e1 = (Course)o1;
		Course e2 = (Course)o2;
		if (e1.score > e2.score){
			return -1;
		}
		else{	
			if (e1.score == e2.score){
				return 0;
			}
			else{
				return 1;
			}
		}
	}
}
