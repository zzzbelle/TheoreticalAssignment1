import java.io.File;
import java.io.IOException;

import jxl.write.WriteException;


public class Main {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws WriteException 
	 */
	public static void main(String[] args) throws WriteException, IOException{
		// TODO Auto-generated method stub
		
		System.out.println("-----成绩计算-----");
		System.out.println();
		
		File input = new File("Courses.html");
		
		MainOutPut output = new MainOutPut();
		output.processScoreTable(input);
		System.out.println("Finish.");
	}

}
