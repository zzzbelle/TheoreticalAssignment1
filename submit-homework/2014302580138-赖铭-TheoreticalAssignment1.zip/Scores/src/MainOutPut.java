import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.Vector;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import Course.Course;
import Course.CourseCompare;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

public class MainOutPut {
	private Document html;
	private Vector<Course> courses = new Vector<Course>();
	
	public void createScoreTable(File output) throws WriteException,IOException{
		WritableWorkbook workbook = Workbook.createWorkbook(output);
		
		WritableSheet sheet = workbook.createSheet("成绩", 0);
		
		Label courseNum = new Label(0,0,Course.sCourseNum);
		sheet.addCell(courseNum);
		Label courseName = new Label(1,0,Course.sCourseName);
		sheet.addCell(courseName);
		Label courseType = new Label(2,0,Course.sCourseType);
		sheet.addCell(courseType);
		Label credit = new Label(3,0,Course.sCredit);
		sheet.addCell(credit);
		Label teacher = new Label(4,0,Course.sTeacher);
		sheet.addCell(teacher);
		Label academy = new Label(5,0,Course.sAcademy);
		sheet.addCell(academy);
		Label year = new Label(6,0,Course.sYear);
		sheet.addCell(year);
		Label term = new Label(7,0,Course.sTerm);
		sheet.addCell(term);
		Label score = new Label(8,0,Course.sScore);
		sheet.addCell(score);
		
		int i = 0;
		for (Course course : courses){
			courseNum = new Label(0,i,course.courseNum);
			sheet.addCell(courseNum);
			courseName = new Label(1,i,course.courseName);
			sheet.addCell(courseName);
			courseType = new Label(2,i,course.courseType);
			sheet.addCell(courseType);
			credit = new Label(3,i,String.valueOf(course.credit));
			sheet.addCell(credit);
			teacher = new Label(4,i,course.teacher);
			sheet.addCell(teacher);
			academy = new Label(5,i,course.academy);
			sheet.addCell(academy);
			year = new Label(6,i,course.year);
			sheet.addCell(year);
			term = new Label(7,i,course.term);
			sheet.addCell(term);
			if (course.score < 0){
				score = new Label(8,i,"");
			}
			else{
				score = new Label(8,i,String.valueOf(course.score));
			}
			sheet.addCell(score);
			
			i++;
		}
		Label sGPA = new Label(0,courses.size()+1,"综合加权GPA");
		sheet.addCell(sGPA);
		Label gpa = new Label(1,courses.size()+1,String.valueOf(getTotalGPA()));
		sheet.addCell(gpa);
		
		Label sWeightMean = new Label(0,courses.size()+2,"加权平均分");
		sheet.addCell(sWeightMean);
		Label weightMean = new Label(1,courses.size()+2,String.valueOf(getWeightMean()));
		sheet.addCell(weightMean);
		
		workbook.write();
		workbook.close();
		
	}
	
	public void processScoreTable(File input) throws IOException, WriteException{
		html = Jsoup.parse(input, "gb2312");
		
		Elements trs = html.getElementsByTag("tr");
		
		Element tr = trs.get(0);
		Elements ths = tr.getElementsByTag("th");
		Course.sCourseNum = ths.get(0).text();
		Course.sCourseName = ths.get(1).text();
		Course.sCourseType = ths.get(2).text();
		Course.sCredit = ths.get(3).text();
		Course.sTeacher = ths.get(4).text();
		Course.sAcademy = ths.get(5).text();
		Course.sYear = ths.get(7).text();
		Course.sTerm = ths.get(8).text();
		Course.sScore = ths.get(9).text();
		
		for (int i = 1; i < trs.size(); i++){
			tr = trs.get(i);
			Elements tds = tr.getElementsByTag("td");
			Course course = new Course();
			course.courseNum = tds.get(0).text();
			course.courseName = tds.get(1).text();
			course.courseType = tds.get(2).text();
			course.credit = Double.parseDouble(tds.get(3).text());
			course.teacher = tds.get(4).text();
			course.academy = tds.get(5).text();
			course.year = tds.get(7).text();
			course.term = tds.get(8).text();
			try{
				course.score = Double.parseDouble(tds.get(9).text());
			}
			catch (Exception e){
				course.score = -1;
			}
			courses.addElement(course);
		}
		
		File output = new File("scores.xls");
		createScoreTable(output);
		
	}
	
	@SuppressWarnings("unchecked")
	public void sort(){
		@SuppressWarnings("rawtypes")
		Comparator ct = new CourseCompare();
		Collections.sort(courses, ct);
	}
	
	public double getWeightMean(){
		double creditSum = 0;
		double sum = 0;
		for (Course course : courses){
			if (course.score >= 0){
				creditSum += course.credit;
				sum += course.score * course.credit;
			}
		}
		if (!((Double)creditSum).equals(0.0)){
			return sum / creditSum;
		}
		else{
			return 0;
		}
	}
	
	public double getTotalGPA(){
		double creditSum = 0;
		double sum = 0;
		for (Course course : courses){
			if (course.score > 0){
				creditSum += course.credit;
				sum += course.credit * getGPA(course.score);
			}
		}
		if (!((Double)creditSum).equals(0.0)){
			return sum / creditSum;
		}
		else{
			return 0;
		}
	}
	
	public double getGPA(double score){
		double gpa = 0;
		if (score >= 90){
			gpa = 4;
		}
		if (score < 90 && score >= 85){
			gpa = 3.7;
		}
		if (score < 85 && score >= 82){
			gpa = 3.3;
		}
		if (score < 82 && score >= 78){
			gpa = 3.0;
		}
		if (score < 78 && score >= 75){
			gpa = 2.7;
		}
		if (score < 75 && score >= 72){
			gpa = 2.3;
		}
		if (score < 72 && score >= 68){
			gpa = 2.0;
		}
		if (score < 68 && score >= 64){
			gpa = 1.5;
		}
		if (score < 64 && score >= 60){
			gpa = 1.0;
		}
		if (score < 60){
			gpa = 0;
		}
		return gpa;
	}
	
	
}
