import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Created by inksmallfrog on 10/2/15.
 */
//用Jsoup从html中读取解析课程信息
public class ScoreReader {
    private float averageScore = 0.0f;                      //加权平均分
    private float gpa = 0.0f;                               //加权gpa

    private float scoreSum = 0.0f;                          //分数合计
    private float gpaSum = 0.0f;                            //gpa合计
    private float weight = 0.0f;                            //权重总和

    List<ClassInfo> classInfos = new ArrayList<>();         //链表用于保存各课程信息

    //从文件中读取html
    ScoreReader(File input){
        LoadInfoFromFile(input);
    }

    //解析html中的成绩内容，将其保存到链表中，并计算加权平均分，加权gpa，根据各课程分数进行排序
    public void LoadInfoFromFile(File input){
        try {
            //根据html格式，读取到包含各科信息的块
            Document doc = Jsoup.parse(input, "gb2312");
            Element table = doc.getElementsByTag("table").first();
            Elements items = table.getElementsByTag("tr");

            //逐个循环读取各科信息
            for(Element item : items){
                ClassInfo classInfo = new ClassInfo();
                Elements infos = item.getElementsByTag("td");
                //忽略表格的"th"部分
                if(infos.size() == 0){
                    continue;
                }

                //读取信息并加入链表
                classInfo.LoadInfo(infos);
                classInfos.add(classInfo);

                //成绩、绩点、权重求和
                if(classInfo.getScore() >= 0.0f) {
                    SumAll(classInfo.getScore(), classInfo.getClassCredit());
                }
            }

            //计算平均成绩和绩点
            GenerateAll();

            //对链表进行逆序排序
            classInfos.sort(Comparator.<ClassInfo>reverseOrder());
        }
        catch(IOException e) {
            e.printStackTrace();
        }
    }

    //成绩求和
    public void SumScore(float score, float credit){
        scoreSum += score * credit;
    }

    //绩点求和
    public void SumGpa(float score, float credit){
        if (score >= 90.0f) {
            gpaSum += credit * 4.0f;
        } else if (score >= 85.0f) {
            gpaSum += credit * 3.7f;
        } else if (score >= 82.0f) {
            gpaSum += credit * 3.3f;
        } else if (score >= 78.0f) {
            gpaSum += credit * 3.0f;
        } else if (score >= 75.0f) {
            gpaSum += credit * 2.7f;
        } else if (score >= 72.0f) {
            gpaSum += credit * 2.3f;
        } else if (score >= 68.0f) {
            gpaSum += credit * 2.0f;
        } else if (score >= 64.0f) {
            gpaSum += credit * 1.5f;
        } else if (score >= 60.0f) {
            gpaSum += credit * 1.0f;
        } else {
            gpaSum += 0.0f;
        }
    }

    //权重求和
    public void SumWeight(float credit){
        weight += credit;
    }

    //全部求和
    public void SumAll(float score, float credit){
        SumScore(score, credit);
        SumGpa(score, credit);
        SumWeight(credit);
    }

    //计算加权平均分
    public void GenerateAverageScore(){
        averageScore = scoreSum / weight;
    }

    //计算加权gpa
    public void GenerateGPA(){
        gpa = gpaSum / weight;
    }

    //计算平均分和平均gpa
    public void GenerateAll(){
        GenerateAverageScore();
        GenerateGPA();
    }

    public float getAverageScore() {
        return averageScore;
    }

    public float getGpa() {
        return gpa;
    }

    public List<ClassInfo> getClassInfos() {
        return classInfos;
    }
}