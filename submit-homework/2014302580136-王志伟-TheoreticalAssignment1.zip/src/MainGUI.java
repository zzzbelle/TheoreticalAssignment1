import javax.swing.*;

import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

/**
 * Created by inksmallfrog on 10/2/15.
 */
//Gui程序入口
public class MainGUI extends JFrame{
    public static void main(String[] args){
        EventQueue.invokeLater(new Runnable() {
            @Override
            //在运行队列中加入登录界面
            public void run() {
                LoginGui frame = new LoginGui(fileName);
                frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                frame.setVisible(true);
                frame.setTitle("成绩爬取--登录");
            }
        });
    }

    //当登录成功后，进入表格界面
    public static void EnterTableGui(){
        TableGui frame = new TableGui();
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setTitle("成绩爬取--计算");
    }

    //设置保存文件的文件名
    public static String fileName = "./products/scoreChart";
}