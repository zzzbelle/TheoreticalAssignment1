import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

/**
 * Created by inksmallfrog on 10/2/15.
 */
//表格界面窗口
public class TableGui extends JFrame{
    private java.util.List<ClassInfo> classInfos;    //各课程信息
    //表头
    private String[] headers = {
            "课头号",
            "课程名称",
            "课程类型",
            "学分",
            "教师",
            "授课学院",
            "学习类型",
            "学年",
            "学期",
            "成绩"
    } ;

    JPanel mainPanel;                               //主面板
    JTable table;                                   //表格
    JScrollPane scrollPane;                         //滚动条窗格
    JButton exportButton;                           //导出按钮

    TableGui(){
        setSize(1024, 768);

        //创建主面板
        mainPanel = new JPanel();
        mainPanel.setSize(getWidth(), getHeight());
        mainPanel.setLayout(null);

        //创建表格
        CreateTable();

        //创建表格的滚动窗格
        scrollPane = new JScrollPane(table);
        scrollPane.setBounds(0, 0, mainPanel.getWidth(), mainPanel.getHeight() - 80);
        mainPanel.add(scrollPane);

        //创建导出按钮
        exportButton = new JButton("导出");
        exportButton.setBounds(mainPanel.getWidth() - 150, mainPanel.getHeight() - 70, 100, 25);
        exportButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                XLSXOperator xls = new XLSXOperator(MainGUI.fileName);
                xls.XLSXExport(table);
                JOptionPane.showMessageDialog(null, "数据导出完毕， 导出文件名: " + MainGUI.fileName + ".xlsx");
            }
        });
        mainPanel.add(exportButton);


        //将主面板添加至界面
        add(mainPanel);

        //监听窗口组件事件，对窗口大小的改变作出响应
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                super.componentResized(e);
                Reset();
            }
        });
    }

    //创建表格
    public void CreateTable(){
        //解析html获取课程信息
        ScoreReader test = new ScoreReader(new File(MainGUI.fileName + ".html"));
        classInfos = test.getClassInfos();

        //根据信息量创建相应大小的表格
        table = new JTable(classInfos.size() + 3, 10);

        //设置表头
        for(int i = 0; i < headers.length; ++i){
            table.setValueAt(headers[i], 0, i);
        }

        //设置表格绘制渲染器
        table.setDefaultRenderer(Object.class, new TableRenderer());

        //将课程信息逐行填入表格
        int i = 1;
        for(ClassInfo classInfo : classInfos){
            table.setValueAt(classInfo.getClassId(), i, 0);
            table.setValueAt(classInfo.getClassName(), i, 1);
            table.setValueAt(classInfo.getClassType(), i, 2);
            table.setValueAt(classInfo.getClassCredit(), i, 3);
            table.setValueAt(classInfo.getTeacherName(), i, 4);
            table.setValueAt(classInfo.getClassSchool(), i, 5);
            table.setValueAt(classInfo.getStudyType(), i, 6);
            table.setValueAt(classInfo.getSchoolYear(), i, 7);
            table.setValueAt(classInfo.getTerm(), i, 8);

            //若成绩大于0.0,则向单元格填写成绩
            float score = classInfo.getScore();
            if(score >= 0.0){
                table.setValueAt(classInfo.getScore(), i, 9);
            }

            ++i;
        }

        //最后两行显示统计结果，即加权平均分和加权gpa
        table.setValueAt("总计：", i, 0);
        table.setValueAt("加权平均分:", i + 1, 0);
        table.setValueAt(test.getAverageScore(), i + 1, 1);
        table.setValueAt("加权gpa:", i + 1, 3);
        table.setValueAt(test.getGpa(), i + 1, 4);
    }

    //窗口重置，对窗口的大小变化做出响应
    public void Reset(){
        mainPanel.setSize(getWidth(), getHeight());
        scrollPane.setBounds(0, 0, mainPanel.getWidth(), mainPanel.getHeight() - 80);
        exportButton.setBounds(mainPanel.getWidth() - 150, mainPanel.getHeight() - 70, 100, 25);
    }
}

//表格渲染器
class TableRenderer implements TableCellRenderer {
    //渲染器继承自默认渲染器
    public static final DefaultTableCellRenderer DEFAULT_RENDERER = new DefaultTableCellRenderer();

    @Override
    //对成绩小于60.0，和没有成绩的行进行特殊渲染
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        Component renderer = DEFAULT_RENDERER.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        //判断是否为课程信息所在行
        if(row < table.getRowCount() - 2){
            if(row != 0 && column == 0){
                //取得该行对应的成绩值
                Object score = table.getValueAt(row, 9);
                //成绩值为空则用灰色渲染
                if(score == null){
                    renderer.setForeground(Color.gray);
                }
                //成绩值小于60.0则用红色渲染
                else if(Float.parseFloat(score.toString()) < 60.0f){
                    renderer.setForeground(Color.red);
                }
                else{
                    renderer.setForeground(Color.black);
                }
            }
        }
        //否则用默认的黑色渲染
        else{
            renderer.setForeground(Color.black);
        }

        return renderer;
    }
}