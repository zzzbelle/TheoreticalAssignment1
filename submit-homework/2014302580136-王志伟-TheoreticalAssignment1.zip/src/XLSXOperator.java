import com.sun.deploy.uitoolkit.impl.fx.ui.FXMessageDialog;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.*;

import javax.swing.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by inksmallfrog on 10/2/15.
 */
//用poi对XLS进行操作
public class XLSXOperator{
    private String fileName;

    XLSXOperator(String _fileName){
        fileName = _fileName + ".xlsx";
    }

    //JTable导出XLSX格式
    void XLSXExport(JTable table){
        try{
            //创建工作薄和表格
            XSSFWorkbook workbook = new XSSFWorkbook();
            FileOutputStream out = new FileOutputStream(new File(fileName));
            XSSFSheet sheet = workbook.createSheet("Score");

            //设置表头样式
            CellStyle style_head = workbook.createCellStyle();
            style_head.setAlignment(CellStyle.ALIGN_CENTER);

            //设置挂科样式
            CellStyle style_red = workbook.createCellStyle();
            Font font_red = workbook.createFont();
            font_red.setColor(IndexedColors.RED.getIndex());
            style_red.setFont(font_red);

            //设置未修完的课程样式
            CellStyle style_gray = workbook.createCellStyle();
            Font font_gray = workbook.createFont();
            font_gray.setColor(IndexedColors.GREY_40_PERCENT.getIndex());
            font_gray.setItalic(true);
            style_gray.setFont(font_gray);

            //逐行导出成绩单
            for(int i = 0; i < table.getRowCount(); ++i){
                XSSFRow row = sheet.createRow(i);
                if(i == 0){
                    row.setRowStyle(style_head);
                }
                //逐列输出信息
                for(int j = 0; j < table.getColumnCount(); ++j){
                    XSSFCell cell = row.createCell(j);
                    Object data = table.getValueAt(i, j);
                    if(data != null) {
                        //根据成绩列信息，判断是否挂科
                        if(i != 0 && j == 9){
                            float score = Float.parseFloat(data.toString());
                            cell.setCellValue(score);
                            if(score < 60.0){
                                row.setRowStyle(style_red);
                            }
                        }
                        //将信息以字符串形式存入单元格
                        else{
                            cell.setCellValue(data.toString());
                        }
                    }
                    //如果成绩列的信息为空，则启用相应样式
                    else if(j == 9 && i < table.getRowCount() - 2){
                        row.setRowStyle(style_gray);
                    }
                }
            }

            //设置部分列的列宽
            sheet.setColumnWidth(0, 4500);
            sheet.setColumnWidth(1, 4500);
            sheet.setColumnWidth(2, 3072);
            sheet.setColumnWidth(4, 4500);
            sheet.setColumnWidth(5, 4500);

            //写出文件
            workbook.write(out);
            out.close();
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }
}