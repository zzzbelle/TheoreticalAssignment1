
public class Course {
	int size=10;
	String[] Courses=new String[size];
	public void Course(String CourseNumber,String CourseName,String CourseType,String Credit,String Teacher,
			String Institute,String LearningType,String  SchoolYear,String Term,String Grade){
		Courses[0]=CourseNumber;
		Courses[1]=CourseName;
		Courses[2]=CourseType;
		Courses[3]=Credit;
		Courses[4]=Teacher;
		Courses[5]=Institute;
		Courses[6]=LearningType;
		Courses[7]=SchoolYear;
		Courses[8]=Term;
		Courses[9]=Grade;
	}
	@Override
	public String toString()
    {
        return Courses[0] +" " + Courses[1]+" "  + Courses[2]+" " +Courses[3] +" "+Courses[4] + " "
        		+Courses[5] +" "+ Courses[6] +" " + Courses[7] +" "+  Courses[8]+" "  + Courses[9];
    }
}
