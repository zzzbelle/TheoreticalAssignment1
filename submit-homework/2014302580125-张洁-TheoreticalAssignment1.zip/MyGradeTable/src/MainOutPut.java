import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import java.util.Scanner;
public class MainOutPut {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// public ArrayList<Course> course=new ArrayList<Course>();
		 String[] Grade=new String[25];
		 int[] a=new int[25];//��¼�ɼ�
		 float[] b=new float[25];//��¼ѧ��
		 double[] c=new double[25];//��¼GPA
		 float WeightedAverage=0;//��Ȩƽ����
		 double WeightedGPA=0;//�ۺϼ�ȨGPA
		try(FileWriter fw = new FileWriter("MyGradeTable.txt");){
			Scanner in=new Scanner(new File("C:/Users/dell/workspace/MyGradeTable/�ҵĳɼ���.txt"));
			int line=0;
			while(line==0){
				String t=in.nextLine();
				line++;
				fw.write(t+"\r\n");
			}
		for(int i=0;i<25;i++){//���ı��ж�������
			Course course=new Course();
				String str=in.nextLine();
				String strr=str.trim();//ɾ���ַ�����β�ո�
				String[] abc=strr.split("[\\p{Space}]+");
				String str1=abc[0];
				String str2=abc[1];
				String str3=abc[2];
				String str4=abc[3];
				String str5=abc[4];
				String str6=abc[5];
				String str7=abc[6];
				String str8=abc[7];
				String str9=abc[8];
				String str10=abc[9];
	            course.Course(str1,str2,str3,str4,str5,str6,str7,str8,str9,str10);
				Grade[i]=course.toString();
				int n= Integer.parseInt(str10);
				float  m=Float.parseFloat(str4);
				a[i]=n;//�ɼ�
				b[i]=m;//ѧ��
				if(n>=90){
					c[i]=4.0;
				}
				else if(n>=85){
					c[i]=3.7;
				}
				else if(n>=82){
					c[i]=3.3;
				}
				else if(n>=78){
					c[i]=3.0;
				}
				else if(n>=75){
					c[i]=2.7;
				}
				else if(n>=72){
					c[i]=2.3;
				}
				else if(n>=68){
					c[i]=2.0;
				}
				else if(n>=64){
					c[i]=1.5;
				}
				else if(n>=60){
					c[i]=1.0;
				}
				else{
					c[i]=0;
				}
				//fw.write(Grade[i]);
				//fw.write(course.toString());
				//fw.write(String.valueOf(c[i]));
				//fw.write("\r\n");
		}
		for(int i=0;i<25;i++){
			for(int j=i+1;j<25;j++){
				if(a[j]>a[i]){//�Ƚϳɼ��Ĵ�С
					String t=Grade[i];
					Grade[i]=Grade[j];
					Grade[j]=t;
					int m=a[i];
					a[i]=a[j];
					a[j]=m;
				}
			}
			fw.write(Grade[i]);//���ɼ��Ӹߵ�������
			fw.write("\r\n");
		}
		float t=0;//��������ѧ��
		float p=0;//ѧ�ֺ�
		double q=0;//GPA����ѧ��
		for(int i=0;i<25;i++){
			q=c[i]*b[i]+q;
			 t=a[i]*b[i]+t;
			 p=b[i]+p;
		}
		 WeightedAverage=t/p;//��Ȩƽ����
		 WeightedGPA=q/p;//�ۺϼ�ȨGPA
		 fw.write("��Ȩƽ����Ϊ��"+String.valueOf(WeightedAverage)+"\r\n");
		 fw.write("�ۺϼ�ȨGPAΪ��"+String.valueOf(WeightedGPA)+"\r\n");
		}
		catch (IOException ioe) {
			 ioe.printStackTrace();
		}
			}

}