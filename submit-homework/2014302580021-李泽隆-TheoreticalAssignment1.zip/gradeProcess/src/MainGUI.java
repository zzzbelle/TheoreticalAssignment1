import java.awt.*;
import javax.swing.JFrame;
public class MainGUI 
{
	public static void main(String[] args) throws Exception
	{
		Runnable a=new Runnable()
		{
			public void run()
			{
				JFrame button=new ButtonFrame();
				button.setTitle("grade");
				button.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				button.setVisible(true);
				button.setResizable(false);
				
			}
			
		};
		EventQueue.invokeLater(a);

	}
}