package cn.edu;

import java.io.File;

public interface MainOutPut {
		public void processScoreTable(File GradeInput);
			
	
}
