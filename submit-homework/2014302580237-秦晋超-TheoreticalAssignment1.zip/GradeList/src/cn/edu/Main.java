package cn.edu;

import java.io.File;
import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException{

		
		
		Grade a= new Grade();
		File FileName = new File("Grade.html");
		a.processScoreTable(FileName);
		a.Sort();
		a.Avg();
		a.Output();
	     
   
	     
       }
}
