package cn.edu;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Grade {
	//����洢�ɼ�
	 public String [][] ar =new String[13][3];
	 public double avg =0;
	 public double GPA =0;
	 //ץȡ�ɼ���������
public void processScoreTable(File GradeInput) throws IOException{
		 
		  	//File GradeInput =new File(FileName);
		 	//��ȡ�ɼ���ҳ
		 	Document GradeDoc = Jsoup.parse(GradeInput,"GBK");
		 	//ѡȡ��ҳ�����е� Ԫ��
		 	Elements tr = GradeDoc.select("table").select("tr");
		 	//��14�ſγ�
		 	for(int i = 0;i<13;i++) {
		 		Elements td = tr.get(i+1).select("td");
		 		//�γ���
		 		ar[i][0]= td.get(1).text();	        
		 		//ѧ��
		 		ar[i][1]= td.get(3).text();
		 		//����
		 		ar[i][2]= td.get(9).text();

		 		}  
		 	
	 		}
	 //����
	 public void Sort(){

		 String [][] br =new String[1][3];
		 for (int i = 12; i >0; i--) {
		
			 for (int j = 0; j < i; j++) {
				//int a =Integer.valueOf(ar[j][2]).intValue();
				double a=Double.parseDouble(ar[j][2]);
				//int b =Integer.valueOf(ar[j+1][2]).intValue();
				double b=Double.parseDouble(ar[j+1][2]);
				 if (a <= b) {
					 br[0][0] =ar[j][0];
					 br[0][1] =ar[j][1];
					 br[0][2] =ar[j][2];
					
					 ar[j][0] =ar[j+1][0];
					 ar[j][1] =ar[j+1][1];
					 ar[j][2] =ar[j+1][2];
					 
					 ar[j+1][0]=br[0][0];
					 ar[j+1][1]=br[0][1];
					 ar[j+1][2]=br[0][2];
				}
				 
			}
			 
			
		}
		 
	
	 }
	//GPA AVG
	 public void Avg (){
		 double s =0;
		 double c =0;
		 for (int j = 0; j < ar.length; j++) {
			 
			 double a=Double.parseDouble(ar[j][1]);
			 double b=Double.parseDouble(ar[j][2]);
			 s =+a*b;
			 c =+ a; 	 
		}
		 avg = s/c;
		 GPA = avg/100*4;
	
		 
	 }
	 //������ļ�
	public void Output() throws IOException{ 
		
		PrintWriter txt = new PrintWriter("Grade.txt");
		txt.write("�γ���"+"  "+"�ɼ�");
		for (int i = 0; i < ar.length; i++) {
		txt.write(ar[i][0]+"  "+ar[i][2]);
		}
		txt.write("��Ȩƽ���֣�"+avg);
		txt.write("GPA:"+GPA);
		txt.close();
	}
}
