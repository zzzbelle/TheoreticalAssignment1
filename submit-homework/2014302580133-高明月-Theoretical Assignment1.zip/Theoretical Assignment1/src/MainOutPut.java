import java.io.File;
 
import jxl.*;  
import jxl.write.*;   
import jxl.write.Number;
import jxl.write.WritableWorkbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import java.io.FileInputStream;
import jxl.Workbook;
import jxl.Cell;
import java.io.*; 


public class MainOutPut
{
	    private String subject;
		private String type;
		private double credit;
		private String teacher;
		private String department;
		private String studyType;
		private String year;
		private String semester;
		private double grade;

		public MainOutPut(String subject,String type,double credit, String teacher, String department,String studyType, String year, String semester, double grade)
		{  
			this.subject = subject;
			this.type = type;
			this.credit = credit;
			this.teacher = teacher;
			this.department = department;
			this.studyType = studyType;
			this.year = year;
			this.semester = semester;
			this.grade = grade;
		}


	public static void main(String[] args)
	{
		// TODO Auto-generated method stub\
		//��ȡexcel
		try
		{
			 //����Workbook����, ֻ��Workbook���� 
			 //ֱ�Ӵӱ����ļ�����Workbook   
			InputStream is = new FileInputStream("src/book.xls"); 
			 Workbook rwb = Workbook.getWorkbook(is);   
			 //��ȡsheet��:��ȡ��0ҳ
			 Sheet st = rwb.getSheet(0);
			 //��һ��һ���ж�����,������
		    int rsRows = st.getRows();
		 
			 //����һ������
			 MainOutPut mop[]=new MainOutPut[rsRows-1];
				String subject;
				String type;
				double credit;
				String teacher;
				String department;
				String studyType;
				String year;
				String semester;
				double grade;
			 //��ȡ���������������
			 for(int i=1;i<=rsRows-1;i++)
					 {

				 Cell cl0=st.getCell(0,i);
				 subject=cl0.getContents();
				 Cell cl1=st.getCell(1,i);
				 type=cl1.getContents();
				 Cell cl2=st.getCell(2,i);
				 credit= Double.parseDouble(cl2.getContents());
				 Cell cl3=st.getCell(3,i);
				 teacher=cl3.getContents();
				 Cell cl4=st.getCell(4,i);
				 department=cl4.getContents();
				 Cell cl5=st.getCell(5,i);
				 studyType=cl5.getContents();
				 Cell cl6=st.getCell(6,i);
				 year=cl6.getContents();
				 Cell cl7=st.getCell(7,i);
				 semester=cl7.getContents();
				 Cell cl8=st.getCell(8,i);
				 grade= Double.parseDouble(cl8.getContents());
				 
				 mop[i-1]=new MainOutPut(subject,type,credit,teacher,department,studyType,year,semester,grade);
				 
					 }
			 //�����Ȩƽ����
			 double totalGrade=0;
			 double totalCredit=0.0;
			 double totalGPA=0;
			 int j=0;
			 for(j=0;j<rsRows-2;j++)
			 {
				 totalGrade=totalGrade+mop[j].grade*mop[j].credit;
				 totalCredit=totalCredit+mop[j].credit;
				 if(mop[j].grade>=60 && mop[j].grade<=63)
					 totalGPA=totalGPA+1.0*mop[j].credit;
					 if(mop[j].grade>=64&&mop[j].grade<=67)
						 totalGPA=totalGPA+1.5*mop[j].credit;
						 if(mop[j].grade>=68&&mop[j].grade<=71)
							 totalGPA=totalGPA+2.0*mop[j].credit;
							 if(mop[j].grade>=72&&mop[j].grade<=74)
								 totalGPA=totalGPA+2.3*mop[j].credit;
								 if(mop[j].grade>=75&&mop[j].grade<=77)
									 totalGPA=totalGPA+2.7*mop[j].credit;
									 if(mop[j].grade>=78&&mop[j].grade<=81)
										 totalGPA=totalGPA+3.0*mop[j].credit;
										 if(mop[j].grade>=82&&mop[j].grade<=84)
											 totalGPA=totalGPA+3.3*mop[j].credit;
											 if(mop[j].grade>=85&&mop[j].grade<=89)
												 totalGPA=totalGPA+3.7*mop[j].credit;
												 if(mop[j].grade>=90)
													 totalGPA=totalGPA+4.0*mop[j].credit;
			 }
			 double averageGrade;
			 double averageGPA;
			 averageGrade=totalGrade/totalCredit;
			 averageGPA=totalGPA/totalCredit;
			 //�����������ճɼ������γ�һ���µ�����
			 double db;
			 String str;
			 for(int k=1;k<=rsRows-2;k++)
			 {
				 for(int a=rsRows-2;a>=k;a--)
				 {
					 if(mop[a].grade>mop[a-1].grade)
					 {
						str=mop[a].subject;
						mop[a].subject=mop[a-1].subject;
						mop[a-1].subject=str;
						
						str=mop[a].type;
						mop[a].type=mop[a-1].type;
						mop[a-1].type=str;
						
						db=mop[a].credit;
						mop[a].credit=mop[a-1].credit;
						mop[a-1].credit=db;
						
						str=mop[a].teacher;
						mop[a].teacher=mop[a-1].teacher;
						mop[a-1].teacher=str;
						
						str=mop[a].department;
						mop[a].department=mop[a-1].department;
						mop[a-1].department=str;
						
						str=mop[a].studyType;
						mop[a].studyType=mop[a-1].studyType;
						mop[a-1].studyType=str;
						
						str=mop[a].year;
						mop[a].year=mop[a-1].year;
						mop[a-1].year=str;
						
						str=mop[a].semester;
						mop[a].semester=mop[a-1].semester;
						mop[a-1].studyType=str;
						
						db=mop[a].grade;
						mop[a].grade=mop[a-1].grade;
						mop[a-1].grade=db;
					 }
				 }
			 }
		//��WritableWorkbookֱ��д�뵽�����
		try
		{
			WritableWorkbook wwb = Workbook.createWorkbook(new File("src/newtable.xls"));
			//���ɵ�һҳ�Ĺ�����������Ϊ0˵���ǵ�һҳ
			WritableSheet ws = wwb.createSheet("��һҳ", 0);
			//ָ����Ԫ���λ���ǵ�һ�е�һ�У���һ������Ϊ��
			//д�ϱ�����
			Label lb1 = new Label(0,0,"�γ�����");
			Label lb2 = new Label(1,0,"�γ�����");
			Label lb3 = new Label(2,0,"ѧ��");
			Label lb4 = new Label(3,0,"��ʦ");
			Label lb5 = new Label(4,0,"�ڿ�ѧԺ");
			Label lb6 = new Label(5,0,"�ڿ�����");
			Label lb7 = new Label(6,0,"ѧ��");
			Label lb8 = new Label(7,0,"ѧ��");
			Label lb9 = new Label(8,0,"�ɼ�");
			ws.addCell(lb1);
			ws.addCell(lb2);
			ws.addCell(lb3);
			ws.addCell(lb4);
			ws.addCell(lb5);
			ws.addCell(lb6);
			ws.addCell(lb7);
			ws.addCell(lb8);
			ws.addCell(lb9);
			//д��������ѧ�������йص���
			NumberFormat nf = new NumberFormat("#.##"); 
			WritableCellFormat wcfN = new WritableCellFormat(nf); 
			for(int a=1;a<=rsRows-1;a++)
			{
				 Label label1= new Label(0,a,mop[a-1].subject);
				 ws.addCell(label1); 
				 
				 Label label2= new Label(1,a,mop[a-1].type);
				 ws.addCell(label2);
				 
				 Number label3 = new jxl.write.Number(2,a,mop[a-1].credit,wcfN);  
				 ws.addCell(label3);
				 
				 Label label4= new Label(3,a,mop[a-1].teacher);
				 ws.addCell(label4);
				 
				 Label label5= new Label(4,a,mop[a-1].department);
				 ws.addCell(label5);
				 
				 Label label6= new Label(5,a,mop[a-1].studyType);
				 ws.addCell(label6);
				 
				 Label label7= new Label(6,a,mop[a-1].year);
				 ws.addCell(label7);
				 
				 Label label8= new Label(7,a,mop[a-1].semester);
				 ws.addCell(label8);
				 
				 Number label9 = new jxl.write.Number(8,a,mop[a-1].grade);  
				 ws.addCell(label9);
			}
			//д���Ȩƽ����
			Label lab1 = new Label(0,rsRows,"ƽ����");
			ws.addCell(lab1);
			Number lab2 = new jxl.write.Number(1,rsRows,averageGrade);  
			 ws.addCell(lab2);
			 
			 //д���ۺϼ�ȨGPA
			 Label lab3 = new Label(4,rsRows,"��ȨGPA");
				ws.addCell(lab3);
				Number lab4 = new jxl.write.Number(5,rsRows,averageGPA);  
				 ws.addCell(lab4);
				 
			//д�빤����
			wwb.write();
			wwb.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();   
	         System.out.println("error");
		}
		 rwb.close();   
		}
		catch (Exception e)
		{   
			  
            e.printStackTrace();   
  
        } 
		
	}
}
			 
			 
		

	
	

