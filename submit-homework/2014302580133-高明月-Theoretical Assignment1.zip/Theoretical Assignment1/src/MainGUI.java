
	import java.io.*;  
	import javax.swing.*;
	import java.awt.event.*;

	public class MainGUI implements ActionListener
	{
	public void run(){
		JFrame  frame =new JFrame();
		JButton bt= new JButton("��������");
		bt.addActionListener(this);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		
		frame.setVisible(true);
		frame.getContentPane().add(bt);
		frame.setSize(600, 600);
	}
	
	public void actionPerformed(ActionEvent event)
	{
		String[]i = {};
		MainOutPut.main(i);
		try 
		{
			Runtime.getRuntime().exec("cmd /c start src/newtable.xls");
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		}
		System.exit(0);
	}
	public static void main(String[] arg)
	{
		// TODO Auto-generated method stub
		MainGUI gui = new MainGUI();
		gui.run();
		
		
	}
	}		