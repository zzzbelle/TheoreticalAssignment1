/**
 * 
 */
package Text;


public class MainGUI {

	/**
	 * @param args
	 * @throws IOException 
	 */

	public static void main(String[] args)  {
		GUI gui=new GUI();
		
	}

	
}
