package Text;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class GUI extends JFrame implements ActionListener {

	public GUI()
	{
		setTitle("��Ӣ��");
		setBounds(400,200,400,400);
		setVisible(true);
		setDefalutCloseOPeration(EXIT_ON_CLOSE);
		JButton j=new JButton("���ִ�в���");
		this.getContentPane().add(j);
		j.setBounds(250, 150, 100, 30);
		j.addActionListener(this);
		
	}
	private void setDefalutCloseOPeration(int exitOnClose) {
		// TODO Auto-generated method stub
		
	}
	private void setDefalutCloseOPeration() {
		// TODO Auto-generated method stub
		
	}
	public static void sort(float[] a)
	{
		float temp=(float) 0.0;
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[j]>a[i])
				{
					temp=a[j];
					a[j]=a[i];
					a[i]=temp;
				}
			}
		}
		
	}
 public static float CalGPA(float[] chengji,float[] score){
	 float Jidian=0;//����
	 float GPA=0;//���޿γ�ѧ�ּ�֮��
	 float GPA1=0;//ƽ��ѧ�ּ��㣨GPA��
	 int sum=0;//���޿γ�ѧ��֮��
	 for(int i=0;i<26;i++)
	 {
		 if (chengji[i]>=90) Jidian=(float) 4.0;
		 else if(chengji[i]<90&&chengji[i]>=85)Jidian=(float)3.7;
		 else if(chengji[i]<85&&chengji[i]>=82)Jidian=(float)3.3;
		 else if(chengji[i]<82&&chengji[i]>=78)Jidian=(float)3.0;
		 else if(chengji[i]<78&&chengji[i]>=75)Jidian=(float)2.7;
		 else if(chengji[i]<75&&chengji[i]>=72)Jidian=(float)2.3;
		 else if(chengji[i]<72&&chengji[i]>=68)Jidian=(float)2.0;
		 else if(chengji[i]<68&&chengji[i]>=64)Jidian=(float)1.5;
		 else if(chengji[i]<64&&chengji[i]>=60)Jidian=(float)1.0;
		 else if(chengji[i]<60)Jidian=(float)0;
		GPA+=score[i]*Jidian;
		sum+=score[i];
	 }
	 GPA1=GPA/sum;
	 return GPA1;
 }
 public static float Average(String[] a,float[] chengji,float[] score){
	 int sum=0;//���޿�ѧ��֮��
	 float ave2=0;//ѡ�޵�ѧ�ּ�֮��
	 float ave=0;//���޵�ѧ�ּ�֮��
	 float ave1=0;//��Ȩƽ���ɼ�
	 for(int i=0;i<26;i++)
	 {
		 if(a[i].equals("��������")|a[i].equals("רҵ����"))
		 {
			 sum+=score[i];
			 ave+=chengji[i]*score[i];
		 }
		 else
		 {
			 ave2+=chengji[i]*score[i]*0.002;
		 }
	 }
	 ave1=ave/sum+ave2;
	 return ave1;
 }
@Override
public void actionPerformed(ActionEvent e) {
	try{
		FileInputStream sFileInputStream=new FileInputStream("chengji.xls");
		Workbook aHssfWorkbook;
		aHssfWorkbook = new HSSFWorkbook(sFileInputStream);
		Sheet aSheet=aHssfWorkbook.getSheetAt(0);
		int n=0;
		boolean b=false;
		while(true)
		{
				
			try {
				if(! aSheet.getRow(n).getCell(9).toString().isEmpty())
					n++;
			} catch (Exception e1) {
				b=true;// TODO: handle exception
			}
			if(b==true)
				break;
		}
		float[] grade=new float[n-1];
		for(int i=0;i<n-1;i++)
		{
			grade[i]=Float.parseFloat(aSheet.getRow(i+1).getCell(9).toString());
		}
		
		sort(grade);
		HSSFWorkbook aHssfWorkbook2=new HSSFWorkbook();
		HSSFSheet aHssfSheet=aHssfWorkbook2.createSheet("�ɼ�����");
		Vector<HSSFRow> aHssfRows=new Vector<HSSFRow>();
		aHssfRows.add(aHssfSheet.createRow(0));
		for(int i=0;i<10;i++)
		{
			aHssfRows.get(0).createCell((short)i).setCellValue(aSheet.getRow(0).getCell(i).toString());
		}
		for(int i=0;i<n-1;i++)
		{
			aHssfRows.add(aHssfSheet.createRow(i+1));
		}
		//��ԭ���������������д���µı���
		for(int i=0;i<n-1;i++)
		{
			for(int j=0;j<n-1;j++)
			{
				if(Float.parseFloat(aSheet.getRow(i+1).getCell(9).toString())==grade[j])
				{
					for(int h=0;h<10;h++)
					{
						aHssfRows.get(j+1).createCell((short)h).setCellValue(aSheet.getRow(i+1).getCell(h).toString());
					}
					grade[j]=-1;
					
				}
			}
			
		}
		String[] a=new String[26];
		float[] chengji=new float[26];
		float[] score=new float[26];
		for(int i=1;i<=26;i++)
		{
			a[i-1]= aSheet.getRow(i).getCell(2).toString();
			chengji[i-1]=Float.parseFloat(aSheet.getRow(i).getCell(9).toString());
			score[i-1]=Float.parseFloat(aSheet.getRow(i).getCell(3).toString());
		}
		float Jidian=CalGPA(chengji,score);
		float ave=Average(a,chengji,score);
		aHssfRows.get(0).createCell((short)10).setCellValue("ƽ������");//������ƽ�����㣩��Ԫ��
		aHssfRows.get(0).createCell((short)11).setCellValue("��Ȩƽ����");
		aHssfRows.get(1).createCell((short)10).setCellValue(Jidian);
		aHssfRows.get(1).createCell((short)11).setCellValue(ave);
		FileOutputStream outputStream=new FileOutputStream("grade.xls");
		aHssfWorkbook2.write(outputStream);
		outputStream.close();
		System.out.print("ִ�гɹ�");// TODO Auto-generated method stub
	}
	catch(Exception e2)
	{
		e2.printStackTrace();
	}
	
	
}
}
