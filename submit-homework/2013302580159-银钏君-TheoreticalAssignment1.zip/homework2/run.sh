#!/bin/sh

filepath=$(cd "$(dirname "$0")"; pwd)
CLASSPATH=$filepath"/lib/jsoup-1.8.3.jar":$filepath"/lib/jxl.jar:$CLASSPATH"
cd $filepath
javac -g:none -nowarn ./src/*.java -d ./out/
cd out
java MainGUI
