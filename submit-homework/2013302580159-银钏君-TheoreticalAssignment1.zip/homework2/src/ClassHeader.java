/**
 * Created by fuxiuyin on 15-10-7.
 */

import java.io.*;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.*;
import jxl.write.Label;
import jxl.write.biff.RowsExceededException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import javax.swing.*;

public class ClassHeader
{
    private String XLSPath = "./score.xls";
    private String resultPath = "./score_result.xls";

    public ClassHeader(JTextArea textArea)
    {
        File file = new File(XLSPath);
        if(file.exists())
        {
            file.delete();
            textArea.append(String.format("删除%s\n", file.getAbsolutePath()));
        }
        file = new File(resultPath);
        if(file.exists())
        {
            file.delete();
            textArea.append(String.format("删除%s\n", file.getAbsoluteFile()));
        }
    }

    public boolean readHTMLAndWrite(JTextArea textArea)
    {
        List<List<String>> datas = getAllSource(textArea);
        if(datas == null)
        {
            textArea.append("读取HTML文件失败\n");
            return false;
        }
        return writeXLS(datas, false, XLSPath, textArea);
    }

    public boolean readXLSAndWrite(JTextArea textArea)
    {
        File file = new File(XLSPath);
        InputStream in;
        Workbook wb;
        try
        {
            in = new FileInputStream(file);
            wb = Workbook.getWorkbook(in);
        }
        catch (FileNotFoundException e)
        {
            textArea.append(String.format("找不到文件%s\n请先处理HTML\n", file.getAbsoluteFile()));
            return false;
        }
        catch (BiffException e)
        {
            textArea.append(String.format("%s打开失败\n", file.getAbsoluteFile()));
            return false;
        }
        catch (IOException e)
        {
            textArea.append(String.format("%s打开失败\n", file.getAbsoluteFile()));
            return false;
        }
        Sheet sheet = wb.getSheet(0);
        List<List<String>> datas = new ArrayList<List<String>>();
        for(int i = 1; i < sheet.getRows(); i++)
        {
            List<String> row = new ArrayList<String>();
            for (int j = 0; j < sheet.getColumns(); j++)
            {
                Cell cell = sheet.getCell(j, i);
                row.add(cell.getContents());
            }
            datas.add(row);
        }
        return writeXLSWithSort(datas, textArea);
    }

    private Document getDoucment(String filePath) throws IOException
    {
        File file = new File(filePath);
        if(!file.exists())
        {
            throw new IOException();
        }
        return Jsoup.parse(file, "UTF-8");
    }

    private List<List<String>> getAllSource(JTextArea textArea)
    {
        String filePath = "./score.html";
        Document document = null;
        try
        {
            document = getDoucment(filePath);
        }
        catch (IOException e)
        {
            e.printStackTrace();
            textArea.append(String.format("打开成绩文件:%s/score.html失败\n", System.getProperty("user.dir")));
            return null;
        }
        List<List<String>> result = new ArrayList<List<String>>();
        Element pointElement = document.body();
        pointElement = pointElement.getElementsByTag("table").first();
        pointElement = pointElement.getElementsByTag("tbody").first();
        int x, y;  // 用来过滤没用的数据的
        x = y = 0;
        for(Element tr : pointElement.getElementsByTag("tr"))
        {
            List<String> classSources = new ArrayList<String>();
            Elements elements;
            ++x;
            if (x == 1)
                continue;
            else
                elements = tr.getElementsByTag("td");
            for(Element td : elements)
            {
                ++y;
                if(y == 11)
                {
                    y = 0;
                    continue;
                }
                classSources.add(td.html());
            }
            ++x;
            result.add(classSources);
        }
        return result;
    }

    private File openNewFile(String filePath, JTextArea textArea)
    {
        File file = new File(filePath);
        if(file.exists())
        {
            try
            {
                // 如果文件存在就删除在创建一个
                file.delete();
                file.createNewFile();
            }
            catch (IOException e)
            {
                e.printStackTrace();
                textArea.append(String.format("重新创建%s失败\n", file.getAbsolutePath()));
                return null;
            }
        }
        else
        {
            try
            {
                file.createNewFile();
            }
            catch (IOException e)
            {
                e.printStackTrace();
                textArea.append(String.format("创建文件:%s失败\n", file.getAbsolutePath()));
            }
        }
        return file;
    }

    private boolean writeXLS(List<List<String>> datas, boolean withAverage, String filePath, JTextArea textArea)
    {
        File file = openNewFile(filePath, textArea);
        if(file == null)
        {
            textArea.append("写入成绩失败\n");
            return false;
        }
        WritableWorkbook wb = null;
        try
        {
            OutputStream stream = new FileOutputStream(file);
            wb = Workbook.createWorkbook(stream);
        }
        catch (FileNotFoundException e)
        {
            textArea.append("写入成绩失败\n");
            return false;
        }
        catch (IOException e)
        {
            textArea.append(String.format("无法读取:%s\n", file.getAbsolutePath()));
            textArea.append("写入成绩失败\n");
            return false;
        }
        WritableSheet sheet = wb.createSheet("成绩", 0);
        int lineNum, rowNum;  // 写入xls文件的位置
        int countSuccess, countFail; // 计数
        countSuccess = countFail = 0;
        lineNum = rowNum = 0;
        Label label;
        List<String> title = new ArrayList<String>();
        double weightTotal = 0;  // 总学分
        double weightScoreTotal = 0;  // 总得到学分
        double scoreTotal = 0;  // 乘过学分的总成绩
        // 给表加上title
        title.add("课头号");
        title.add("课程名称");
        title.add("课程类型");
        title.add("学分");
        title.add("教师");
        title.add("授课学院");
        title.add("学习类型");
        title.add("学年");
        title.add("学期");
        title.add("成绩");
        datas.add(0, title);
        WritableCellFormat wc = new WritableCellFormat();
        try
        {
            wc.setAlignment(Alignment.CENTRE);
        }
        catch (WriteException e)
        {
            textArea.append("设置单元格居中失败\n采用默认模式\n");
        }
        for(List<String> line : datas)
        {
            String scores = line.get(9);
            if(!scores.equals("") && !scores.equals("成绩"))
            {
                Double score = Double.parseDouble(line.get(9));
                if(score >= 60.0)
                {
                    Double weight = Double.parseDouble(line.get(3));
                    Double weightScore = getWeight(score);
                    weightScoreTotal += (weightScore * weight);
                    scoreTotal += (weight * score);
                    weightTotal += weight;
                }
            }
            for(String data : line)
            {
                label = new Label(rowNum, lineNum, data, wc);
                ++rowNum;
                try
                {
                    sheet.addCell(label);
                    ++countSuccess;
                }
                catch (jxl.write.biff.RowsExceededException e)
                {
                    textArea.append("写入单元格失败\n");
                    ++countFail;
                }
                catch (WriteException e)
                {
                    textArea.append("写入单元格失败\n");
                    ++countFail;
                }
            }
            ++lineNum;
            rowNum = 0;
        }
        if(withAverage)
        {
            Double scoreAverage = scoreTotal / weightTotal;
            Double weightScoreAverage = weightScoreTotal / weightTotal;
            DecimalFormat fnum = new DecimalFormat("0.00");

            try {
                label = new Label(0, lineNum, "平均", wc);
                sheet.addCell(label);
                label = new Label(3, lineNum, fnum.format(weightScoreAverage), wc);
                sheet.addCell(label);
                label = new Label(9, lineNum, fnum.format(scoreAverage), wc);
                sheet.addCell(label);
                countSuccess += 3;
            } catch (RowsExceededException e) {
                textArea.append("写入平均成绩失败\n");
                textArea.append(String.format("平均分为:%s, 平均GPA为:%s\n", fnum.format(scoreAverage), fnum.format(weightScoreAverage)));
            } catch (WriteException e) {
                countFail += 3;
                textArea.append("写入平均成绩失败\n");
                textArea.append(String.format("平均分为:%s, 平均GPA为:%s\n", fnum.format(scoreAverage), fnum.format(weightScoreAverage)));
            }
        }
        try
        {
            wb.write();
            wb.close();
        }
        catch (IOException e)
        {
            textArea.append("写入单元格成功但是保存失败\n");
            return false;
        }
        catch (WriteException e)
        {
            textArea.append("写入单元格成功但是保存失败\n");
            return false;
        }
        textArea.append("写入成绩完成!\n");
        textArea.append(String.format("成功%d个单元格,失败%d个单元格\n", countSuccess, countFail));
        textArea.append(String.format("结果存放在%s\n", file.getAbsoluteFile()));
        return true;
    }

    private boolean writeXLSWithSort(List<List<String>> datas, JTextArea textArea)
    {
        Comparator<List<String>> comparator = (arg0, arg1) ->
        {
            List<String> list0 = (List<String>) arg0;
            List<String> list1 = (List<String>) arg1;
            Double score0, score1;
            try
            {
                score0 = Double.parseDouble(list0.get(9));
            }
            catch (NumberFormatException e)
            {
                score0 = 0.0;
            }
            try
            {
                score1 = Double.parseDouble(list1.get(9));
            }
            catch (NumberFormatException e)
            {
                score1 = 0.0;
            }
            return score1.compareTo(score0);
        };
        Collections.sort(datas, comparator);
        return writeXLS(datas, true, resultPath, textArea);
    }

    private double getWeight(double score)
    {
        if(score >= 90.0)
            return 4.0;
        else if(score >= 85 && score <90)
            return 3.7;
        else if(score >= 82 && score < 85)
            return 3.3;
        else if(score >= 78 && score < 82)
            return 3.0;
        else if(score >= 75 && score < 78)
            return 2.7;
        else if(score >= 72 && score < 75)
            return 2.3;
        else if(score >= 68 && score < 72)
            return 2.0;
        else if(score >= 64 && score < 68)
            return 1.5;
        else if(score >= 60 && score < 64)
            return 1.0;
        else
            return 0;
    }
}
