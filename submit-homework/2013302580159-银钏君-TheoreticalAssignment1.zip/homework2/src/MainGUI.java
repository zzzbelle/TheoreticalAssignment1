/**
 * Created by fuxiuyin on 15-10-6.
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;


public class MainGUI
{

    public static void main(String args[])
    {
        MyWindows myWindows = new MyWindows();
    }

}

class MyWindows extends JFrame
{
    Container contentPane;

    public MyWindows()
    {
        super("成绩处理程序");
        helloWindows();
        setVisible(true);
        setResizable(false);
    }

    private void funWindiows()
    {
        contentPane.removeAll();

        JTextArea textArea = new JTextArea();
        textArea.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        textArea.setOpaque(true);
        textArea.setEditable(false);
        textArea.setBackground(new Color(0, 0, 0));
        textArea.setForeground(new Color(255, 255, 255));
        textArea.setLineWrap(true);
        JScrollPane panel = new JScrollPane(textArea,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        panel.setBounds(50, 220, 650, 300);
        contentPane.add(panel);

        ClassHeader header = new ClassHeader(textArea);
        textArea.append("点击按钮开始操作\n");
        JButton readHTMLAndWrite = new JButton("读取HTML并写入xls");
        JButton readXLSAndWrite = new JButton("读取xls并处理");
        readHTMLAndWrite.setBounds(50, 100, 300, 100);
        readXLSAndWrite.setBounds(400, 100, 300, 100);
        readHTMLAndWrite.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                textArea.append("开始读取并处理HTML文件\n");
                header.readHTMLAndWrite(textArea);
            }
        });
        readXLSAndWrite.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                textArea.append("开始读取并处理xls文件\n");
                header.readXLSAndWrite(textArea);
            }
        });
        contentPane.add(readHTMLAndWrite);
        contentPane.add(readXLSAndWrite);


        // contentPane.add(textArea);

        contentPane.revalidate();
        contentPane.repaint();

    }

    private void helloWindows()
    {
        contentPane = getContentPane();
        contentPane.removeAll();
        contentPane.setBackground(new Color(255, 255, 255));
        setSize(800, 600);
        JButton okButton = new JButton("OK");
        okButton.setBounds(((800 - 100) / 2), 500, 100, 50);
        contentPane.setLayout(null);
        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                funWindiows();
            }
        });
        contentPane.add(okButton);

        JTextArea helloLabel = new JTextArea();
        helloLabel.setText("这是一个简单的成绩处理程序\n可以计算平均分,平局GPA和排序并生成xls文件\n数据来源是" +
                "上次作业得到的HTML文件\n基本原理是使用JSoup处理HTML文件然后使用jxl读写xls文件\n\n" +
                "没像比人那样和第一次作业整合在一起,因为想着作业本来就是老师考察学生会不会的,既然已经通过上一次作业知道会了" +
                "也就没必要再知道一次了.\n再说了,孙助教说了这样不扣分,所以确定不扣分再点\"OK\".\n写这玩意学会算GPA算出来以后内" +
                "心是崩溃的");
        helloLabel.setLineWrap(true);
        helloLabel.setEditable(false);
        helloLabel.setBounds(10, 150, 780, 300);
        helloLabel.setFont(new Font("微软雅黑", Font.PLAIN, 18));
        contentPane.add(helloLabel);

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

}