import java.io.File;

public class testmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String url ="http://210.42.121.132/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Tue%20Sep%2022%202015%2021:59:17%20GMT+0800";
		String Thtml="display.html";
		HttpRequest Rhttp=HttpRequest.get(url);
		Rhttp.header("Cookie","JSESSIONID=1DF54B9DB3E9229C1FC7BE02F2692F4B.tomcat2 ");
		Rhttp.receive(new File(Thtml));
		
	
	}

}
