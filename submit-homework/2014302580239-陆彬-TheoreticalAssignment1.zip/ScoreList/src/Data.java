import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;

public class Data {

	ArrayList<Course> scoreList = new ArrayList<Course>();
	ArrayList<Course> scoreList_noPoints = new ArrayList<Course>();
	String[] tableHead=new String[11];
	String averageScore;
	String averageGradePoints;
	double scoreSum=0.0;
	double gradePointsSum=0.0;     
	
	//sort score
	public void dataSortByScore()
	{
		Collections.sort(scoreList,new SortByScore());
	}
	
	//calculate the average score
	public void getAverageScore()
	{
		double creditSum=0.0;
		for(int i=0;i<scoreList.size();i++)
		{
			scoreSum=scoreSum+Double.valueOf(scoreList.get(i).item[9])*
					Double.valueOf(scoreList.get(i).item[3]);
			creditSum=creditSum+Double.valueOf(scoreList.get(i).item[3]);			
		}
		
		DecimalFormat df = new DecimalFormat( "0.000");
				
		if(creditSum!=0)
			averageScore=df.format(scoreSum/creditSum);
	}
	
	//calculate the average credit of all courses
	public void getAverageGradePoints()
	{
		double creditSum=0.0;
		for(int i=0;i<scoreList.size();i++)
		{
			gradePointsSum=gradePointsSum+scoreList.get(i).getGradePoints()*
					Double.valueOf(scoreList.get(i).item[3]);
			creditSum=creditSum+Double.valueOf(scoreList.get(i).item[3]);			
		}
		
		DecimalFormat df = new DecimalFormat( "0.000");
				
		if(creditSum!=0)
			averageGradePoints=df.format(gradePointsSum/creditSum);
	}
}
