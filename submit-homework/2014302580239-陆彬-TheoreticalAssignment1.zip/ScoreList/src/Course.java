
public class Course {
    
	// this string[11] includes id ,type,credit,teacher, .....,score 
	String[] item = new String[11];
	
    // get the credit of this course by its score
    public double getGradePoints()
    {
    	if(Double.valueOf(item[9])>=90)
    	    return 5.0;
    	else if(Double.valueOf(item[9])>=85 && Double.valueOf(item[9])<=89)
	    	return 3.7;
    	else if(Double.valueOf(item[9])>=82 && Double.valueOf(item[9])<=84)
    		return 3.5;
    	else if(Double.valueOf(item[9])>=78 && Double.valueOf(item[9])<=82)
    		return 3.0;
    	else if(Double.valueOf(item[9])>=75 && Double.valueOf(item[9])<=77)
    		return 2.7;
    	else if(Double.valueOf(item[9])>=72 && Double.valueOf(item[9])<=74)
    		return 2.3;
        else if(Double.valueOf(item[9])>=68 && Double.valueOf(item[9])<=71)
    		return 2.0;
        else if(Double.valueOf(item[9])>=64 && Double.valueOf(item[9])<=67)
        	return 1.5;
        else if(Double.valueOf(item[9])>=60 && Double.valueOf(item[9])<=73)
        	return 1.0;
        else 
        	return 0;
    }    
    
   
}

