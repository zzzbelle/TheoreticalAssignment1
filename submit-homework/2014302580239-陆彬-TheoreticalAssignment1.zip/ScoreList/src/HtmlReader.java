import org.jsoup.*;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.IOException;

public class HtmlReader {
	
	//read data from a html file
	public void readHtml(File FileName,Data data) throws IOException 
	{
		Document doc=Jsoup.parse(FileName,"gb2312");
		
		Element scoreTable=doc.select("table[class=table listTable]").first();
		Elements rows=scoreTable.getElementsByTag("tr");
        
        for(Element e:rows)
        {
        	Elements tableHeads=e.getElementsByTag("th");
        	Elements cells=e.getElementsByTag("td");
        	
        	//this variable stands for the number of elements in this row
        	int nNumber=0;
        	if(!tableHeads.isEmpty())
        	{
        		for(Element el:tableHeads)
        			{
        			data.tableHead[nNumber]=el.text();
        			nNumber++;
        			}
        	}
        	else
        	{
        		Course course=new Course();
        		for(Element el:cells)
        		{
        			course.item[nNumber]=el.text();
        			nNumber++;
        		}       		
        		if(course.item[9].equals(""))
        			{
        			course.item[9]="��ѧ";
        			data.scoreList_noPoints.add(course);        			
        			}
        		else
        			data.scoreList.add(course);
        		
        	}
        }
	}
}
