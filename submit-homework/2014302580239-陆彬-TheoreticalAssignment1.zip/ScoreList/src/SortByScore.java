import java.util.Comparator;

public class SortByScore implements Comparator<Course>
{
	public int compare(Course course1, Course course2) 
	{
		if (Double.valueOf(course1.item[9]) > Double.valueOf(course2.item[9]))
		   return -1;
		else if (Double.valueOf(course1.item[9]) < Double.valueOf(course2.item[9]))
		   return 1;
		else	   
		   return 0;
	}
	
}
