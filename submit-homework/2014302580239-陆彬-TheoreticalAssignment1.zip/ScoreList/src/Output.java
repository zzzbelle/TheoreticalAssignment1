import java.io.File;
import java.io.IOException;



import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;



public class Output {
	
	//the argument desFile stands for the destination of the .xls file
	public static void processScoreTable(File file,Data dt,File desFile) throws IOException, RowsExceededException, WriteException
	{
		HtmlReader reader =new HtmlReader();
		reader.readHtml(file,dt);
        dt.getAverageScore();
        dt.getAverageGradePoints();
        dt.dataSortByScore();
        
        WritableWorkbook workbook = Workbook.createWorkbook(desFile);
        WritableSheet sheet = workbook.createSheet("First Sheet",0);
       
        for(int j=0;j<10;j++)
        {
        	Label label=new Label(j,0,dt.tableHead[j]);
    		sheet.addCell(label);
        }
        
            Label label_averageScore=new Label(14,10,"ƽ����");
            Label label_GPA=new Label(15,10,"GPA");
            Label averageScore=new Label(14,11,dt.averageScore);
            Label GPA=new Label(15,11,dt.averageGradePoints);
            sheet.addCell(label_averageScore);
            sheet.addCell(label_GPA);
            sheet.addCell(averageScore);
            sheet.addCell(GPA);
        
        for(int i=0;i<dt.scoreList.size();i++)
        {
        	for(int j=0;j<10;j++)
        	{
        		Label label=new Label(j,i+1,dt.scoreList.get(i).item[j]);
        		sheet.addCell(label);
        	}
        }
        
        for(int i=0;i<dt.scoreList_noPoints.size();i++)
        {
        	for(int j=0;j<10;j++)
        	{
        		Label label=new Label(j,i+1+dt.scoreList.size(),dt.scoreList_noPoints.get(i).item[j]);
        		sheet.addCell(label);
        	}
        }
        
        workbook.write();
        workbook.close();
      
	}

	public static void main(String[] args) throws IOException, RowsExceededException, WriteException  {
		// TODO Auto-generated method stub
		File fileName = new File("ImageCrawler.html");
		Data data = new Data();
        File desFileName = new File("ScoreList.xls");
		processScoreTable(fileName,data,desFileName);
        System.out.println("Sucessfully");
	}
}
