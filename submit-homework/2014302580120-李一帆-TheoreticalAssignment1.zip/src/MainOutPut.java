import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class MainOutPut {
	public void processScoreTable(File input) throws BiffException, IOException, RowsExceededException, WriteException {
		/*
		 *����ԭʼxls�ļ�
		 */
		Workbook gradeFile = Workbook.getWorkbook(input);
		Sheet sheet = gradeFile.getSheet(0);
		
		//ԭʼ�ļ����С�����
	    int allRow = sheet.getRows();
		int allColumn = sheet.getColumns();
		
		/*
		 * �����½��ļ�
		 */
		String name = "NewGrades.xls";
		File newFile = new File(name);
		WritableWorkbook newGradeFile = Workbook.createWorkbook(newFile);
		WritableSheet newSheet = newGradeFile.createSheet("newGradeTable", 0);
		Label gradeLabel;
		
		/*
		 * ���γ�id�����������ֵ��Ա�����
		 */
		Map<String, String> map = new HashMap<String, String>();
		for (int i=1; i<=allRow-1; i++) {
			map.put(sheet.getCell(0, i).getContents(), sheet.getCell(9, i).getContents());
		}
		
		/*
		 * ����ʵ��
		 */
		List<Map.Entry<String, String>> list = new ArrayList<Map.Entry<String, String>>(map.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<String, String>>()
			{
				public int compare(Map.Entry<String, String> o1, Map.Entry<String, String> o2)
				{
					if (o2.getValue()!=null&&o1.getValue()!=null&&o2.getValue().compareTo(o1.getValue())>0) {
						return 1;
					}else{
						return -1;
					}
				}
			});
		
		/*
		 * д���ͷ��Ϣ
		 */
		for (int i=0; i<=allColumn-1; i++) {
			gradeLabel = new Label(i, 0, sheet.getCell(i, 0).getContents());
			newSheet.addCell(gradeLabel);
		}
		
		/*
		 * ������д�����
		 */
		for (int i=0; i<list.size(); i++) {
			Map.Entry<String, String> a = list.get(i);
			String classId = a.getKey();
			
			Cell cell = sheet.findCell(classId);//���ݿ�ͷ�Ż�ȡ��Ԫ��
			int k = cell.getRow();//��ȡ��Ԫ������һ����
			
			for (int j=0; j<=allColumn-1; j++) {
				gradeLabel = new Label(j, i+1, sheet.getCell(j, k).getContents());
				newSheet.addCell(gradeLabel);
			}
		}
		
		
		double totalCredit = 0.0;//��ѧ��
		double averageScore = 0.0;//ƽ����
		double averageGpa = 0.0;//ƽ������
		
		/*
		 * ����ѧ��
		 */
		for (int i=1; i<=allRow-1; i++) {
			String credit_string = sheet.getCell(3, i).getContents();
			double credit = Double.parseDouble(credit_string);
			totalCredit += credit;
		}
		
		/*
		 * ƽ���ּ�����
		 */
		for (int i=1; i<=allRow-1; i++) {
			//��ȡ���ſγ̳ɼ���String��תDouble��
			String score_string = sheet.getCell(9, i).getContents();
			double score = Double.valueOf(score_string).doubleValue();
			//��ȡ���ſγ�ѧ�֣�String��תDouble��
			String credit_string = sheet.getCell(3, i).getContents();
			double credit = Double.valueOf(credit_string).doubleValue();
			//����ƽ����
			averageScore += score * credit / totalCredit;
			
			double gpa = 0.0;
			//���ſμ���
			if (score>=90)
				gpa = 4.0;
			if (score>=85 && score<=89)
				gpa = 3.7;
			if (score>=82 && score<=84)
				gpa = 3.3;
			if (score>=78 && score<=81)
				gpa = 3.0;
			if (score>=75 && score<=77)
				gpa = 2.7;
			if (score>=72 && score<=74)
				gpa = 2.3;
			if (score>=68 && score<=71)
				gpa = 2.0;
			if (score>=64 && score<=67)
				gpa = 1.5;
			if (score>=60 && score<=63)
				gpa = 1.0;
			if (score<60)
				gpa = 0.0;
			//ƽ������
			averageGpa += gpa * credit / totalCredit;
		}
		System.out.println("ƽ���֣�" + averageScore + '\n' + "GPA��" + averageGpa);
		
		/*
		 * ��ƽ���ּ�����������
		 */
		gradeLabel = new Label(allColumn, 0, "��Ȩƽ����");
		newSheet.addCell(gradeLabel);
		gradeLabel = new Label(allColumn, 1, String.valueOf(averageScore));
		newSheet.addCell(gradeLabel);
		gradeLabel = new Label(allColumn+1, 0, "GPA");
		newSheet.addCell(gradeLabel);
		gradeLabel = new Label(allColumn+1, 1, String.valueOf(averageGpa));
		newSheet.addCell(gradeLabel);
		
		/*
		 * д��ɼ���ر�
		 */
		newGradeFile.write();
		gradeFile.close();
		newGradeFile.close();
	}
	
	
	public static void main(String[] args) throws RowsExceededException, BiffException, WriteException, IOException {
		//Ҫ��ȡ���ļ�
		File file = new File("OriginalGrades.xls");
		MainOutPut outPut = new MainOutPut();
		outPut.processScoreTable(file);
	}
	
}