import java.io.*;

import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Main {
	public static void main(String [] argc) throws IOException, RowsExceededException, WriteException{
		//LessonList lessonList=new LessonList("test.html");
		File file=new File("test.html");
		MainOutPut out=new MainOutPut();
		out.processScoreTable(file);
	}
}
