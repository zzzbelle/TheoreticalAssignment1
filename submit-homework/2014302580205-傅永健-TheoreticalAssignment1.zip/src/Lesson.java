import java.io.*;

import jxl.write.*;
import jxl.write.Number;
import jxl.write.biff.RowsExceededException;

public class Lesson {
	private String m_ID;
	private String m_name;
	private String m_type;
	private double m_credit;
	private String m_teacher;
	//�����ѧԺ����ݵ���Ϣ
	private String m_other;
	private double m_score;
	private double m_GPA;
	
	//����Ϊʵ��������
	//��ӡ�����γ���Ϣ������̨
	public void outToConsole(){
		System.out.printf("%s\t%s\t%s\t%.1f\t%s\t%s\t%.1f\n",
				m_ID,m_name,m_type,m_credit,m_teacher,m_other,m_score);
	}
	//��ӡ���ļ�
	public void outToFile(FileWriter fout)throws IOException{
		fout.write(m_ID+"\t");
		fout.write(m_name+"\t");
		fout.write(m_type+"\t");
		fout.write(String.format("%.1f\t",m_credit));
		fout.write(m_teacher+"\t");
		fout.write(m_other+"\t");
		fout.write(String.format("%.1f",m_score));
		fout.write("\r\n");
	}
	//��ӡ��xls�ļ�
	public void outToExcel(int row ,WritableSheet sheet) throws RowsExceededException, WriteException{
		Label ID=new Label(0,row,m_ID);
		sheet.addCell(ID);
		Label name=new Label(1,row,m_name);
		sheet.addCell(name);
		Label type=new Label(2,row,m_type);
		sheet.addCell(type);
		Number credit=new Number(3,row,m_credit);
		sheet.addCell(credit);
		Label teacher=new Label(4,row,m_teacher);
		sheet.addCell(teacher);
		Label other=new Label(5,row,m_other);
		sheet.addCell(other);
		Number score=new Number(6,row,m_score);
		sheet.addCell(score);
	}
	//����γ���Ϣ
	public void setLesson(String ID,String name,String type,
			double credit,String teacher,String other,double score ){
		m_ID=new String (ID);
		m_name=new String(name);
		m_type=new String(type);
		m_credit=credit;
		m_teacher=new String(teacher);
		m_other=new String(other);
		m_score=score;
		caculateGPA();
	}
	//��ȡ�γ̳ɼ�
	public double getScore(){
		return m_score;
	}
	//��ȡ�γ�GPA
	public double getGPA(){
		return m_GPA;
	}
	//��ȡ�γ�ѧ��
	public double getCredit(){
		return m_credit;
	}
	//���ߺ���
	//����GPA
	private void caculateGPA(){
		if(m_score>=90){
			m_GPA=4;
		}else if(m_score>=85){
			m_GPA=3.7;
		}else if(m_score>=82){
			m_GPA=3.3;
		}else if(m_score>=78){
			m_GPA=3.0;
		}else if(m_score>=75){
			m_GPA=2.7;
		}else if(m_score>=72){
			m_GPA=2.3;
		}else if(m_score>=68){
			m_GPA=2.0;
		}else if(m_score>=64){
			m_GPA=1.5;
		}else if(m_score>=60){
			m_GPA=1.0;
		}else{
			m_GPA=0;
		}
	}
	
}
