import java.io.File;
import java.io.IOException;

import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;


public class MainOutPut {
	public void processScoreTable(File input) throws IOException, RowsExceededException, WriteException{
		
		LessonList lessonList=new LessonList(input);
		lessonList.sortByScore();
		//lessonList.outToConsole();
		lessonList.outToFile();
		lessonList.outToExcel();
	}
}
