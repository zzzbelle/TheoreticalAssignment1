import java.io.*;
import java.util.Scanner;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import jxl.Workbook;
import jxl.write.*;
import jxl.write.Number;
import jxl.write.biff.RowsExceededException;
public class LessonList {
	private Lesson m_lesson[]=new Lesson[200];
	private String m_ID[]=new String [200];
	private String m_name[]=new String [200];
	private String m_type[]=new String [200];
	private double m_credit[]=new double [200];
	private String m_teacher[]=new String [200];
	private String m_other[]=new String [200];
	private double m_score[]=new double [200];
	//���ڱ�ǽ�����
	int m_bound;
	//�ۺ�GPA��ƽ����
	double m_GPA,m_average;
	//����Ϊʵ������
	//���캯��
	public LessonList(File file) throws IOException{
		//File file=new File(fileName);
		Document doc=Jsoup.parse(file,"GBK");
		Elements element=doc.select("td");
		String data=element.text();
		for(int i=0;i<200;i++){
			m_lesson[i]=new Lesson();
		}
		getInformation(data);
		setArray();
	}
	//�������
	public void outToConsole(){
		for(int i=0;i<=m_bound;i++){
			m_lesson[i].outToConsole();
		}
		System.out.println(String.format("GPA:%f\nƽ����:%f",m_GPA,m_average));
	}
	//������ļ�
	public void outToFile() throws IOException{
		FileWriter out=new FileWriter("output.txt");
		for(int i=0;i<=m_bound;i++){
			m_lesson[i].outToFile(out);
		}
		out.write(String.format("GPA:%f\r\nƽ����:%f",m_GPA,m_average));
		out.close();
		System.out.print("txt�ļ������ɣ�^_^\n");
	}
	//�����xls�ļ�
	public void outToExcel() throws RowsExceededException, WriteException, IOException{
		File excel=new File("Tabel.xls");
		WritableWorkbook workBook=Workbook.createWorkbook(excel);
		WritableSheet sheet=workBook.createSheet("ScoreTable", 1);
		writeTitleToExcel(sheet);
		for(int i=0;i<=m_bound;i++){
			m_lesson[i].outToExcel(i+1, sheet);
		}
		writeAverageAndGPAToExcel(sheet);
		workBook.write();
		workBook.close();
		System.out.print("xls�ļ������ɣ�^_^\n");
	}
	//���ɼ�����
	public void sortByScore(){
		for(int i=0;i<m_bound;i++){
			for(int j=i+1;j<=m_bound;j++){
				if(m_lesson[i].getScore()<m_lesson[j].getScore()){
					Lesson temp;
					temp=m_lesson[i];
					m_lesson[i]=m_lesson[j];
					m_lesson[j]=temp;
				}
			}
		}
	}
	
	
	
	//����Ϊ���ߺ���
	//����Ϣ���ı�����ȡ����
	private void getInformation(String data){
		Scanner scanner=new Scanner(data);
		int i=0;
		while(scanner.hasNext()){
			m_ID[i]=new String(scanner.next());
			m_name[i]=new String(scanner.next());
			m_type[i]=new String(scanner.next());
			m_credit[i]=scanner.nextDouble();
			m_teacher[i]=new String(scanner.next());
			m_other[i]=new String(scanner.next()+"\t"+scanner.next()+"\t"+scanner.next()+"\t"+scanner.next());
			m_score[i]=scanner.nextDouble();
			//����гɼ��Ŀζ���¼����ɣ������ý��ޣ��Ͽ�ѭ��
			if(m_score[i]>100||m_score[i]<0){
				System.out.println("html�ļ���ȡ�ɹ���");
				m_bound=i-1;
				return;
			}
			i++;
		}
		
	}
	//������д������
	private void setArray(){
		for(int i=0;i<=m_bound;i++){
			m_lesson[i].setLesson(m_ID[i], m_name[i], m_type[i], 
					m_credit[i], m_teacher[i], m_other[i], m_score[i]);
		}
		caculateAverage();
		caculateGPA();
	}
	//����ƽ����
	private void caculateAverage(){
		double sum=0;
		for(int i=0;i<=m_bound;i++){
			sum+=m_lesson[i].getScore()*m_lesson[i].getCredit();
		}
		m_average=sum/caculateCredit();
	}
	//����GPA
	private void caculateGPA(){
		double sum=0;
		for(int i=0;i<=m_bound;i++){
			sum+=m_lesson[i].getGPA()*m_lesson[i].getCredit();
		}
		m_GPA=sum/caculateCredit();
	}
	//������ѧ��
	private double caculateCredit(){
		double sum=0;
		for(int i=0;i<=m_bound;i++){
			sum+=m_lesson[i].getCredit();
		}
		return sum;
	}
	//д��xls�ļ��ı�ͷ��Ϣ
	private void writeTitleToExcel(WritableSheet sheet) throws RowsExceededException, WriteException{
		Label title_1=new Label(0,0,"�γ�ID");
		sheet.addCell(title_1);
		Label titel_2=new Label(1,0,"�γ�����");
		sheet.addCell(titel_2);
		Label titel_3=new Label(2,0,"�γ�����");
		sheet.addCell(titel_3);
		Label titel_4=new Label(3,0,"�γ�ѧ��");
		sheet.addCell(titel_4);
		Label titel_5=new Label(4,0,"��ʦ");
		sheet.addCell(titel_5);
		Label titel_6=new Label(5,0,"�����γ���Ϣ");
		sheet.addCell(titel_6);
		Label titel_7=new Label(6,0,"�ɼ�");
		sheet.addCell(titel_7);
	}
	//��xls�ļ�д��ƽ������GPA
	private void writeAverageAndGPAToExcel(WritableSheet sheet) throws RowsExceededException, WriteException{
		Label titleOfGPA=new Label(0,m_bound+2,"GPA:");
		sheet.addCell(titleOfGPA);
		Label titleOfAverage=new Label(0,m_bound+3,"ƽ����:");
		sheet.addCell(titleOfAverage);
		Number GPA=new Number(1,m_bound+2,m_GPA);
		sheet.addCell(GPA);
		Number average=new Number(1,m_bound+3,m_average);
		sheet.addCell(average);
	}
}
