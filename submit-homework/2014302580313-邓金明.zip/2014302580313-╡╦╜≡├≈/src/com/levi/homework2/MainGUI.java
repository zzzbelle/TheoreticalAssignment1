package com.levi.homework2;


import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import jxl.Workbook;
import jxl.write.WritableCell;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class MainGUI {
	public static void main(String[] args) {
		//创建主窗口设置属性
		JFrame showScore = new JFrame("成绩查询");
		showScore.setSize(800,600);
		showScore.setLocationRelativeTo(null);
		showScore.setResizable(false);
		showScore.setVisible(true);
		showScore.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//添加两个按钮及一个文本域
		JPanel panel = new JPanel();
		JButton start = new JButton("开始");
		start.setBounds(50, 10, 50, 30);
		JButton output = new JButton("输出");
		start.setBounds(70, 10, 50, 30);
		JTextArea score = new JTextArea("Hello World");
		score.setBounds(0, 100, 700, 400);
        score.setTabSize(4);  
        score.setEditable(false);
        score.setLineWrap(true);
        score.setWrapStyleWord(true); 
		
		panel.add(start);
		panel.add(output);
		panel.add(score);
		
		//使用空布局
		showScore.setLayout(null);
		showScore.setContentPane(panel);
		
		start.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				score.setText("");
				Caculator caculator = new Caculator();
				List<Subject> allScore = caculator.getAllScore();
				//读取所有成绩
				for (int i = 0; i < allScore.size(); i++) {
					score.append(allScore.get(i).toString());
				}
				score.append("加权平均分："+caculator.getAverage()+"    GPA:"+caculator.getGpa());
			}
		});
		output.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					Caculator caculator = new Caculator();
					List<Subject> allScore = caculator.getAllScore();
					String[] title = {"课程","学分","成绩"};
					WritableWorkbook wwb= Workbook.createWorkbook(new File("./files/score.xls"));
					WritableSheet sheet=wwb.createSheet("第一页",0);
					//添加标题
					for (int i = 0; i < 3; i++) {
						sheet.addCell(new jxl.write.Label(i,0,title[i]));
					}
					for (int j = 1; j <= allScore.size(); j++) {
						sheet.addCell(new jxl.write.Label(0,j,allScore.get(j-1).getName()));
						sheet.addCell(new jxl.write.Label(1,j,""+allScore.get(j-1).getCredit()));
						sheet.addCell(new jxl.write.Label(2,j,""+allScore.get(j-1).getScore()));
					}
					sheet.addCell(new jxl.write.Label(0,allScore.size()+1,"加权平均分"));
					sheet.addCell(new jxl.write.Label(1,allScore.size()+1,""+caculator.getAverage()));
					sheet.addCell(new jxl.write.Label(0,allScore.size()+2,"GPA"));
					sheet.addCell(new jxl.write.Label(1,allScore.size()+2,""+caculator.getGpa()));
					wwb.write();
					wwb.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (RowsExceededException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (WriteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
	}

}
