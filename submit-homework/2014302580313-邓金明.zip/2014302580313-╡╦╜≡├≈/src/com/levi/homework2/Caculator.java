package com.levi.homework2;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

//该类为方法类，所有逻辑在此处实现
public class Caculator {
	static List<Subject> allGrades;
	public static double gpa;
	public static double average;
	public static double credit;
	public Caculator() {
		credit = 0;
		gpa = 0;
		average = 0;
		allGrades = new ArrayList<>();
		Comparator<Subject> comparator = new Comparator<Subject>() {

			@Override
			public int compare(Subject o1, Subject o2) {
				if (o1.getScore()!=o2.getScore()) {
					return (int) (o2.getScore() - o1.getScore());
				}else {
					return (int) (o2.getCredit() - o1.getCredit());
				}
			}
		};
		//直接读取上次作业爬取的成绩单
		try {
			Document doc = Jsoup.parse(new File("./files/index.html"), "gb2312");
			//选择html中table标签下所有元素
			Elements trs = doc.select("table").select("tr");
			//为了去除标题，从i=1开始
			for (int i = 1; i < trs.size(); i++) {
				Elements tds = trs.get(i).select("td");
				//如果这项成绩存在才读入，使读出的成绩中无本学期课程
				if (!tds.get(9).text().equals("")) {
					String name = tds.get(1).text();
					String grade = tds.get(3).text();
					String score = tds.get(9).text();
					allGrades.add(new Subject(name,Float.valueOf(score),Float.valueOf(grade)));
					average += Float.valueOf(score)*Float.valueOf(grade);
					credit += Float.valueOf(grade);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		Collections.sort(allGrades,comparator);
		average = average / credit;
		if (average>=90) {
			gpa = 4.0;
		}else if (average>=85) {
			gpa = 3.7;
		}else if (average>=78) {
			gpa = 3.3;
		}else if (average>=75) {
			gpa=2.7;
		}else if (average>=72) {
			gpa = 2.3;
		}else if (average>=68) {
			gpa = 2.0;
		}else if (average>=64) {
			gpa = 1.5;
		}else if (average>=60) {
			gpa = 1.0;
		}
	}
	
	public static List<Subject> getAllScore() {
		return allGrades;
	}
	public static double getAverage() {
		return average;
	}
	public static double getGpa() {
		return gpa;
	}
}


