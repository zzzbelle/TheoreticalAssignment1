package com.levi.homework2;

public class Subject {
	private String name;   //课程名
	private double score;   //分数
	private double credit;  //学分
	public Subject(String name,float score,float grade) {
		this.name = name;
		this.score = score;
		this.credit = grade;
	}
	public String getName() {
		return name;
	}
	public double getScore() {
		return score;
	}
	public double getCredit() {
		return credit;
	}
	public String toString(){
		String s = name+"            "+score+"        "+credit+"\n";
		return s;
	}
}
