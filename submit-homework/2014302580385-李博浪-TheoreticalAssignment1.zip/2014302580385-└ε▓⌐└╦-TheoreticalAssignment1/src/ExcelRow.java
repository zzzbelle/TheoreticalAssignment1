import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.apache.poi.hssf.usermodel.*;

public class ExcelRow 
{	
	private HSSFWorkbook wb;  //excel�ļ�
	
	private HSSFSheet st;//sheetҳ
	
	private HSSFRow row; //��
	
	private HSSFCell[] content; //����
	
	private FileInputStream gradeExcel;
	
	public HSSFCell GetHSSFCell(int i)
	{
		return content[i];
	}//��õ�i+1����Ԫ��ֵ
	
	public HSSFRow GetHSSFRow()
	{
		return row;
	}//��ȡ��
	public void TurnOnInput() throws FileNotFoundException 
	{
		gradeExcel = new FileInputStream("grade.xls");
	}//�����ļ���
	
	public void TurnOffInput() throws IOException
	{
		gradeExcel.close();
	}//�ر��ļ���

	
	public ExcelRow(int rowNumber) throws IOException
	{
		//TurnOnInput();
		gradeExcel = new FileInputStream("grade.xls");
		content=new HSSFCell[10];
		wb = new HSSFWorkbook(gradeExcel);
		st = wb.getSheet("Sheet1");
		row = st.getRow(rowNumber);
		for(int i=0;i<10;i++)
		{
			content[i] = row.getCell(i);
		}
		//TurnOffInput();
		gradeExcel.close();
	}
	
}
