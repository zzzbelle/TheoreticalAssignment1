package com.Tim.assignment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.Number;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;


public class MyGrade {
	public static void processScoreTable(File Input) throws BiffException, IOException{
		try{
			OutputStream xls =new FileOutputStream("G:/JAVAworkspace/zhangteng/new.xls");
			WritableWorkbook book = Workbook.createWorkbook(xls);
			WritableSheet sheet1 = book.createSheet("sheet1",1);
			Workbook wb = null;
			Cell cell = null;
			Label label;
			InputStream stream = new FileInputStream(Input);
			wb = Workbook.getWorkbook(stream);
			Sheet sheet = wb.getSheet(0);
			String[][]str = new String[sheet.getRows()][sheet.getColumns()];
			for(int i=0;i<sheet.getRows();i++){
				for(int j=0;j<sheet.getColumns();j++){
					cell=sheet.getCell(j,i);
					str[i][j]=cell.getContents();
				}
			}
			//����������
			for(int i=0;i<str.length-1;i++){
				for(int j=0;j<str.length-i-1;j++){
					String[] str1;
					if(str[j][9].compareTo(str[j+1][9])<0){
						str1 =str[j];
						str[j]= str[j+1];
						str[j+1]=str1;
					}
				}
			}
			double sum1=0;//�����ܺ�
			double sum2=0;//GPA�ܺ�
			double sum3=0;//����*GPA
			double num1;//����
			double num2;//GPA
			
			
			double aveGPA=sum3/sum2;
			double avegrade=sum1/sum2;
			//��sum1,sum2;
			for(int i=1;i<sheet.getRows();i++){
				sum1+=Double.parseDouble(str[i][9]);
				sum2+=Double.parseDouble(str[i][3]);
			}
			//��GPA
			for(int i=1;i<sheet.getRows();i++){
				num1=Double.parseDouble(str[i][3]);
				num2=Double.parseDouble(str[i][9]);
				if(num2>=90){
					sum3+=num1*4;
				}
				else if(num2>=85){
					sum3+=num1*3.7;
				}
				else if(num2>=82){
					sum3+=num1*3.3;
				}
				else if(num2>=78){
					sum3+=num1*3.0;
				}
				else if(num2>=75){
					sum3+=num1*2.7;
				}
				else if(num2>=72){
					sum3+=num1*2.3;
				}
				else if(num2>=68){
					sum3+=num1*2.0;
				}
				else if(num2>=64){
					sum3+=num1*1.5;
				}
				else if(num2>=60){
					sum3+=num1*0;
				}
				else if(num2<60){
					sum3+=num1*3.3;
				}
			}
			for(int i=0;i<sheet.getRows();i++){
				for(int j=0;j<sheet.getColumns();j++){
					label=new Label(j,i,str[i][j]);
					sheet1.addCell(label);
				}
			}
			//д����
			Label label1=new Label(0,9,"��Ȩƽ����");
		    Number label2=new Number(1,9,avegrade);
			Label label3=new Label(2,9,"��Ȩƽ������");
			Number label4=new Number(3,9,aveGPA);
			sheet1.addCell(label1);
			sheet1.addCell(label2);
			sheet1.addCell(label3);
			sheet1.addCell(label4);

			book.write();
			book.close();
		}catch(Exception a){
			a.printStackTrace();
		}
	}
		public static void main(String[] args){

		}
}
