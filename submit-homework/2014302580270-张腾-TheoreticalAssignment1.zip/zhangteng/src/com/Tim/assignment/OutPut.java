package com.Tim.assignment;

import java.io.File;
import java.io.IOException;

import jxl.read.biff.BiffException;

public class OutPut {
	public static void main(String[] args){
		try{
			File xls2=new File("G:/JAVAworkspace/zhangteng/old.xls");
			MyGrade.processScoreTable(xls2);
		}catch(BiffException a){
			a.printStackTrace();
		}catch(IOException a){
			a.printStackTrace();
		}
	}

}
