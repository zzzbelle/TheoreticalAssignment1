package grade;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class GradeList extends JFrame implements ActionListener {

	private JPanel jPanel=null;
	private JLabel jLabel=null;
	//�ɼ�����
	public static void sort(float[] a)
	{
		float temp=(float) 0.0;
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[j]>a[i])
				{
					temp=a[j];
					a[j]=a[i];
					a[i]=temp;
				}
			}
		}
		
	}
	//����Ϊ������ѧ��
	public static float totalscore=1;
	//�������еı�����ѧ��
	public static float totalscore1(String string,float a)
	{
		if(string.equals("��������")||string.equals("רҵ����"))
		{
			return a;
		}
		else {
			return 0;
		}
	}
	//��������ƽ������
	public static float gradePoint(float a,float b)
	{
		if(a>=90)
		{
			return (float)(b*4.0);
		}
		else if(a>=85&&a<90)
		{
			return (float)(b*3.7);
		}
		else if(a>=82&&a<=84)
		{
			return (float)(b*3.3);
		}//�ɼ�û��78������͵�3.0
		else {
			return (float)(b*3.0);
		}
	}
	//�����Ȩƽ����
	public static float averagescore(String string,float a,float b)
	{
		float total=0;
		if(string.equals("��������")||string.equals("רҵ����"))
		{
			total=a*b;
			total=total/totalscore;
			return total;
		}
		else {
			total=(float) (a*b*0.002);
			return total;
		}
	}
	//��ʼ��
	public GradeList()
	{
		super();
		setVisible(true);
		setBounds(400,200,400,400);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	    jPanel=new JPanel();
		setContentPane(jPanel);
		setTitle("�ɼ�����");
		JButton jButton=new JButton("����ɼ���");
		add(jButton);
		jButton.setBounds(110, 100, 90, 25);
		jButton.addActionListener(this);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		try {
			HSSFWorkbook wb=new HSSFWorkbook();
			HSSFSheet sheet=wb.createSheet("�ɼ�����");
			Vector<HSSFRow> aHssfRows=new Vector<HSSFRow>();
			int number=0;//excel ����
			jLabel=new JLabel("��������ʧ�ܣ�ԭ��cookie��ʱ��");
			getContentPane().add(jLabel);
			jLabel.setBounds(110, 130, 200, 25);//�����ǩ��ʾִ�����
			Document doc=Jsoup.connect("http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%20Oct%2004%202015%2015:15:54%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)").header("Cookie","JSESSIONID=519B766DAF343DE11E5B3F7117FF1AF1.tomcat2").get();//Jsoup��ȡ�����ɼ���
			for(Element element :doc.getElementsByClass("table").get(0).select("tbody>tr"))
			{
				if(!element.select("td").toString().equals(""))
				{
					if(!element.select("td").get(9).text().isEmpty())
					{
						aHssfRows.add(sheet.createRow((number)));
						number++;	
					}
				}
			}
			aHssfRows.add(sheet.createRow((number)));//������ 26
			number=0;
			for(Element element :doc.getElementsByClass("table").get(0).select("tbody>tr"))
			{
				
				for(int i=0;i<10;i++)
				{
					aHssfRows.get(0).createCell((short)i).setCellValue(element.select("th").get(i).text());
				}
				break;
			}//Ϊexcel��һ�����ӿγ̺� �γ�����֮����Ϣ
			float[] a=new float[aHssfRows.size()-1];//�����洢�ɼ�
			for(Element element :doc.getElementsByClass("table").get(0).select("tbody>tr"))
			{
				if(!element.select("td").toString().equals(""))
				{
					if(!element.select("td").get(9).text().isEmpty())
					{
						float grade=Float.parseFloat(element.select("td").get(9).text());
						a[number]=grade;
						number++;
					}
				}
			}
			sort(a);//�ɼ��ɸߵ�������
			for(Element element :doc.getElementsByClass("table").get(0).select("tbody>tr"))
			{
				if(!element.select("td").toString().equals(""))
				{
					if(!element.select("td").get(9).text().isEmpty())
					{
						float grade=Float.parseFloat(element.select("td").get(9).text());
						for(int i=0;i<a.length;i++)
						{
							if(grade==a[i])
							{
								for(int j=0;j<10;j++)
								{
									aHssfRows.get(i+1).createCell((short)j).setCellValue(element.select("td").get(j).text());
								}
								a[i]=-1;
								break;
							}
						}
					}
					
				}
			}//�ɼ���д��excel ���ɼ��ɸߵ�������
			float avescore=0;//��Ȩƽ����
			float avescore1=0;//���޿γ���ѧ��
			for(Element element :doc.getElementsByClass("table").get(0).select("tbody>tr"))
			{
				if(!element.select("td").toString().equals(""))
				{
					if(!element.select("td").get(9).text().isEmpty())//����û�гɼ��Ŀγ�Ҳ�������
					{
						if(!element.select("td").get(3).text().isEmpty())
						{
							avescore1=avescore1+totalscore1(element.select("td").get(2).text(), Float.parseFloat(element.select("td").get(3).text()));
						}
					}
					
				}
			}
			totalscore=avescore1;
			float total_grade=0;//��ѧ��
			float total_gradePoint=0;//������ѧ�ֳ˻�֮��
			for(Element element :doc.getElementsByClass("table").get(0).select("tbody>tr"))
			{
				if(!element.select("td").toString().equals(""))
				{
					if(!element.select("td").get(3).text().isEmpty()&&!element.select("td").get(9).text().isEmpty()&&!element.select("td").get(2).text().isEmpty())
					{
						avescore=avescore+averagescore(element.select("td").get(2).text(), Float.parseFloat(element.select("td").get(3).text()), Float.parseFloat(element.select("td").get(9).text()));
						total_grade=total_grade+ Float.parseFloat(element.select("td").get(3).text());
						total_gradePoint=total_gradePoint+gradePoint( Float.parseFloat(element.select("td").get(9).text()), Float.parseFloat(element.select("td").get(3).text()));
					}
							
				}
			}
			//����Ȩƽ���ֺ�ƽ���������excel
			aHssfRows.get(0).createCell((short)10).setCellValue("��Ȩƽ����");
			aHssfRows.get(1).createCell((short)10).setCellValue(avescore);
			aHssfRows.get(0).createCell((short)11).setCellValue("ƽ������");
			aHssfRows.get(1).createCell((short)11).setCellValue(total_gradePoint/total_grade);
			FileOutputStream fileOutputStream=new FileOutputStream("grade1.xls");
			wb.write(fileOutputStream);
			fileOutputStream.close();
			jLabel=new JLabel("�����ɹ�");
			getContentPane().add(jLabel);
			jLabel.setBounds(160, 160, 90, 25);//��ʾ�����ɹ�
		} catch (Exception e2) {
			e2.printStackTrace();// TODO: handle exception
		}
		
		
	}
}
