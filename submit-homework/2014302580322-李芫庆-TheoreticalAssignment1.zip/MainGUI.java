/**
 * 
 */
package grade;

/**
 * @2014302580322 ��ܾ��   ��5
 * 2015.10.7
 *
 */
public class MainGUI {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GradeList gradeList=new GradeList();
	}

}
