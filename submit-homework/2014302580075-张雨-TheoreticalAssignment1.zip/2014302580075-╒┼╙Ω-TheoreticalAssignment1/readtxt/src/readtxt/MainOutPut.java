package readtxt;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainOutPut {
	public static void main(String[] args) {
		//TODO 自动生成的方法存根
		String filepath="MyOldGrade.txt";
		File file=new File(filepath);
		MainOutPut mainOutPut=new MainOutPut();
		mainOutPut.processScoreTable(file);
	}

	/*
	 * 对ReadOut返回的对象和加权数据进行操作写入
	 */
	public void processScoreTable(File input) {
		//ArrayList<MyCourse> myCourse,String filepath
		File file=new File("MyNewGrade.txt");
		try {
			FileWriter fileWriter=new FileWriter(file);
			for (MyCourse myNewCourse : ReadOut(input)) {
				fileWriter.write(myNewCourse.courseId+"\t"+myNewCourse.courseName
						+"\t"+myNewCourse.corseType+"\t"+myNewCourse.courseCredit
						+"\t"+myNewCourse.teacherName+"\t"+myNewCourse.collegeName
						+"\t"+myNewCourse.style+"\t"+myNewCourse.year+"\t"+myNewCourse.term+
						"\t"+myNewCourse.scores+"\r");
				
			}
			fileWriter.write("我的加权分数："+getAverageScore(ReadOut(input))+"\r我的加权GPA："+
									getAverageGPA(ReadOut(input)));
			fileWriter.close();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("写入错误！");
		}
		
	}
	/*
	 * 对原始文件进行读取，然后排序，最后返回一由课程对象组成的ArrayList的对象
	 */
	public static ArrayList<MyCourse> ReadOut(File input) {
		File file=input;
		ArrayList<MyCourse> myCourses=new ArrayList<>();
		try {
			if (file.exists()&&file.isFile()) {
				InputStreamReader reader=new InputStreamReader(new FileInputStream(file),"UTF-8");
				BufferedReader bufferedReader=new BufferedReader(reader);
				String lineTXT=null;
				while ((lineTXT=bufferedReader.readLine())!=null) {//(chartxt=reader.read())!=-1&&counter<48
						
					String[] strArr=lineTXT.split("\t");
					myCourses.add(new MyCourse(strArr[0], strArr[1], strArr[2],
							Double.parseDouble(strArr[3]),strArr[4], strArr[5], strArr[6], 
							strArr[7], strArr[8], Double.parseDouble(strArr[9])));
					
				}
				bufferedReader.close();
				Collections.sort(myCourses, new MySort());
				
				
			}else {
				System.out.println("读取出错！");
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("找不到指定文件！！！");
			System.out.println(e);
		}
		return myCourses;//return null;
		
	}
	/*
	 * 获得我的加权分数
	 */
	public static double getAverageScore(ArrayList<MyCourse> myCourses) {
		double sumScore=0;
		double sumCredit=0;
		double averageScore=0;
		for (int i = 0; i <myCourses.size(); i++) {
			sumScore=sumScore+myCourses.get(i).getScores()*myCourses.get(i).getCourseCredit();
			sumCredit=sumCredit+myCourses.get(i).getCourseCredit();
		}
		averageScore=sumScore/sumCredit;
		return averageScore;
	}
	/*
	 * 获取我的加权GPA
	 */
	public static double getAverageGPA(ArrayList<MyCourse> myCourses) {
		double averageGPA=0;
		double sumGPA=0;
		double sumCredit=0;
		for (int i = 0; i < myCourses.size(); i++) {
			sumGPA=sumGPA+getGPA(myCourses.get(i).getScores())*myCourses.get(i).getCourseCredit();
			sumCredit=sumCredit+myCourses.get(i).getCourseCredit();
		}
		averageGPA=sumGPA/sumCredit;
		return averageGPA;
	}
	/*
	 * 根据分数的不同来获取相应的GPA值
	 */
	public static double getGPA(double score) {
		double GPA=0;
		if (score<=100&&score>=90) {
			 GPA=4.0;
		}else if (score>=85&&score<=89) {
			 GPA=3.7;
		}else if (score>=82&&score<=84) {
			 GPA=3.3;
		}else if (score>=78&&score<=81) {
			 GPA=3.0;
		}else if (score>=75&&score<=77) {
			 GPA=2.7;
		}else if (score>=72&&score<=74) {
			 GPA=2.3;
		}else if (score>=68&&score<=71) {
			 GPA=2.0;
		}else if (score>=64&&score<=67) {
			 GPA=1.5;
		}else if (score>=60&&score<=63) {
			 GPA=1.0;
		}else if (score<=60) {
			 GPA=0;
		}
		return GPA;
	}
	
}
/*
 * 通过继承Comparor创建我自定义的比较方式进行排序
 */
class MySort implements Comparator<MyCourse>
{
	public int compare(MyCourse myCourse1, MyCourse myCourse2) {
		// TODO 自动生成的方法存根
		if (myCourse1.getScores()>myCourse2.getScores()) {
			return -1;
		}else if (myCourse1.getScores()<myCourse2.getScores()) {
			return 1;
		}
		return 0;
	}
}
/*
 * 自定义的课程类
 */
class MyCourse
{
	public String courseId;
	public String courseName;
	public String corseType;	
	public double courseCredit;	
	public String teacherName;
	public String collegeName;
	public String style;
	public String year;	
	public String term;	
	public double scores;
	public MyCourse(String courseId,String courseName,String corseType,double courseCredit,
			String teacherName,String collegeName,String style,String year,String term,double scores) 
	{
		// TODO 自动生成的构造函数存根
			 this.courseId=courseId;
			 this.courseName=courseName;
			 this.corseType=corseType;
			 this.courseCredit=courseCredit;
			 this.teacherName=teacherName;
			 this.collegeName=collegeName;
			 this.style=style;
			 this.year=year;
			 this.term=term;
			 this.scores= scores;		
	}
	public double getCourseCredit() {
		return courseCredit;
	}
	public double getScores() {
		return scores;
	}
	
}
	