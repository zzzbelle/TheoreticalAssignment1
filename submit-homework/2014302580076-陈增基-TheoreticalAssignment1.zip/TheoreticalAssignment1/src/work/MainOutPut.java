package work;
import java.io.File;   
import java.io.FileInputStream;     
import java.io.InputStream;    

import jxl.Cell;     
import jxl.CellType;   
import jxl.NumberCell;
import jxl.Sheet;     
import jxl.Workbook;    
import jxl.write.Label;   
import jxl.write.Number; 
import jxl.*;   
public class MainOutPut {
	
		public static void main(String[] args)  {
		
			 File target= new File("chengjidan.xls");
			processScoreTable(target)  ;
		}
	

	public static void processScoreTable(File input)  {  
	//��ֵ
	double JunFen = 0;
	double JunGPA = 0;
	double XueFen=0;
	
	long[] Axiang = new long[100]  ;
	String[] Bxiang = new String[100]   ;
	String[] Cxiang = new String[100]   ;
	double[] Dxiang = new double[100]  ;
	String[] Exiang = new String[100]   ;
	String[] Fxiang = new String[100]   ;
	String[] Gxiang = new String[100]   ;
	int[] Hxiang = new int[100]  ;
	String[] Ixiang = new String[100]   ;
	int[] Jxiang = new int[100]  ;
	double[] Kxiang = new double[100]  ;
		  
	  String NewBiao = "newchengjidan.xls";
	   
	        jxl.Workbook myxls = null;   
	  	  
	 try{   
	  	 //��������	  
              	  
	            myxls = Workbook.getWorkbook(input);   	  	        
	            Sheet scoresheet = myxls.getSheet(0);              
	            int Rows = scoresheet.getRows();

	    for(int i=0;i<10;i++){
	    	for(int j=1;j<Rows;j++){
	    		Cell cell = scoresheet.getCell(i, j);   
	    		if(i==0){ 
	    			 if (cell.getType() == CellType.NUMBER)     
			            {     
			                NumberCell Acell = (NumberCell)cell;    
			                Axiang[j] =(long) Acell.getValue();
			            }   
		    	}
		    	if(i==1){
		            if (cell.getType() == CellType.LABEL)     
		            {     
		               LabelCell Bcell = (LabelCell)cell;
		               Bxiang[j] = Bcell.getString(); 
		                
		            }   
		    	}
		    	if(i==2){
		            if (cell.getType() == CellType.LABEL)     
		            {     
		                LabelCell Ccell = (LabelCell)cell;    
		                Cxiang[j] = Ccell.getString();
		            }   
		    	}
		    	if(i==3){
		            if (cell.getType() == CellType.NUMBER)     
		            {     
		                NumberCell Dcell = (NumberCell)cell;    
		                Dxiang[j] =(double) Dcell.getValue();
		            }   
		    	}
		    	if(i==4){
		            if (cell.getType() == CellType.LABEL)     
		            {     
		                LabelCell Ecell = (LabelCell)cell;    
		                Exiang[j] = Ecell.getString();
		            }   
		    	}
		    	if(i==5){
		            if (cell.getType() == CellType.LABEL)     
		            {     
		                LabelCell Fcell = (LabelCell)cell;    
		                Fxiang[j] = Fcell.getString();
		            }   
		    	}
		    	if(i==6){
		            if (cell.getType() == CellType.LABEL)     
		            {     
		                LabelCell Gcell = (LabelCell)cell;    
		                Gxiang[j] = Gcell.getString();
		            }   
		    	}
		    	if(i==7){
		            if (cell.getType() == CellType.NUMBER)     
		            {     
		                 NumberCell Hcell = (NumberCell)cell;    
		                Hxiang[j] = (int)Hcell.getValue();
		            }   
		    	}
		    	if(i==8){
		            if (cell.getType() == CellType.LABEL)     
		            {     
		                LabelCell Icell = (LabelCell)cell;    
		                Ixiang[j] = Icell.getString();
		            }   
		    	}
		    	if(i==9){
		            if (cell.getType() == CellType.NUMBER)     
		            {     
		                NumberCell Jcell = (NumberCell)cell; 
		                Jxiang[j] = (int) Jcell.getValue();
		                
		            }   
		    	}
		    	
	    	}
	   
	    }
	    
	    //��������С����˳��
	    for(int j=Rows;j>1;j--){
	    	for(int i=1;i<j;i++){
	    		int left=Jxiang[i],right=Jxiang[i+1];
	    		if(left<right){
	    			Axiang[0]=Axiang[i];Axiang[i]=Axiang[i+1];Axiang[i+1]=Axiang[0];
	    			Bxiang[0]=Bxiang[i];Bxiang[i]=Bxiang[i+1];Bxiang[i+1]=Bxiang[0];
	    			Cxiang[0]=Cxiang[i];Cxiang[i]=Cxiang[i+1];Cxiang[i+1]=Cxiang[0];
	    			Dxiang[0]=Dxiang[i];Dxiang[i]=Dxiang[i+1];Dxiang[i+1]=Dxiang[0];
	    			Exiang[0]=Exiang[i];Exiang[i]=Exiang[i+1];Exiang[i+1]=Exiang[0];
	    			Fxiang[0]=Fxiang[i];Fxiang[i]=Fxiang[i+1];Fxiang[i+1]=Fxiang[0];
	    			Gxiang[0]=Gxiang[i];Gxiang[i]=Gxiang[i+1];Gxiang[i+1]=Gxiang[0];
	    			Hxiang[0]=Hxiang[i];Hxiang[i]=Hxiang[i+1];Hxiang[i+1]=Hxiang[0];
	    			Ixiang[0]=Ixiang[i];Ixiang[i]=Ixiang[i+1];Ixiang[i+1]=Ixiang[0];
	    			Jxiang[0]=Jxiang[i];Jxiang[i]=Jxiang[i+1];Jxiang[i+1]=Jxiang[0];    			
	    		}
	    	}
	    //for1	
	    } 
	    //���㼨��
	    for(int j=1;j<=Rows;j++){
	    	if(Jxiang[j]>=90) Kxiang[j]=4.0;
			else if(Jxiang[j]<90&&Jxiang[j]>=85)Kxiang[j]=3.7;
			else if(Jxiang[j]<85&&Jxiang[j]>=82)Kxiang[j]=3.3;
			else if(Jxiang[j]<82&&Jxiang[j]>=78)Kxiang[j]=3.0;
			else if(Jxiang[j]<78&&Jxiang[j]>=75)Kxiang[j]=2.7;
			else if(Jxiang[j]<75&&Jxiang[j]>=72)Kxiang[j]=2.3;
			else if(Jxiang[j]<72&&Jxiang[j]>=68)Kxiang[j]=2.0;
			else if(Jxiang[j]<68&&Jxiang[j]>=64)Kxiang[j]=1.5;
			else if(Jxiang[j]<64&&Jxiang[j]>=60)Kxiang[j]=1.0;
			else if(Jxiang[j]<60)Kxiang[j]=0;
	    }
	   //�����Ȩƽ���֡�GPA
	    for(int j=1;j<Rows;j++){
	    	JunFen +=Dxiang[j]*Jxiang[j];
	    	JunGPA +=Dxiang[j]*Kxiang[j];
	    	XueFen +=Dxiang[j];
	    	
	    }
	      JunFen=JunFen/XueFen;
	      JunGPA=JunGPA/XueFen;
	    //�½�һ�ű�����ԭ����������ȫ�����Ƶ�����  
	    jxl.write.WritableWorkbook toNewBiao = Workbook.createWorkbook(new File(NewBiao), myxls);   
        jxl.write.WritableSheet xinbiao = toNewBiao.getSheet(0);   
 
        
         //д�����ݸ���ԭ������ 
        for(int i=0;i<11;i++){
        	for(int j=1;j<=Rows;j++){
        		    
                 if(i==0){       		 
                	 Number ShuJu = new Number(i,j,Axiang[j]);           
                     xinbiao.addCell(ShuJu);                         
                 }
                 if(i==1){       		 
          
                     Label label = new Label(i,j,Bxiang[j]);                  
                     xinbiao.addCell(label);   
                 }
                 if(i==2){       		 
                	   Label label = new Label(i,j,Cxiang[j]);                  
                       xinbiao.addCell(label);                      
                 }
                 if(i==3){       		 
                	  Number ShuJu = new Number(i,j,Dxiang[j]);           
                      xinbiao.addCell(ShuJu);                         
                 }
                 if(i==4){       		 
                	   Label label = new Label(i,j,Exiang[j]);                  
                       xinbiao.addCell(label);                          
                 }
                 if(i==5){       		 
                	   Label label = new Label(i,j,Fxiang[j]);                  
                       xinbiao.addCell(label);                        
                 }
                 if(i==6){       		 
                	   Label label = new Label(i,j,Gxiang[j]);                  
                       xinbiao.addCell(label);                    
                   }
                 if(i==7){       		 
                     Number ShuJu = new Number(i,j,Hxiang[j]);           
                     xinbiao.addCell(ShuJu);                         
                 }
                 if(i==8){       		 
                	   Label label = new Label(i,j,Ixiang[j]);                  
                       xinbiao.addCell(label);                        
                 }
                 if(i==9){       		 
                     Number ShuJu = new Number(i,j,Jxiang[j]);           
                     xinbiao.addCell(ShuJu);                         
                 }
                 if(i==10){       		 
                     Number ShuJu = new Number(i,j,Kxiang[j]);           
                     xinbiao.addCell(ShuJu);                         
                 }
                 
        	}
        }
        Number junfen = new Number(9,Rows,JunFen);
        xinbiao.addCell(junfen);
        Number jungpa = new Number(10,Rows,JunGPA);
        xinbiao.addCell(jungpa);
        Label AddShouXiang = new Label(10,0,"GPA");   
        xinbiao.addCell(AddShouXiang);    


        //д��Excel����   

        toNewBiao.write();   

        toNewBiao.close();   
        }
        catch (Exception e) {   
        	  
            e.printStackTrace();   
  
        } finally {   
  
            myxls.close();   
  
        }   
	 
	  
	}   
	  
	  
}
