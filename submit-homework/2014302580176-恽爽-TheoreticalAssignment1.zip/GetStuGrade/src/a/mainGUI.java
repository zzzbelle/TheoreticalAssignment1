package a;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.github.kevinsawicki.http.Assignment1;
import com.github.kevinsawicki.http.Assignment2;


import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;

public class mainGUI extends JFrame {

	private static boolean htmlSuccess = false;
	private static boolean sort = false;
	private static ImageIcon img;
	
	private JPanel contentPane;
	private JTextField txtAaa;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mainGUI frame = new mainGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public mainGUI() {
		setTitle("\u6210\u7EE9\u5230xls");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(245, 255, 250));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		

		//��ʾ״̬��Label
		JLabel label = new JLabel("\u8BF7\u8F93\u5165\u9A8C\u8BC1\u7801");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("΢���ź� Light", Font.PLAIN, 16));
		label.setForeground(Color.GRAY);
		label.setBounds(143, 10, 150, 28);
		contentPane.add(label);
		
		
		//�����textField
		txtAaa = new JTextField();
		txtAaa.setBounds(143, 66, 150, 38);
		contentPane.add(txtAaa);
		txtAaa.setColumns(10);
		
		
		//��ʾͼ���Label
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(10, 55, 117, 49);
		contentPane.add(lblNewLabel);
		if(Assignment1.getImg()){
			try {
				
				//����������̱仯��ֱ��new ImageIcon("*.*")����
				lblNewLabel.setIcon(new ImageIcon(ImageIO.read(new File("xdvfb.png"))));
				
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
		
		//ȷ�ϰ�ť
		JButton btnNewButton = new JButton("\u767B\u5F55");
		btnNewButton.setFont(new Font("΢���ź� Light", Font.PLAIN, 13));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					//�õ���֤��
					String xdfvs = txtAaa.getText();
					
					if(Assignment1.loginAndParse(xdfvs)){//��¼�ɹ�
						Assignment2.transformXLS(sort);
						htmlSuccess = true;
						label.setText("��¼�ɹ���");
					}
					else{								//��¼ʧ��
						label.setText("��֤���������");
						txtAaa.setText("");
						
						Assignment1.getImg();//���»�ȡ��֤��
						
						//����������̱仯
						img = new ImageIcon(ImageIO.read(new File("xdvfb.png")));
						lblNewLabel.setIcon(img);
					}
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		btnNewButton.setBounds(143, 124, 150, 39);
		contentPane.add(btnNewButton);
		
		
		//����ť
		JButton btnNewButton_1 = new JButton("\u6392\u5E8F \u5E73\u5747\u5206 GPA");
		btnNewButton_1.setFont(new Font("΢���ź� Light", Font.PLAIN, 13));
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//htmlSuccess�����ж��Ƿ��Ѿ�����˵�¼��ť
				if(htmlSuccess == true){
					
					//if��sort��������ִ��һ��TransformXLS��������һ�����˷ѣ������ǣ������Workbook��ֻ�����´���һ��Workbook��
					sort = true;
					try {
						Assignment2.transformXLS(sort);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					label.setText("���");
				}
				else{
					label.setText("���ȵ�¼");
				}
			}
		});
		btnNewButton_1.setBounds(143, 180, 150, 38);
		contentPane.add(btnNewButton_1);
				
	}
}
