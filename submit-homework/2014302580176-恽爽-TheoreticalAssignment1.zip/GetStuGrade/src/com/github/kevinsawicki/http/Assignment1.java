package com.github.kevinsawicki.http;
import java.io.File;
import java.util.Scanner;


public class Assignment1 {
	
	private static String fileName = "StuGrade.html";
	private static File StuGrade = new File(fileName);
	private static String urlLogin = "http://210.42.121.241/servlet/Login";
	private static String urlGrade = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%20Sep%2020%202015%2021:52:44%20GMT+0800";
	private static String[] cookiesArray;
	private static String cookies;
	
	public static boolean getImg(){

		//���ץȡ��֤��ͳɼ������ļ�
		String imgName = "xdvfb.png";
		File XdvfbImg = new File(imgName);
		
		String urlImg = "http://210.42.121.241/servlet/GenImg";
		
		//ץȡ��֤��
		HttpRequest img = HttpRequest.get(urlImg);
		img.receive(XdvfbImg);
		
		//��ö�Ӧ��֤���cookie��keyΪSet-Cookie��ȥ����׺
		cookiesArray = img.headers("Set-Cookie");
		cookies = cookiesArray[0].substring(0,cookiesArray[0].length()-8);
		
		return true;
	}
	
	
	public static boolean loginAndParse(String xdvfbIn){
		
		//�ø�cookie����Ϣ��½
		HttpRequest responseLogin = HttpRequest.post(urlLogin).header("Cookie",cookies)
				.form("id","2014302580176").form("pwd","19960805").form("xdvfb",xdvfbIn);
		responseLogin.body();
		
		if(responseLogin.method()=="POST")return false;
		
		//�ø�cookieץȡ�ɼ�
		responseLogin = HttpRequest.get(urlGrade).header("cookie",cookies);
		responseLogin.receive(StuGrade);
		
		return true;
	}
}
