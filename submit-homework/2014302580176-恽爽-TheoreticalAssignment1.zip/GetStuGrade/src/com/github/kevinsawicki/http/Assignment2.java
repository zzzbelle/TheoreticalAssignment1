package com.github.kevinsawicki.http;

import java.io.File;
import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import jxl.Workbook;
import jxl.write.*;

public class Assignment2 {
	private static int trs_count;
	private static int tds_count;
	
	
	/*
	 * ��html�д���һ��workbook����sort��������
	 */
	public static void transformXLS(boolean sort) throws IOException {
		// TODO Auto-generated method stub
		
		//��html�ļ�ת��ΪDocument����
		File toBeAna = new File("StuGrade.html");
		Document doc = Jsoup.parse(toBeAna,"GB2312");
		
		//����xls�ļ�
		WritableWorkbook book = Workbook.createWorkbook(new File("try.xls"));
		WritableSheet sheet = book.createSheet("��һҳ", 0);
		
		try{
			
			//���ñ����һЩ�п��и�
			sheet.setRowView(0, 350);
			sheet.setColumnView(0, 12);
			sheet.setColumnView(1, 25);
			sheet.setColumnView(5, 14);
			
			//��������tr��ǩ��ѭ������td������label��add������
			Elements trs = doc.getElementsByTag("tr");
			
			for(int i = 0; i < trs.size(); i++){
				Elements tds = trs.get(i).select("td");
				for(int j = 0; j < tds.size(); j++){
					String td = tds.get(j).text();
						Label label = new Label(j,i,td);		//ע��i��j��ת�ˣ���ΪExcel�Ĺ�ϵ
						sheet.addCell(label);
				}
			}
			
			//trsΪ������tdsΪ����
			trs_count = trs.size();
			tds_count = trs.get(1).select("td").size();
			
			
			//���sortΪtrue������
			if(sort==true)
				readXls(book);
			
			
			//�ر�
			book.write();
			book.close();
		}
		catch(Exception e){
			
		}
	}
	
	
	/*
	 * ����������ѭ���Ĳ���
	 * 		���򲿷ֵ���swapGradeXls����
	 * 		ͬʱ����ƽ���֣�����Calculate����
	 * 		ͬʱ����GPA������CalculateGPA����
	 */
	public static void readXls(WritableWorkbook book){
		try{
			WritableSheet sheet = book.getSheet(0);
			for(int i = 1; i < trs_count - 1; i++){			//��0��Ϊ�գ���ʼ��Ϊ1
				for(int j = i+1; j < trs_count; j++){
					String grade_s1 = sheet.getCell(tds_count-2, i).getContents(), grade_s2 = sheet.getCell(tds_count-2, j).getContents();
					Double grade_1 = 0.0,grade_2 = 0.0;
					
					//�жϳɼ���empty string����empty��grade = 0
					if(grade_s1 != null && !grade_s1.trim().equals("")){
						grade_1 = Double.parseDouble(sheet.getCell(tds_count-2,i).getContents());
					}
					if(grade_s2 != null && !grade_s2.trim().equals("")){
						grade_2 = Double.parseDouble(sheet.getCell(tds_count-2,j).getContents());
					}
					
					if(grade_1 < grade_2)
						swapGradeXls(i, j, sheet);
				}
			}
			
			//ƽ����GPA��ʾ�ڵ�һ��
			Label labelAve = new Label(0,0,"ƽ����");
			Label labelForAve = new Label(1,0,String.valueOf(calculate(sheet)));
			Label labelGPA = new Label(2,0,"GPA");
			Label labelForGPA = new Label(3,0,String.valueOf(calculateGPA(sheet)));
			sheet.addCell(labelAve);
			sheet.addCell(labelForAve);
			sheet.addCell(labelGPA);
			sheet.addCell(labelForGPA);
			
		}
		catch(Exception e){
			System.out.println("1");
			System.out.println(e);
		}
	}
	
	/*
	 * �������гɼ���i��jΪ��Ҫ���������У���ÿ�е�������Ԫ�񽻻�
	 */
	public static void swapGradeXls(int i,int j, WritableSheet sheet){
		
		try{
			for(int k = 0; k < tds_count; k++){
				WritableCell cell_1 = sheet.getWritableCell(k, i);
				WritableCell cell_2 = sheet.getWritableCell(k, j);
				String row_1 = sheet.getCell(k, i).getContents();
				String row_2 = sheet.getCell(k, j).getContents();
				Label lab_1 = (Label) cell_1;
				Label lab_2 = (Label) cell_2;
				lab_1.setString(row_2);
				lab_2.setString(row_1);
			}
		}
		catch(Exception e){
			System.out.println("2");
			System.out.println(e);
		}
	}
	
	
	/*
	 * ����ƽ����
	 */
	public static double calculate(WritableSheet sheet){
		double grade_current = 0.0;
		double weight_current = 0.0;
		double weighted_average = 0.0;
		double weight_amount = 0.0;
		try{
			for(int i = 0; i < trs_count; i++){
				String s_grade_current = sheet.getWritableCell(tds_count-2, i).getContents();
				if(s_grade_current != null && !s_grade_current.trim().equals("")){
					grade_current = Double.parseDouble(s_grade_current);
					weight_current = Double.parseDouble(sheet.getWritableCell(3,i).getContents());
					weight_amount = weight_amount + weight_current;
					weighted_average = weighted_average + grade_current * weight_current;
				}
			}
			weighted_average = weighted_average / weight_amount;
			
		}
		catch(Exception e){
			System.out.println(e);
		}
		return weighted_average;
	}
	
	
	/*
	 * ����GPA
	 */
	public static double calculateGPA(WritableSheet sheet){
		double grade_current = 0.0;
		double GP = 0.0;
		double weight_current = 0.0;
		double weight_amount = 0.0;
		double GPA = 0.0;

		try{
			for(int i = 0; i < trs_count; i++){
				String s_grade_current = sheet.getWritableCell(tds_count-2, i).getContents();
				if(s_grade_current != null && !s_grade_current.trim().equals("")){
					grade_current = Double.parseDouble(s_grade_current);
					if(grade_current>=90&&grade_current<=100)GP = 4.0;
					else if(grade_current>=85&&grade_current<90)GP = 3.7;
					else if(grade_current>=82&&grade_current<85)GP = 3.3;
					else if(grade_current>=78&&grade_current<82)GP = 3.0;
					else if(grade_current>=75&&grade_current<78)GP = 2.7;
					else if(grade_current>=72&&grade_current<75)GP = 2.3;
					else if(grade_current>=68&&grade_current<72)GP = 2.0;
					else if(grade_current>=64&&grade_current<68)GP = 1.5;
					else if(grade_current>=60&&grade_current<64)GP = 1.0;
					else if(grade_current<60)GP = 0;
					weight_current = Double.parseDouble(sheet.getWritableCell(3,i).getContents());
					weight_amount = weight_amount + weight_current;
					GPA = GPA + GP * weight_current;
				}
			}
			GPA = GPA / weight_amount;
			
		}
		catch(Exception e){
			System.out.println(e);
		}
		return GPA;
	}
}
