import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class gradebook implements Comparable<gradebook>{
	public gradebook(){}
	public gradebook(gradebook A){
		this.Head=A.Head;
		this.Name=A.Name;
		this.Type=A.Type;
		this.credit=A.credit;
		this.teacher=A.teacher;
		this.institute=A.institute;
		this.type=A.type;
		this.year=A.year;
		this.semester=A.semester;
		this.grade=A.grade;
	}
	String Head;
	String Name;
	String Type;
	String credit;
	String teacher;
	String institute;
	String type;
	String year;
	String semester;
	String grade;
	public String getHead(){return Head;}
	public void setHead(String Head){this.Head=Head;}
	public String getName(){return Name;}
	public void setName(String Name){this.Name=Name;}
	public String getType(){return Type;}
	public void setType(String Type){this.Type=Type;}
	public String getcredit(){return credit;}
	public void setcredit(String credit){this.credit=credit;}
	public String getteacher(){return teacher;}
	public void setteacher(String teacher){this.teacher=teacher;}
	public String getinstitute(){return institute;}
	public void setinstitute(String institute){this.institute=institute;}
	public String gettype(){return type;}
	public void settype(String type){this.type=type;}
	public String getyear(){return year;}
	public void setyear(String year){this.year=year;}
	public String getsemester(){return semester;}
	public void setsemester(String semester){this.semester=semester;}
	public String getgrade(){return grade;}
	public void setgrade(String grade){this.grade=grade;}
	public String toString(){
		return "gradebook[Head="+Head+"Name"+Name+"Type"+Type+"credit"+credit+"teacher"+teacher+"institute"+institute+"type"+type+"year"+year+"semester"+semester+"grade"+grade+"]";
	}
	public int compareTo(gradebook a){
		if(this.grade==a.grade){
			return this.Name.compareTo(a.Name);
		}else{return this.grade.compareTo(a.grade);}
	}
}
