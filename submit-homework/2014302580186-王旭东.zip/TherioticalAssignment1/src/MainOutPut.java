import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainOutPut{
	public void processScoreTable(File input){
		List<gradebook>list=null;
	BufferedReader br=null;
	BufferedWriter bw=null;
	
		
		try {
			
			File Wgradebook = new File("Wgradebook.txt");
			list = new ArrayList<gradebook>();
			br = new BufferedReader(new FileReader(input));
			bw = new BufferedWriter(new FileWriter(Wgradebook));
			
			
			char[] c = new char[2000];
			br.read(c);
			
		
			int len = 0;
			int count = 0;
			String string = null;
			gradebook t = new gradebook();
			for (int i = 0; i < c.length; i++) {
				if (c[i] == '\0') {
					break;
				}
				if (c[i] != '\t' && c[i] != '\n') {
					len++;
				}
				if (c[i] == '\t' || c[i] == '\n') {
					string = new String(c, i - len, len);
					switch (count % 10) {
					case 0:
						t.setHead(string);
						break;
					case 1:
						t.setName(string);
						break;
					case 2:
						t.setType(string);
						break;
					case 3:
						t.setcredit(string);
						break;
					case 4:
						t.setteacher(string);
						break;
					case 5:
						t.setinstitute(string);
						break;
					case 6:
						t.settype(string);
						break;
					case 7:
						t.setyear(string);
						break;
					case 8:
						t.setsemester(string);
						break;
					case 9:
						t.setgrade(string);
						break;
					}
					count++;
					if (c[i] == '\n') {
						gradebook temp = new gradebook(t);
						list.add(temp);

					}
					len = 0;
				}
			}
			
			
			double sumCredit = 0;
			
			double sumCC = 0;
			
			double sumGPA = 0;
			
		
			CountGpa cGpa = new CountGpa();

			Collections.sort(list);
			for (gradebook t1 : list) {
				bw.write(t1.Head + "\t" + t1.Name + "\t"
						+ t1.Type + "\t" + t1.credit + "\t" + t1.teacher
						+ "\t" + t1.institute + "\t" + t1.type
						+ "\t" + t1.year + "\t" + t1.semester + "\t" + t1.grade
						+ "\n");
				bw.flush();
				sumCredit += Double.parseDouble(t1.credit);
				sumCC += Double.parseDouble(t1.credit)
						* Double.parseDouble(t1.grade);
				sumGPA += cGpa.getGpa(Double.parseDouble(t1.grade))
						* Double.parseDouble(t1.credit);
			}
	
			java.text.DecimalFormat df = new java.text.DecimalFormat("#.00");
			bw.write("��Ȩƽ����" + "\t\t\t\t\t\t\t\t\t"
					+ df.format(sumCC / sumCredit) + "\n" + "��ȨGPA"
					+ "\t\t\t\t\t\t\t\t\t" + df.format(sumGPA / sumCredit));
		} catch (IOException e) {
		
			e.printStackTrace();
		} finally {
		
			if (bw != null) {
				try {
					bw.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

		
		
		
		
}
