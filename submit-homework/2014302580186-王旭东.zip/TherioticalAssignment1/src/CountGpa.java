import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

 public class CountGpa{
	public double getGpa(double d){
		if(90<d&&d<=100){
			return 4.0;
		}else if(85<d&&d<=90){
			return 3.7;
		}else if(82<d&&d<=85){
			return 3.3;
		}else if(79<d&&d<=82){
			return 3.0;
		}else if(75<d&&d<=79){
			return 2.7;
		}else if(72<d&&d<=75){
			return 2.3;
		}else if(68<d&&d<=72){
			return 2.0;
		}return 0;
	}
}