/**
 Packages to support the CSS-style element selector.
 */
package org.jsoup.select;