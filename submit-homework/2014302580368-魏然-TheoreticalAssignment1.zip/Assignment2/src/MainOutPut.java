import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;

import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import jxl.Workbook;
public class MainOutPut<WritableWorkbook> {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MainOutPut mop=new MainOutPut();
		try {
			mop.processScoreTable();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void processScoreTable()  throws Exception{
	ArrayList<Grade>Info=new ArrayList<Grade>();
	File file=new File("G:/javaʵ��/Assignment2/grade.txt");
	jxl.write.WritableWorkbook workbook = Workbook.createWorkbook(new FileOutputStream("Grade.xls"));
	WritableSheet sheet = workbook.createSheet("SHEET", 0);
	//��ȡ�ɼ�
	BufferedReader reader =null;
	String tempString =null;
	try{
		InputStreamReader isr = new InputStreamReader(new FileInputStream(file),"Unicode");
		reader =new BufferedReader(isr);
		while((tempString=reader.readLine())!=null){
			String []arr=tempString.split("\\t+");
			Info.add(new Grade(arr[0],arr[1],arr[2],arr[3],arr[4],arr[5],arr[6],arr[7],arr[8],arr[9]));
		}
		reader.close();
		Collections.sort(Info,new GradeOp());
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}finally{
			if(reader!=null){
				try{
						reader.close();
					}catch(IOException e){
						e.printStackTrace();
										}
							}
				}
	//����ɼ�
	for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            Label label = new Label(j, i, Info.get(i).item[j]);
            sheet.addCell(label);
        }
    }
    String As = String.valueOf(new GradeOp().getAverageScore(Info));
    //ƽ����
    Label label1 = new Label(0, 11, "��Ȩƽ����");
    sheet.addCell(label1);
    Label averageScoreLabel = new Label(1,11, As);
    sheet.addCell(averageScoreLabel);
    String Ag = String.valueOf(new GradeOp().getAverageGPA(Info));
    //ƽ��GPA
    Label label2 = new Label(0,12, "�ۺϼ�ȨGPA");
    sheet.addCell(label2);
    Label GPALabel = new Label(1,12, Ag);
    sheet.addCell(GPALabel);
    workbook.write();
    workbook.close();
	}
}
