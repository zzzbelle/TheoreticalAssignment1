import java.util.ArrayList;
import java.util.Comparator;

class GradeOp implements Comparator{
	//����
	public int compare(Object object1,Object object2)
	{
		Grade Grade1 = (Grade)object1;
		Grade Grade2 = (Grade)object2;
		return new Double(Grade2.getScore()).compareTo(new Double(Grade1.getScore()));
	}
	//����GPA;
	public double getAverageGPA(ArrayList<Grade>Info){
		double sumcredit=0;
		double sumgpa = 0;
		for(Grade i:Info)
		{	
			double gpa=0;
			double s=Double.parseDouble(i.getScore());
			sumcredit = sumcredit+Double.parseDouble(i.getCredit());
			if(s>=90&&s<=100)
			{
				gpa = 4.0;
			}
			if(s>=85&&s<=89)
			{
				gpa = 3.7;
			}
			if(s>=82&&s<=84)
			{
				gpa = 3.3;
			}
			if(s>=78&&s<=81)
			{
				gpa = 3.0;
			}
			if(s>=75&&s<=77)
			{
				gpa = 2.7;
			}
			if(s>=72&&s<=74)
			{
				gpa = 2.3;
			}
			if(s>=68&&s<=71)
			{
				gpa = 2.0;
			}
			if(s>=64&&s<=67)
			{
				gpa = 1.5;
			}
			if(s>=60&&s<=63)
			{
				gpa = 1.0;
			}
			if(s<60)
			{
				gpa = 0;
			}
			sumgpa= sumgpa+gpa*Double.parseDouble(i.getCredit());
		}
		return(sumgpa/sumcredit);
	}
	//����ƽ����
	public double getAverageScore(ArrayList<Grade>Info){
		double sumscore=0;
		double sumcredit=0;
		for(Grade i:Info){
			sumcredit = sumcredit+Double.parseDouble(i.getCredit());
			sumscore=sumscore+Double.parseDouble(i.getScore())*Double.parseDouble(i.getCredit());
		}
		return(sumscore/sumcredit);
	}
}