import java.io.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
//import org.apache.poi.xssf.usermodel.examples.CreateCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFCell;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import javax.swing.text.Document;
//import java.net.URL;

public class grades {

	/*
	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		//	String filename="test.xls";
	File filename=new File("./scores.xls");
	processGradeTable(filename);
	
	}*/
	 public static void main(String args[]){
		 JFrame frame=new JFrame("first gui");

	       JLabel lbl=new JLabel("�����ť����ɲ���");
	       lbl.setBackground(Color.green);
	       lbl.setSize(150,50);
	       frame.setLayout(new FlowLayout());
	       frame.add(lbl);
	       frame.setVisible(true);
	       JPanel panel=new JPanel();
	       JButton btn=new JButton("��ť");
	       btn.addActionListener(new ActionListener(){
	    	   public void actionPerformed(ActionEvent e){
	    		   try {
					operaction();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	    	   }
	       });
	       panel.setBackground(Color.cyan);
	       panel.setSize(150,50);
	       panel.setLocation(0,50);
	       frame.setLayout(null);
	       frame.add(panel);
	       panel.add(btn);
	       frame.setLocation(80,120);
	       frame.setSize(150,150);
	       frame.setVisible(true);  
	       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	       System.out.println("end");
	      }
	
	 public static void operaction() throws IOException{
		 File filename=new File("./scores.xls");
			processGradeTable(filename);
	 }

	public static void processGradeTable(File input) throws IOException{
		double ave=0;//��ƽ���ɼ�
		double gpa=0;
		double sum=0;//�ǳɼ�
		double score=0;//��ѧ��
		
		//����excel�ļ�
		FileInputStream in = new FileInputStream(input);
		//
		HSSFWorkbook wb = new HSSFWorkbook(in);
		HSSFSheet st = wb.getSheetAt(0);
		//
		HSSFWorkbook nwb=new HSSFWorkbook();
		//����һ���µı���
		HSSFSheet nst = nwb.createSheet();
		//��ȡ��һ�У�û�б�������ʧ��
		HSSFRow row= st.getRow(0); 				// ����д����         <-- 
		//��ȡ��һ����Ԫ��û�б�������ʧ��
		HSSFCell cell = row.getCell(0);
		//��cell�еĶ�����ȡ����
		//System.out.printf("%s", cell);

		int a ;
		for(int i=0;i < 40;i++)
		{
			nst.createRow(i);
			for(a= 0; a < 15; a++){
				nst.getRow(i).createCell(a);
			}
		}
		/*// ȥ������
		int j= 1;
		int i;
		for(i=1; i< 110; i++){
			if(st.getRow(i).getCell(0).getNumericCellValue() > 0){
				System.out.printf("%d, %d",  i,j);
				for(a = 0; a < 15; a++){
					//nst.getRow(j).getCell(a).setCellValue(st.getRow(i).getCell(a).toString());
					//nst.getRow(j).getCell(a).setCellValue("aa");
				}
				j++;
			}
		}*/
		//�����ܷ֡��ܼ���
		int i;
		int j;
		for( i=1;i<=26;i++)
		{
			sum += st.getRow(i).getCell(3).getNumericCellValue()*st.getRow(i).getCell(9).getNumericCellValue();
			score+=st.getRow(i).getCell(9).getNumericCellValue();
		}
		//����ƽ���ɼ������
		System.out.println(score);
		ave=sum/score;
		nst.getRow(28).getCell(0).setCellValue("ƽ���ɼ�Ϊ��");
		nst.getRow(28).getCell(1).setCellValue(ave);
		//���㼨��
		double point []=new double[30];
		for( j = 1; j<=26; j++)
		{
			if(st.getRow(j).getCell(9).getNumericCellValue() >= 90)
			{
				point[j] = 4.0;
			}
			else if(st.getRow(j).getCell(9).getNumericCellValue() >= 85
					&&st.getRow(j).getCell(9).getNumericCellValue() <= 89)
			{
				point[j] = 3.7;
			}
			else if(st.getRow(j).getCell(9).getNumericCellValue() >= 82
					&& st.getRow(j).getCell(9).getNumericCellValue() <= 84)
			{
				point[j] = 3.3;
			}
			else if(st.getRow(j).getCell(9).getNumericCellValue() >= 78
					&& st.getRow(j).getCell(9).getNumericCellValue() <= 81)
			{
				point[j] = 3.0;
			}
			else if(st.getRow(j).getCell(9).getNumericCellValue() >= 75
					&& st.getRow(j).getCell(9).getNumericCellValue() <= 77)
			{
				point[j] = 2.7;
			}
			else if(st.getRow(j).getCell(9).getNumericCellValue() >= 72
					&& st.getRow(j).getCell(9).getNumericCellValue() <= 74)
			{
				point[j] = 2.3;
			}
			else if(st.getRow(j).getCell(9).getNumericCellValue() >= 68
					&& st.getRow(j).getCell(9).getNumericCellValue() <= 71)
			{
				point[j] = 2.0;
			}
			else if(st.getRow(j).getCell(9).getNumericCellValue() >= 64
					&& st.getRow(j).getCell(9).getNumericCellValue() <= 67)
			{
				point[j] = 1.5;
			}
			else if(st.getRow(j).getCell(9).getNumericCellValue() >= 60
					&& st.getRow(j).getCell(9).getNumericCellValue() <= 63)
			{
				point[j] = 1.0;
			}
			else
			{
				point[j] = 0.0;
			}
			gpa += point[j]*st.getRow(j).getCell(3).getNumericCellValue();
		}
		gpa=gpa/score;
		//���gpa
		nst.getRow(38).getCell(0).setCellValue("GPA��");
		nst.getRow(38).getCell(1).setCellValue(gpa);
		
		
		    int size = 26; // �����С   
		    for (i = 1; i <= size ; i++) {   
		        for ( j = i + 1; j <= size; j++) {   
		            if (st.getRow(i).getCell(9).getNumericCellValue() < st.getRow(j).getCell(9).getNumericCellValue()) { // ����������λ��   
		            	
		                copyrow(st.getRow(j), nst.getRow(0)); 
		                copyrow(st.getRow(i), st.getRow(j));
		                copyrow(nst.getRow(0), st.getRow(i));
		            }   
		        }   
		    }   
		 for(i = 0; i <= size; i++){
			 copyrow(st.getRow(i), nst.getRow(i));
		 }
		//����ļ�
		FileOutputStream out=new FileOutputStream("./����ɼ���.xls");
		//�ر������
		nwb.write(out);
		in.close();
		out.close();
		nwb.close();
		System.out.printf("end");
	}

	public static void copyrow(HSSFRow row, HSSFRow row2){
		int a;
		for(a = 0; a < 10; a++){
			if (row.getCell(a).getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {
				row2.getCell(a).setCellValue(row.getCell(a).getNumericCellValue());
			} else if (row.getCell(a).getCellType() == HSSFCell.CELL_TYPE_STRING) {
				row2.getCell(a).setCellValue(row.getCell(a).getStringCellValue());
			} else {
				System.out.println("error");
			}
		}
	}


	}


