import java.io.File;
public class ImageCrawler 
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		String url="http://210.42.121.132/servlet/GenImg";
		//get image
		for(int counter=0;counter<10;counter++)
		{
			HttpRequest response=HttpRequest.get(url);
			String fName="test"+Integer.toString(counter)+".png";
			if(response.ok())
			{
				response.receive(new File(fName));
			}
		}
		
	}

}
