/**1.html����
 * 2.xls��ȡ
 *3.xlsд��
 *4.����
 *5.gpa
 *6.ƽ����
 *7.д�뵽����
 */
/**
 * @author ��
 *
 */
import java.io.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.*;
import org.jsoup.parser.*;
import org.jsoup.select.*;

import jxl.read.biff.BiffException;
import jxl.write.*;
import jxl.write.biff.RowsExceededException;
import jxl.*;

import java.text.DecimalFormat;

public class Data {
	//
	// ����������������html����
	// ͻȻ���ֿ������������棬һ�����γ̶���ʱ�����ޣ��˴�͵��
	// ͻȻ����items�Ļ��ۼ����������û�����Ĵ���ÿ���γ̵����ݵ�
	// ��������ûɶ�ã��ʷ����ȣ���ѭ�����������ڵ����

	private static int items = 0;
	private static int courses = 0;
	public static String[] itemStr = new String[15];
	public static String[][] data;

	public static boolean htmlR() {
		String place = "out.html";
		try {
			File input = new File(place);
			Document html = Jsoup.parse(input, "GB2312");

			Elements all = html.getElementsByTag("tr");
			courses = 0;
			int count = 0;
			for (Element index : all) {

				if (courses == 0) {
					// ��ʼ��
					Elements rowData = index.getElementsByTag("th");
					for (Element head2 : rowData) {
						itemStr[items] = head2.text();
						items++;
					}
					data = new String[200][items];
					courses++;// ���һ��
				} else {
					Elements rowData = index.getElementsByTag("td");
					for (Element course : rowData) {
						data[courses - 1][count] = course.text();
						count++;
					}
					count = 0;
					courses++;
				}
			}
			courses--;// ȥ������һ��
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return false;
		}

	}

	public static boolean xlsR() {
		// ���¶���xls��ʱ�����޾Ͳ�����ѡ������xls�м����ˣ�ֱ��Ĭ�϶���original
		try {
			Workbook book = Workbook.getWorkbook(new File("original.xls"));
			Sheet sheet = book.getSheet(0);
			for (int i = 0; i < items; i++) {
				for (int j = 1; j < courses; j++) {
					data[j][i] = sheet.getCell(i, j).getContents();
				}
			}
			book.close();
		} catch (BiffException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}

	public static boolean dataW(String mode) {
		try {
			WritableWorkbook book = Workbook.createWorkbook(new File(mode
					+ ".xls"));
			WritableSheet sheet = book.createSheet("1", 0);
			for (int i = 0; i < items; i++) {
				for (int j = 0; j < courses; j++) {
					if (j == 0) {
						try {
							sheet.addCell(new Label(i, j, itemStr[i]));
						} catch (RowsExceededException e) {
							// TODO Auto-generated catch block
							return false;
						}
					} else {
						try {
							sheet.addCell(new Label(i, j, data[j - 1][i]));
						} catch (RowsExceededException e) {
							// TODO Auto-generated catch block
							return false;
						}
					}

				}
			}
			book.write();
			book.close();
			return true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			return false;
		} catch (WriteException e) {
			return false;
		}

	}

	public static void sort() {
		// �����׶ˣ�Ӧ��������
		// �������n����Ŀ���ޡ�����
		Float last;
		Float this_one = 0.0f;
		String temp;
		for (int i = 1; i < courses; i++) {
			if (data[i][9].length() > 0)
				this_one = Float.valueOf(data[i][9]);
			else
				break;
			System.out.println(data[i][9]);
			for (int j = i - 1; j >= 0; j--) {
				try {
					last = Float.valueOf(data[j][9]);
					if (this_one > last) {
						// ���������lastһ�����ﵽ��������Ч��
						for (int k = 0; k < items; k++) {
							temp = data[j][k];
							data[j][k] = data[j + 1][k];
							data[j + 1][k] = temp;
							this_one = Float.valueOf(data[j][9]);
						}

					} else
						break;
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					break;
				}

			}
		}
	}

	public static double GPA() {
		double GPA = 0;
		int point;
		int sumpoint = 0;
		int mark;
		int[] markP = new int[101];
		// ��ʼ�������ж������ܱ�ÿ�η�֧10��Ҫ��
		for (int i = 0; i < 101; i++) {
			if (i <= 60)
				markP[i] = 0;
			else if (i <= 63)
				markP[i] = 10;
			else if (i <= 67)
				markP[i] = 15;
			else if (i <= 71)
				markP[i] = 20;
			else if (i <= 74)
				markP[i] = 23;
			else if (i <= 77)
				markP[i] = 27;
			else if (i <= 81)
				markP[i] = 30;
			else if (i <= 84)
				markP[i] = 33;
			else if (i <= 89)
				markP[i] = 37;
			else if (i <= 100)
				markP[i] = 40;
		}
		for (int i = 0; i < courses; i++) {
			if (data[i][9].length() > 0) {
				point = (Integer.valueOf((data[i][3]).substring(0, 1))
						.intValue())
						* 10
						+ Integer.valueOf((data[i][3]).substring(2, 3))
								.intValue();
				mark = Integer.valueOf((data[i][9]).substring(0, 2)).intValue();
				GPA += (markP[mark]) * point;
				sumpoint += point;
			}
		}
		return GPA = GPA / (10 * sumpoint);
	}

	public static double average() {
		double average = 0;
		int mark;
		int point;
		int sumpoint = 0;
		for (int i = 0; i < courses; i++) {

			if (data[i][9].length() > 0) {

				mark = Integer.valueOf((data[i][9]).substring(0, 2)).intValue();

				point = (Integer.valueOf((data[i][3]).substring(0, 1))
						.intValue())
						* 10
						+ Integer.valueOf((data[i][3]).substring(2, 3))
								.intValue();
				average = mark * point + average;
				sumpoint += point;
			} else {
				break;// ��ֹѡ�˿�û�ɼ���
			}
		}
		return average = average / sumpoint;
	}

	public static boolean GPA_MARK_W(double GPA, double average) {
		try {
			Workbook wb = Workbook.getWorkbook(new File("after.xls"));
			WritableWorkbook book = Workbook.createWorkbook(new File(
					"after.xls"), wb);
			WritableSheet sheet = book.getSheet(0);

			try {
				sheet.addCell(new Label(0, courses + 1, "����"));
				sheet.addCell(new Label(0, courses + 2, "��Ȩƽ����"));
				DecimalFormat df = new DecimalFormat("######0.00");
				String temp = df.format(GPA).toString();
				sheet.addCell(new Label(1, courses + 1, temp));
				temp = df.format(average).toString();
				sheet.addCell(new Label(1, courses + 2, temp));
			} catch (RowsExceededException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			book.write();
			book.close();
		} catch (BiffException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} catch (WriteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return true;
	}
}
