import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.TextField;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Window.Type;
import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;

import java.awt.Toolkit;

import javax.swing.AbstractAction;

import java.awt.event.ActionEvent;

import javax.swing.Action;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;

import java.awt.image.BufferedImage;
import java.io.*;

import jdk.nashorn.internal.objects.DataPropertyDescriptor;
import javax.swing.JPasswordField;

/*
 * @author��
 * ��������˵��Ի���ϵͳ����buildpath��jre library��������Ҳ������
 */
public class MainGUI extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_2;
	private JLabel lblNewLabel_1;
	public static String cookies;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainGUI frame = new MainGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

	}

	/**
	 * Create the frame.
	 */
	public MainGUI() {
		setIconImage(Toolkit
				.getDefaultToolkit()
				.getImage(
						MainGUI.class
								.getResource("/javax/swing/plaf/metal/icons/ocean/file.gif")));
		setResizable(false);
		setBackground(new Color(240, 255, 255));
		setTitle("\u6210\u7EE9\u5904\u7406");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		// ���߱���
		JLabel lblJamieLuo = new JLabel("Jamie Luo");
		lblJamieLuo.setBounds(5, 5, 424, 22);
		lblJamieLuo.setHorizontalAlignment(SwingConstants.CENTER);
		lblJamieLuo.setFont(new Font("΢���ź�", Font.BOLD, 16));
		// ѧ������
		JLabel label = new JLabel("\u5B66\u53F7");
		label.setBounds(115, 47, 30, 20);
		label.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		// ѧ�������
		textField = new JTextField();
		textField.setBounds(165, 45, 160, 20);
		textField.setColumns(10);
		// ��������
		JLabel lblNewLabel = new JLabel("\u5BC6\u7801");
		lblNewLabel.setBounds(115, 95, 30, 20);
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		// ��֤������
		JLabel label_1 = new JLabel("\u9A8C\u8BC1\u7801");
		label_1.setBounds(104, 174, 45, 20);
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		// ��֤�������
		textField_2 = new JTextField();
		textField_2.setBounds(159, 174, 67, 20);
		textField_2.setColumns(10);
		// �����¼��ť
		JButton btnNewButton_1 = new JButton("\u722C\u53D6");
		btnNewButton_1.setBounds(193, 214, 60, 25);
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// �������ȡ
				String number = textField.getText();
				// System.out.println(textField.getText());
				// System.out.println(textField_1.getText());
				StringBuffer pw = new StringBuffer();
				char[] correctPassword = passwordField.getPassword();
				pw.append(correctPassword);
				String pwt = pw.toString();
				// System.out.println(textField_2.getText());
				String xdvfb = textField_2.getText();
				if (Login.Login(number, pwt, xdvfb, cookies)) {
					JOptionPane.showMessageDialog(MainGUI.this, "��¼�ɹ�");
					// ��ȡhtml
					if (!(Data.htmlR())) {
						JOptionPane.showMessageDialog(MainGUI.this,
								"��ȡhtmlʧ�ܣ������µ�½��ȡ");
						cookies = getimage.getimage();
						BufferedImage image;
						try {
							image = ImageIO.read(new File("the_enter_one.png"));
							lblNewLabel_1.setIcon(new ImageIcon(image));
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							JOptionPane.showMessageDialog(MainGUI.this,
									"��֤���ȡʧ��");
						}
					} else {
						// ....
						DataP frame2 = new DataP();
						frame2.setVisible(true);
						dispose();
					}
				} else {
					JOptionPane.showMessageDialog(MainGUI.this, "��¼ʧ��");
					cookies = getimage.getimage();
					BufferedImage image;
					try {
						image = ImageIO.read(new File("the_enter_one.png"));
						lblNewLabel_1.setIcon(new ImageIcon(image));
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(MainGUI.this, "��֤���ȡʧ��");
					}

				}
			}
		});
		btnNewButton_1.setFont(new Font("΢���ź�", Font.PLAIN, 12));

		JButton button = new JButton("\u70B9\u51FB\u5237\u65B0");
		button.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		button.setBounds(232, 173, 91, 23);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// �����ˢ��
				cookies = getimage.getimage();
				BufferedImage image;
				try {
					image = ImageIO.read(new File("the_enter_one.png"));
					lblNewLabel_1.setIcon(new ImageIcon(image));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(MainGUI.this, "��֤���ȡʧ��");
				}

			}
		});
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		contentPane.setLayout(null);
		contentPane.add(lblJamieLuo);
		contentPane.add(label);
		contentPane.add(textField);
		contentPane.add(lblNewLabel);
		contentPane.add(label_1);
		contentPane.add(textField_2);
		contentPane.add(button);
		contentPane.add(btnNewButton_1);

		lblNewLabel_1 = new JLabel("");
		cookies = getimage.getimage();
		if (cookies.equals(" ")) {
			lblNewLabel_1.setIcon(new ImageIcon("noimg.jpg"));
		} else {
			lblNewLabel_1.setIcon(new ImageIcon("the_enter_one.png"));
		}

		lblNewLabel_1.setBounds(175, 127, 120, 30);
		contentPane.add(lblNewLabel_1);

		passwordField = new JPasswordField();
		passwordField.setBounds(165, 96, 160, 21);
		contentPane.add(passwordField);
	}
}
