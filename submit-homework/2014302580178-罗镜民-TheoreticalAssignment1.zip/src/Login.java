/**
 * login the ���� && ��ȥ
 */

/**
 * @author ��
 *
 */
import java.util.HashMap;
import java.util.Map;
import java.awt.image.BufferedImage;
import java.io.*;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import com.github.kevinsawicki.http.*;
import com.github.kevinsawicki.http.HttpRequest.HttpRequestException;

public class Login {
	public static boolean Login(String number, String pwd, String xdvfb,
			String cookies) {
		// System.out.println(cookies);
		// test 100 image
		// GetImage(ImgUrl);
		String CourserUrl = "http://210.42.121.132/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0";
		String LoginUrl = "http://210.42.121.132/servlet/Login";
		Map<String, String> data = new HashMap<String, String>();
		data.put("id", number);
		data.put("pwd", pwd);
		data.put("xdvfb", xdvfb);
		HttpRequest login;
		try {
			login = HttpRequest.post(LoginUrl).header("Cookie", cookies)
					.form(data).followRedirects(false);
			int length = login.body().length();
			if (length > 8)
				return false;
		} catch (HttpRequestException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		// show you the problem or keep
		// simulation of login
		File output = new File("out.html");
		HttpRequest.get(CourserUrl).header("Cookie", cookies).receive(output);
		// System.out.println(cookies);
		return true;
	}
}
