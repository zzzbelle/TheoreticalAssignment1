import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;

import javax.swing.JProgressBar;
import javax.swing.SwingConstants;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JLabel;

import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JList;

public class DataP extends JFrame {

	/**
	 * Create the frame.
	 */
	public DataP() {
		setResizable(false);

		setTitle("\u8C03\u620F\u6570\u636E");
		setIconImage(Toolkit
				.getDefaultToolkit()
				.getImage(
						DataP.class
								.getResource("/com/sun/java/swing/plaf/windows/icons/HardDrive.gif")));
		setBounds(100, 100, 436, 322);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);

		JButton btnNima = new JButton("\u53EA\u5BFC\u51FAxls");
		btnNima.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (Data.dataW("original")) {
					JOptionPane.showMessageDialog(DataP.this, "д��ɹ�");
				} else {
					JOptionPane.showMessageDialog(DataP.this, "ʧ��");
				}
			}
		});
		btnNima.setFont(new Font("΢���ź�", Font.BOLD, 14));
		btnNima.setBounds(10, 10, 111, 33);
		getContentPane().add(btnNima);

		JButton btnLogOut = new JButton("log out");
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				MainGUI frame = new MainGUI();
				frame.setVisible(true);
			}
		});
		btnLogOut.setBounds(331, 10, 93, 23);
		getContentPane().add(btnLogOut);

		JLabel lblJava = new JLabel("original.xls\uFF08\u9700\u8981\u5148\u6309\uFF09");
		lblJava.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		lblJava.setBounds(131, 10, 195, 33);
		getContentPane().add(lblJava);

		JButton btnxls = new JButton("\u91CD\u8F7D\u4E0A\u9762xls");
		btnxls.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (Data.xlsR()) {
					JOptionPane.showMessageDialog(DataP.this, "���سɹ�");
				} else {
					JOptionPane.showMessageDialog(DataP.this, "����ʧ��");
				}
			}
		});
		btnxls.setFont(new Font("΢���ź�", Font.BOLD, 14));
		btnxls.setBounds(10, 70, 111, 33);
		getContentPane().add(btnxls);

		JLabel label = new JLabel(
				"\u91CD\u8F7D\u5FC5\u987B\u540C\u540D~\u683C\u5F0F\u4E0D\u80FD\u4E71\u6539~\u53EF\u589E\u5220\u8BFE\u7A0B\u6761\u76EE");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		label.setBounds(131, 74, 274, 24);
		getContentPane().add(label);

		JButton button = new JButton("\u6574\u7406\u5E76\u8F93\u51FA");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Data.sort();
				if (Data.dataW("after")) {
					JOptionPane.showMessageDialog(DataP.this,
							"�ѱ��浽����Ŀ¼��after.xls");
				} else {
					JOptionPane.showMessageDialog(DataP.this, "д���ļ�ʧ��");
				}
			}
		});
		button.setFont(new Font("΢���ź�", Font.BOLD, 14));
		button.setBounds(10, 140, 111, 33);
		getContentPane().add(button);

		JLabel lblAfterxls = new JLabel("after.xls");
		lblAfterxls.setFont(new Font("΢���ź�", Font.BOLD, 14));
		lblAfterxls.setBounds(131, 140, 98, 33);
		getContentPane().add(lblAfterxls);

		JLabel label_1 = new JLabel("\u7EE9\u70B9:");
		label_1.setFont(new Font("΢���ź�", Font.BOLD, 14));
		label_1.setBounds(193, 226, 73, 50);
		getContentPane().add(label_1);

		JLabel label_2 = new JLabel("\u52A0\u6743\u5E73\u5747\u5206:");
		label_2.setFont(new Font("΢���ź�", Font.BOLD, 14));
		label_2.setBounds(193, 186, 138, 50);
		getContentPane().add(label_2);

		JButton btnNewButton = new JButton(
				"\u4FDD\u5B58\u5230\u8868\u683Cafter");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double GPA = Data.GPA();
				double average = Data.average();
				if (Data.GPA_MARK_W(GPA, average)) {
					JOptionPane.showMessageDialog(DataP.this,
							"�ѱ��浽����Ŀ¼��after.xls");
				} else {
					JOptionPane.showMessageDialog(DataP.this, "д���ļ�ʧ��");
				}
			}
		});
		btnNewButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		btnNewButton.setBounds(10, 243, 179, 33);
		getContentPane().add(btnNewButton);

		JButton btngpa = new JButton("\u8BA1\u7B97GPA/\u5E73\u5747\u5206");
		btngpa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double GPA = Data.GPA();
				double average = Data.average();
				String temp = label_2.getText();
				label_2.setText(temp + average);
				temp = label_1.getText();
				label_1.setText(temp + GPA);
			}
		});
		btngpa.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		btngpa.setBounds(10, 193, 179, 40);
		getContentPane().add(btngpa);

	}
}
