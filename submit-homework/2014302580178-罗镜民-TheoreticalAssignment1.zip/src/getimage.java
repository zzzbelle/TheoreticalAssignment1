/**
 * getimage from  whu jiaowu
 */

/**
 * @author ��
 *
 */
import com.github.kevinsawicki.http.*;
import java.io.*;

public class getimage {
	public static String getimage() {
		String ImgUrl = "http://210.42.121.132/servlet/GenImg";
		// get the cookie by the captcha image
		HttpRequest response = HttpRequest.get(ImgUrl);
		if (response.ok()) {
			/*
			 * we can output headers by .headers() find that
			 * {Transfer-Encoding=[chunked], null=[HTTP/1.1 200 OK],
			 * Server=[nginx/1.2.1], Connection=[keep-alive],
			 * Set-Cookie=[JSESSIONID=A695B6EC76986E05F87AB2D66FD49BE9.tomcat2;
			 * Path=/], Expires=[Thu, 01 Jan 1970 00:00:00 GMT], Date=[Sun, 27
			 * Sep 2015 06:16:50 GMT], Content-Type=[image/jpeg]}
			 */
			String cookies = response.header("Set-Cookie");
			String FileName = "the_enter_one.png";
			// System.out.println(cookies);
			response.receive(new File(FileName));
			// System.out.println(cookies);
			return cookies;
		}
		return " ";
	}
}
