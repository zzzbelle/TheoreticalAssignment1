package shiyan2;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import jxl.Cell;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.*;
import jxl.write.Number;

import java.util.*;
import java.io.FileOutputStream;


public class MainOutPut 
{
	public static void main(String[] args) throws BiffException, IOException{
		MainOutPut a= new MainOutPut();
		a.read("1.xls");
		a.processScoreTable("test.xls");
	}

private Vector<line>  data=new Vector<line>();
//��ȡԭ����excel���񣬲��������vector��
private void read(String filename) throws BiffException, IOException
{
	try
	{
		
		
		InputStream is = new FileInputStream(filename);
		jxl.Workbook rwb = Workbook.getWorkbook(is);
		jxl.Sheet rs = rwb.getSheet(0);
		for(int i=1;i<=26;i++){
			line l=new line();
			l.numbers=rs.getCell(0,i).getContents();
			l.courses=rs.getCell(1,i).getContents();
			l.types=rs.getCell(2,i).getContents();
			l.credits=Double.valueOf(rs.getCell(3,i).getContents()).doubleValue();
			l.teachers=rs.getCell(4,i).getContents();
			l.colleges=rs.getCell(5,i).getContents();
			l.studytypes=rs.getCell(6,i).getContents();
			l.years=Integer.valueOf(rs.getCell(7,i).getContents()).intValue();
			l.terms=rs.getCell(8,i).getContents();
			l.grades=Integer.valueOf(rs.getCell(9,i).getContents()).intValue();
			data.add(l);
		}
		
	}
	finally{
		
	}

}


private void processScoreTable(String filename)
{
	System.out.println(data.size());
	Collections.sort(data,new Comparator<Object>(){
		public int compare(Object left,Object right){
			line l=(line)left;
			line r=(line)right;
			if(l.grades>r.grades){
				return -1;
			}else{
				return 1;
			}
		}
	});
 
	String[] title = {"��ͷ��","�γ�����","�γ�����","ѧ��","��ʦ","�ڿ�ѧԺ","ѧϰ����","ѧ��","ѧ��","�ɼ�","��Ȩƽ����","�ۺϼ�Ȩƽ����"};   
     try {     
         // ����Excel������   
         jxl.write.WritableWorkbook wwb;   
         // �½���һ��jxl�ļ�,����C��������test.xls   
         java.io.OutputStream os = new FileOutputStream(filename);   
         wwb=Workbook.createWorkbook(os);    
         // ���ӵ�һ�������������õ�һ��Sheet������   
         jxl.write.WritableSheet sheet = wwb.createSheet("�ɼ���", 0);   
       
         for(int i=0;i<12;i++)
         {
        	 Label label = new jxl.write.Label(i,0,title[i]);
        	 sheet.addCell(label);
         }
         double GPA=0;
    	 double allGPA=0;
    	 double allcredits=0;
    	 double allgrades=0;
         for(int j=1;j<=26;j++)
         {
        	 Label a = new jxl.write.Label(0,j,data.get(j-1).numbers);
        	 sheet.addCell(a);
        	 Label b = new jxl.write.Label(1,j,data.get(j-1).courses);
        	 sheet.addCell(b);
        	 Label c = new jxl.write.Label(2,j,data.get(j-1).types);
        	 sheet.addCell(c);
        	 Number d = new Number(3,j,data.get(j-1).credits);
        	 sheet.addCell(d);
        	 Label e = new jxl.write.Label(4,j,data.get(j-1).teachers);
        	 sheet.addCell(e);
        	 Label f = new jxl.write.Label(5,j,data.get(j-1).colleges);
        	 sheet.addCell(f);
        	 Label g = new jxl.write.Label(6,j,data.get(j-1).studytypes);
        	 sheet.addCell(g);
        	 Number h = new Number(7,j,data.get(j-1).years);
        	 sheet.addCell(h);
        	 Label i = new jxl.write.Label(8,j,data.get(j-1).terms);
        	 sheet.addCell(i);
        	 Number k = new Number(9,j,data.get(j-1).grades);
        	 sheet.addCell(k);
        	
        	 allgrades+= data.get(j-1).credits*data.get(j-1).grades;
        	 
        	 if(data.get(j-1).grades>=90){
        		 GPA=4.0;
        	 }
        	 else if(data.get(j-1).grades>=85){
        		 GPA=3.7;
        	 }
        	 else if(data.get(j-1).grades>=82){
        		 GPA=3.3;
        	 }
        	 else if(data.get(j-1).grades>=78){
        		 GPA=3.0;
        	 }
        	 else if(data.get(j-1).grades>=75){
        		 GPA=2.7;
        	 }
        	 else if(data.get(j-1).grades>=72){
        		 GPA=2.3;
        	 } else if(data.get(j-1).grades>=68){
        		 GPA=2.0;
        	 } else if(data.get(j-1).grades>=64){
        		 GPA=1.5;
        	 }
        	 allGPA+=data.get(j-1).credits*GPA;
        	allcredits+=data.get(j-1).credits;
         }
         double averagegrades=allgrades/allcredits;
         double averageGPA=allGPA/allcredits;
         Number r = new Number(10,1,averagegrades);
         sheet.addCell(r);
         Number s = new Number(11,1,averageGPA);
         sheet.addCell(s);
         wwb.write();
         wwb.close();
     }catch (Exception e) {   
             System.out.println("---�����쳣---");   
             e.printStackTrace();   
         }
}
class line{
	public String numbers;
	public String courses;
	public String types;
	public double credits;
	public String teachers;
	public String colleges;
	public String studytypes;
	public int years;
	public String terms;
	public int grades;
	public line(String a,String b,String c,double d,String e,String f,String g,int h,String i,int j) {
	}
	public line(){
		
	}
	
}
}

