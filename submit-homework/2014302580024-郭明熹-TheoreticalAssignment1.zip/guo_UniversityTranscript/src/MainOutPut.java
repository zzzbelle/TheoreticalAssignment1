import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class MainOutPut {
	
	private static String temp[][];
	private static double[] scores;//���������������Ȩƽ����
	private static float AvScore;
	private static float Gpa;

	//��html����������th��td�м��Ԫ�ش���temp��ά������
	public static void Get(){
		try{
			File input = new File("guo_grade.html");
			Document doc = Jsoup.parse(input, "gb2312");
			Elements table = doc.select("table");
		//��ȡHTML���ݣ���ѡȡtable�е�����
            int i=0;
            for(Element x:table){
            	Elements tr=x.select("tr");
            	temp=new String[tr.size()][];
            	for(Element xx:tr){
            		Elements td=null;
            		if(i==0){
            			td=xx.select("th");
            		}else{
            			td=xx.select("td");
            		}
            		temp[i]=new String[td.size()];
            		int j=0;
            		for(Element xxx:td){
            			temp[i][j]=xxx.text();
            			j++;
            		}i++;
            	}//ʵ���˴洢����
            	
            }
      
		
     }catch (IOException x) {
		// TODO Auto-generated catch block
		x.printStackTrace();
		}
	}
	
	//������temp�������еĳɼ���������
	public static void Sort(int Sortions){
		switch(Sortions){
		case 1:
			for(int m=temp.length-1;m>0;m--){
				for(int n=m;n>1;n--){
					float former=0;
					float later=0;
					if(!temp[n][9].equals("")){
						later=Float.parseFloat(temp[n][9]);
					}
					if(!temp[n-1][9].equals("")){
						former=Float.parseFloat(temp[n-1][9]);
					}
					if(later>former){
						for(int k = 0; k < temp[n].length;k++){
							String data = temp[n][k];
							temp[n][k] = temp[n-1][k];
							temp[n-1][k] = data;
					}
				}
			}
		
		}break;
		case 2:
			for(int m=1;m<temp.length;m++){
				for(int n = temp.length - 2; n > m-1; n--){
					float former=0;
					float later=0;
					if(!temp[n][9].equals("")){
						later=Float.parseFloat(temp[n][9]);
					}
					if(!temp[n+1][9].equals("")){
						former=Float.parseFloat(temp[n+1][9]);
					}
					if(former>later){
						for(int k = 0; k < temp[n].length;k++){
							String data = temp[n][k];
							temp[n][k] = temp[n+1][k];
							temp[n+1][k] = data;
					}
				}
				}
			}break;
		default:
			break;}
	}
	//ʵ��ƽ�������ļ����Gpa�ļ���
	public static void calc(){
    float totalCredit = 0;
	float sum = 0;
	float sum2 = 0;
	for(int i = 1;i<temp.length;i++){
		if(temp[i][9].equals("")){
			continue;
		}
		sum += Float.parseFloat(temp[i][9]) * Float.parseFloat(temp[i][3]);
		totalCredit += Float.parseFloat(temp[i][3]);
	}
	//System.out.println(totalCredit);
	if(totalCredit != 0){
		AvScore = sum / totalCredit;
	}
	
	
	for(int i = 1;i<temp.length;i++){
		if(temp[i][9].equals("")){
			continue;
		}
		float tempGrade = Float.parseFloat(temp[i][9]);
		float tempScore;
		if(tempGrade >= 90){
			tempScore = 4.0f;
		}else if(tempGrade >= 85){
			tempScore = 3.7f;
		}else if(tempGrade >= 82){
			tempScore = 3.3f;
		}else if(tempGrade >= 78){
			tempScore = 3.0f;
		}else if(tempGrade >=75){
			tempScore = 2.7f;
		}else if(tempGrade >= 72){
			tempScore = 2.3f;
		}else if(tempGrade >=68){
			tempScore = 2.0f;
		}else if(tempGrade >=64){
			tempScore = 1.5f;
		}else if(tempGrade >= 60){
			tempScore = 1.0f;
		}else{
			tempScore = 0f;
		}
		sum2 += tempScore * Float.parseFloat(temp[i][3]);
					
	}
	
	if(totalCredit != 0){
		Gpa = sum2/totalCredit;
	}	
	}
	//��temp�е����ݺ������Gpa�Լ�AvScore���뵽������
	public static void Write(){
	 try {
		WritableWorkbook gradeXls = Workbook.createWorkbook(new File("./Guo_grade.xls"));
		WritableSheet gradeSheet = gradeXls.createSheet("grade", 0);
		  for (int i = 0;i<temp.length;i++){
              int z = 0;
              for (int j=0;j<temp[i].length;j++){
                  if (temp[i][j]=="0"){
                      temp[i][j]="";
                  }
                  String tdText = temp[i][j];
                  Label label = new Label(z,i,tdText);
                  gradeSheet.addCell(label);
                  z++;
              }
          }
		  Label labelaveScore=new Label(10,1,"ƽ������");
		  Label labelaveGpa= new Label(10,2,"GPA��ֵ");
		  Label labelAveScore = new Label(11,1,AvScore+"");
          Label labelGpa = new Label(11, 2, Gpa+"");
          gradeSheet.addCell(labelaveScore);
          gradeSheet.addCell(labelaveGpa);
          gradeSheet.addCell(labelAveScore);
          gradeSheet.addCell(labelGpa);
          gradeXls.write();
          gradeXls.close();
	} catch (IOException e) {
		// TODO �Զ����ɵ� catch ��
		e.printStackTrace();
	} catch (RowsExceededException e) {
		// TODO �Զ����ɵ� catch ��
		e.printStackTrace();
	} catch (WriteException e) {
		// TODO �Զ����ɵ� catch ��
		e.printStackTrace();
	}
	
	}
	//ִ����������������������˳���������
	 public static void main(String[] arg){
		 Get();
		 Sort(1);
		 calc();
		 Write();
		 
		 
	 }
}
	