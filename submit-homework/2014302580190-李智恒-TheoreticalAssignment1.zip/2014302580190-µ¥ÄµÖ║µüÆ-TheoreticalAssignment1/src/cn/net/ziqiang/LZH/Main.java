package cn.net.ziqiang.LZH;

import java.io.File;

public class Main {

    public static void main(String[] args) {
        File txtFile = new File("./Resource/ScoreTable.txt");
        File excelFile = new File("./Resource/ScoreExcel.xls");

        //实现了txt读写和excel读写，用重写抽象方法的思想进行动态绑定。

        MainOutPut txtMainOutPut = new TXTMainOutPut();
        txtMainOutPut.processScoreTable(txtFile);

        MainOutPut excelMainOutPut = new ExcelMainOutput();
        excelMainOutPut.processScoreTable(excelFile);
    }
}
