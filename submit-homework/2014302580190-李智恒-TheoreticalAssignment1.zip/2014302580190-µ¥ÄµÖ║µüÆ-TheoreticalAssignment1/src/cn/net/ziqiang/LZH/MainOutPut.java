package cn.net.ziqiang.LZH;

import java.io.File;


/**
 * Created by Hubert on 15/10/6.
 */
public abstract class MainOutPut {

    /**
     * 读取txt和生成txt方法
     * @param input
     */
    public abstract void processScoreTable(File input);

}
