package cn.net.ziqiang.LZH;

import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.Cell;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;

/**
 * Created by Hubert on 15/10/7.
 */
public class ExcelMainOutput extends MainOutPut {
    @Override
    public void processScoreTable(File input) {

        ArrayList<Course> courseArrayList = new ArrayList<Course>();

        //读取Excel
        try {
            String path = input.getAbsolutePath();
            InputStream is = new FileInputStream(path);
            HSSFWorkbook workbook = new HSSFWorkbook(is);

            Course course = null;


            HSSFSheet sheet = workbook.getSheetAt(0);

            if (sheet == null) {
                return;
            }

            for (int rowNum = 1; rowNum <= sheet.getLastRowNum() ; rowNum++) {
                HSSFRow row = sheet.getRow(rowNum);
                if (row != null) {
                    course = new Course();

                    HSSFCell number = row.getCell(0);
                    HSSFCell name = row.getCell(1);
                    HSSFCell courseType = row.getCell(2);
                    HSSFCell credit = row.getCell(3);
                    HSSFCell teacher = row.getCell(4);
                    HSSFCell school = row.getCell(5);
                    HSSFCell studyType = row.getCell(6);
                    HSSFCell schoolYear = row.getCell(7);
                    HSSFCell semester = row.getCell(8);
                    HSSFCell score = row.getCell(9);

                    number.setCellType(Cell.CELL_TYPE_STRING);
                    schoolYear.setCellType(Cell.CELL_TYPE_STRING);

                    course.setNumber(number.getStringCellValue());
                    course.setName(name.getStringCellValue());
                    course.setCourseType(courseType.getStringCellValue());
                    course.setCredit(credit.getNumericCellValue());
                    course.setTeacher(teacher.getStringCellValue());
                    course.setSchool(school.getStringCellValue());
                    course.setStudyType(studyType.getStringCellValue());
                    course.setSchoolYear(schoolYear.getStringCellValue());
                    course.setSemester(semester.getStringCellValue());
                    course.setScore(score.getNumericCellValue());

                    course.setGpa(course.calculateGPA(course.getScore()));

                    courseArrayList.add(course);

                }
            }

            System.out.println("excel读取成功");



        }catch (FileNotFoundException e) {
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }

        Collections.sort(courseArrayList, Course.CourseScoreComparator);
        System.out.println("excel排序成功");

        //写入
        try {
            double scoreWeightSum = 0;
            double GPAWeightSum = 0;
            double creditSum = 0;


            HSSFWorkbook wbToWrite = new HSSFWorkbook();
            HSSFSheet sheet = wbToWrite.createSheet();

            HSSFRow row = null;
            int i = 0;
            for (Course course: courseArrayList) {
                row = sheet.createRow(i);


                HSSFCell number = row.createCell(0, Cell.CELL_TYPE_STRING);
                HSSFCell name = row.createCell(1, Cell.CELL_TYPE_STRING);
                HSSFCell courseType = row.createCell(2, Cell.CELL_TYPE_STRING);
                HSSFCell credit = row.createCell(3, Cell.CELL_TYPE_NUMERIC);
                HSSFCell teacher = row.createCell(4, Cell.CELL_TYPE_STRING);
                HSSFCell school = row.createCell(5, Cell.CELL_TYPE_STRING);
                HSSFCell studyType = row.createCell(6, Cell.CELL_TYPE_STRING);
                HSSFCell schoolYear = row.createCell(7, Cell.CELL_TYPE_STRING);
                HSSFCell semester = row.createCell(8, Cell.CELL_TYPE_STRING);
                HSSFCell score = row.createCell(9, Cell.CELL_TYPE_NUMERIC);
                HSSFCell gpa = row.createCell(10, Cell.CELL_TYPE_NUMERIC);

                number.setCellValue(course.getNumber());
                name.setCellValue(course.getName());
                courseType.setCellValue(course.getCourseType());
                credit.setCellValue(course.getCredit());
                teacher.setCellValue(course.getTeacher());
                school.setCellValue(course.getSchool());
                studyType.setCellValue(course.getStudyType());
                schoolYear.setCellValue(course.getSchoolYear());
                semester.setCellValue(course.getSemester());
                score.setCellValue(course.getScore());
                gpa.setCellValue(course.getGpa());

                scoreWeightSum += (course.getScore() * course.getCredit());
                GPAWeightSum += (course.getGpa() * course.getCredit());
                creditSum += course.getCredit();

                i++;
            }

            double averageScore = scoreWeightSum / creditSum;
            double averageGPA = GPAWeightSum / creditSum;

            row = sheet.createRow(i++);
            HSSFCell averageScoreTitleCell = row.createCell(0, Cell.CELL_TYPE_STRING);
            HSSFCell averageScoreCell = row.createCell(1, Cell.CELL_TYPE_NUMERIC);
            row = sheet.createRow(i++);
            HSSFCell avarageGPATitleCell = row.createCell(0, Cell.CELL_TYPE_STRING);
            HSSFCell averageGPACell = row.createCell(1, Cell.CELL_TYPE_NUMERIC);

            averageScoreTitleCell.setCellValue("加权平均分：");
            averageScoreCell.setCellValue(averageScore);
            avarageGPATitleCell.setCellValue("加权GPA：");
            averageGPACell.setCellValue(averageGPA);



            FileOutputStream os = new FileOutputStream("./Output/ExcelOutput.xls");
            wbToWrite.write(os);

        }catch (FileNotFoundException e) {
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("excel写入成功，请到 ./Output/ExcelOutput.xls 中查看");
        
    }
}
