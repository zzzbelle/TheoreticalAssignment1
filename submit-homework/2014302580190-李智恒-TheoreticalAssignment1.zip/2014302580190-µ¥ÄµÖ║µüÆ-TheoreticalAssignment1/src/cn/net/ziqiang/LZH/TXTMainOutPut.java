package cn.net.ziqiang.LZH;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;

/**
 * Created by Hubert on 15/10/7.
 */
public class TXTMainOutPut extends MainOutPut {
    @Override
    public void processScoreTable(File input) {
        ArrayList<Course> courseList = new ArrayList();
        //使用Java 7
        try {
            BufferedReader br = new BufferedReader(new FileReader(input));
            String line = "";
            while ((line = br.readLine()) != null) {
                Course temp = new Course(line);
                courseList.add(temp);
            }
            br.close();
        }catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println("File Not Found!");
        }catch (IOException e) {
            e.printStackTrace();
            System.out.println("IOException Occurred!");
        }

        System.out.println("txt读取成功！");

        Collections.sort(courseList, Course.CourseScoreComparator);
        System.out.println("txt排序成功！");

        double scoreWeightSum = 0;
        double GPAWeightSum = 0;
        double creditSum = 0;
        for (Course course: courseList) {
            scoreWeightSum += (course.getScore() * course.getCredit());
            GPAWeightSum += (course.getGpa() * course.getCredit());
            creditSum += course.getCredit();
        }

        double averageScore = scoreWeightSum / creditSum;
        double averageGPA = GPAWeightSum / creditSum;


        //输出
        File outputFile = new File("./Output/SortedScoreTable.txt");

        try {
            outputFile.createNewFile();
            BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));

            writer.write("课头号\t课程名称\t课程类型\t学分\t教师\t授课学院\t学习类型\t学年\t学期\t成绩\tGPA\n");
            writer.flush();

            for (Course course: courseList) {
                String courseDescription = course.toString();
                writer.write(courseDescription + "\n");
                writer.flush();
            }

            //写入平均成绩
            writer.write("平均成绩: " + Double.toString(averageScore));
            writer.flush();
            writer.newLine();
            //写入GPA
            writer.write("GPA: " + Double.toString(averageGPA));
            writer.flush();
            writer.close();
        }catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("txt输出成功！请到 ./Output/SortedScoreTable.txt 中查看");
    }
}
