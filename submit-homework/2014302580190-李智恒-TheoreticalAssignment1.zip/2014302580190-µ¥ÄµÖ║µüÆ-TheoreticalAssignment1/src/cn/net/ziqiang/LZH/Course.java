package cn.net.ziqiang.LZH;

import java.util.Comparator;

/**
 * Created by Hubert on 15/10/4.
 */
public class Course implements Comparable<Course> {

    private String number;
    private String name;
    private String courseType;
    private double credit;
    private String teacher;
    private String school;
    private String studyType;
    private String schoolYear;
    private String semester;
    private double score;
    private double gpa;

    /**
     * 根据txt文件中的一行进行解析
     * @param txtLine
     */
    public Course(String txtLine) {

        String[] strArr = txtLine.split("\\t");
        this.number = strArr[0];
        this.name = strArr[1];
        this.courseType = strArr[2];
        try {
            this.credit = Double.parseDouble(strArr[3]);
        } catch (NumberFormatException e) {
            this.credit = 0;
        }
        this.teacher = strArr[4];
        this.school = strArr[5];
        this.studyType = strArr[6];
        this.schoolYear = strArr[7];
        this.semester = strArr[8];
        try {
            this.score = Double.parseDouble(strArr[9]);
        } catch (NumberFormatException e) {
            this.score = 0;
        }
        this.gpa = calculateGPA(score);
    }

    /**
     * 无参数构造
     */
    public Course(){}

    public double getScore() {
        return this.score;
    }
    public double getCredit() {
        return this.credit;
    }
    public double getGpa() {
        return gpa;
    }

    public String getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public String getCourseType() {
        return courseType;
    }

    public String getSchool() {
        return school;
    }

    public String getSchoolYear() {
        return schoolYear;
    }

    public String getSemester() {
        return semester;
    }

    public String getStudyType() {
        return studyType;
    }

    public String getTeacher() {
        return teacher;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCourseType(String courseType) {
        this.courseType = courseType;
    }

    public void setCredit(double credit) {
        this.credit = credit;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public void setStudyType(String studyType) {
        this.studyType = studyType;
    }

    public void setSchoolYear(String schoolYear) {
        this.schoolYear = schoolYear;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

    /**
     * 实现Comparable接口，用来比较两门课的成绩大小
     * @param course
     * @return
     */
    public int compareTo(Course course) {
        int difference = (int)(this.score - course.score);
        return difference;
    }

    public static Comparator<Course> CourseScoreComparator = new Comparator<Course>() {
        @Override
        public int compare(Course o1, Course o2) {
            //降序，所以是o2比o1
            return o2.compareTo(o1);
        }
    };

    @Override
    public String toString() {
        return this.number + "\t" + this.name + "\t" + this.courseType + "\t" + Double.toString(this.credit)
                + "\t" + this.teacher + "\t" + this.school + "\t" + this.studyType + "\t" + this.schoolYear + " " +
                 this.semester + "\t" + Double.toString(this.score) + "\t" +Double.toString(this.gpa);
    }

    /*计算GPA方法*/
    public double calculateGPA(double grade) {
        if (grade>=90) {
            return 4.0;
        } else if (grade>=85) {
            return 3.7;
        } else if (grade>=82) {
            return 3.3;
        } else if (grade>=78) {
            return 3.0;
        } else if (grade>=75) {
            return 2.7;
        } else if (grade>=72) {
            return 2.3;
        } else if (grade>=68) {
            return 2.0;
        } else if (grade>=64) {
            return 1.5;
        } else if (grade>=60) {
            return 1.0;
        }
        return 0;
    }
}
