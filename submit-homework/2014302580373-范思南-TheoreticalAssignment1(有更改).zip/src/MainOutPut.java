import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

//import org.apache.poi.hssf.eventusermodel.HSSFRequest;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
//import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;


public class MainOutPut {

	public static void main(String[] args) throws IOException {
		// TODO �Զ����ɵķ������
//		File myGrade = new File("D:/Java/workspace/OOP-JAVA-CLASSTEST01/myGrade.xls");
		File myGrade = new File("./myGrade.xls");
		processScoreTable(myGrade);
		System.out.println("ok");
	}

	public static void processScoreTable(File input) throws IOException {
		// ��ȡԭ�����ļ�
		FileInputStream in = new FileInputStream(input);
		HSSFWorkbook oldWb = new HSSFWorkbook(in);
		HSSFSheet oldSheet = oldWb.getSheetAt(0);

		
		// д���±���
		HSSFWorkbook newWb = new HSSFWorkbook();
		HSSFSheet newSheet = newWb.createSheet();
				
		//���ö���
		HSSFCellStyle cellStyle = newWb.createCellStyle();
		cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		
		//��������к͵�Ԫ�񣬲������иߺ͵�Ԫ����ʽ
		for(int i = 0; i<39; i++)
		{
			newSheet.createRow(i);
			newSheet.getRow(i).setHeight((short)350);
			for(int j = 0; j<10; j++)
			{
				newSheet.getRow(i).createCell(j).setCellStyle(cellStyle);
			}
		}
		// Ϊ��Ԫ���趨�п�
			newSheet.setColumnWidth(0, 4000);
			newSheet.setColumnWidth(1, 10000);
			newSheet.setColumnWidth(2, 3000);
			newSheet.setColumnWidth(4, 3000);
			newSheet.setColumnWidth(5, 5000);
			newSheet.setColumnWidth(6, 2000);
			newSheet.setColumnWidth(7, 2000);
			newSheet.setColumnWidth(8, 1500);
			newSheet.setColumnWidth(9, 1500);	
			
		// ������ѧ��
		double totalCredits = 0;
		for (int j = 0; j < 22; j++) {
			totalCredits += oldSheet.getRow(j).getCell(3).getNumericCellValue();
		}
		
		// �����Ȩƽ����
		double averagePoint = 0;
		for (int j = 0; j < 22; j++) {
			averagePoint += oldSheet.getRow(j).getCell(3).getNumericCellValue()
					* oldSheet.getRow(j).getCell(9).getNumericCellValue();
		}
		averagePoint /= totalCredits;
		
		// ���㵥�Ƽ���
		double gradePoint[] = new double[22];
		for(int j = 0; j<22; j++)
		{
			if(oldSheet.getRow(j).getCell(9).getNumericCellValue() >= 90)
			{
				gradePoint[j] = 4.0;
			}
			else if(oldSheet.getRow(j).getCell(9).getNumericCellValue() >= 85
					&& oldSheet.getRow(j).getCell(9).getNumericCellValue() <= 89)
			{
				gradePoint[j] = 3.7;
			}
			else if(oldSheet.getRow(j).getCell(9).getNumericCellValue() >= 82
					&& oldSheet.getRow(j).getCell(9).getNumericCellValue() <= 84)
			{
				gradePoint[j] = 3.3;
			}
			else if(oldSheet.getRow(j).getCell(9).getNumericCellValue() >= 78
					&& oldSheet.getRow(j).getCell(9).getNumericCellValue() <= 81)
			{
				gradePoint[j] = 3.0;
			}
			else if(oldSheet.getRow(j).getCell(9).getNumericCellValue() >= 75
					&& oldSheet.getRow(j).getCell(9).getNumericCellValue() <= 77)
			{
				gradePoint[j] = 2.7;
			}
			else if(oldSheet.getRow(j).getCell(9).getNumericCellValue() >= 72
					&& oldSheet.getRow(j).getCell(9).getNumericCellValue() <= 74)
			{
				gradePoint[j] = 2.3;
			}
			else if(oldSheet.getRow(j).getCell(9).getNumericCellValue() >= 68
					&& oldSheet.getRow(j).getCell(9).getNumericCellValue() <= 71)
			{
				gradePoint[j] = 2.0;
			}
			else if(oldSheet.getRow(j).getCell(9).getNumericCellValue() >= 64
					&& oldSheet.getRow(j).getCell(9).getNumericCellValue() <= 67)
			{
				gradePoint[j] = 1.5;
			}
			else if(oldSheet.getRow(j).getCell(9).getNumericCellValue() >= 60
					&& oldSheet.getRow(j).getCell(9).getNumericCellValue() <= 63)
			{
				gradePoint[j] = 1.0;
			}
			else
			{
				gradePoint[j] = 0.0;
			}
		}
		
		// ����GPA
		double GPA = 0;
		for(int j = 0; j<22; j++)
		{
			GPA += gradePoint[j] * oldSheet.getRow(j).getCell(3).getNumericCellValue(); 
		}
		GPA /= totalCredits;
		
		// �����Ȩƽ����
		newSheet.getRow(37).getCell(0).setCellValue("��Ȩƽ���֣�");
		newSheet.getRow(37).getCell(1).setCellValue(averagePoint);
		
		// ���GPA
		newSheet.getRow(38).getCell(0).setCellValue("GPA��");
		newSheet.getRow(38).getCell(1).setCellValue(GPA);
		
		//���ݷ����������У��ó�ԭ����������Ӧ���±�������
		int order[] = new int[22];
		for(int i = 0; i<22; i++)
		{
			order[i] = 0;
			//ͳ�Ƹ�������ĸ�����ֱ��ȷ���Ӵ�С��λ��
			for(int j = 0; j<22; j++)
			{
				if(oldSheet.getRow(i).getCell(9).getNumericCellValue()
						< oldSheet.getRow(j).getCell(9).getNumericCellValue())
				{
					order[i]++;
				}
			}
			//������ͬ����ʱ��λ��+1�����Ⲣ��
			for(int k = 0; k<i; k++)
			{
				if(oldSheet.getRow(i).getCell(9).getNumericCellValue()
						== oldSheet.getRow(k).getCell(9).getNumericCellValue())
				{
					order[i]++;
				}
			}
		}

		
		//����������˳�������������
		for(int i = 0; i<37; i++)
		{
			if(i<22)
			{
				for(int j = 0; j<10; j++)
				{
					changeValue(oldSheet.getRow(i).getCell(j), newSheet.getRow(order[i]).getCell(j));
				}
			}
			if(i>=22 && i<37)
			{
				for(int j = 0; j<9; j++)
				{
					changeValue(oldSheet.getRow(i).getCell(j), newSheet.getRow(i).getCell(j));
				}
			}
		}
	
		// ��������ļ�
//		FileOutputStream out = new FileOutputStream("D:/Java/workspace/OOP-JAVA-CLASSTEST01/myGradeSorting.xls");
		FileOutputStream out = new FileOutputStream("./myGradeSorting.xls");
		newWb.write(out);
		out.close();
		oldWb.close();
		newWb.close();

	}

	
	// ��Ԫ��ֵ
	public static void changeValue(HSSFCell oldCell, HSSFCell newCell) {
		if (oldCell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {
			newCell.setCellValue(oldCell.getNumericCellValue());
		} else if (oldCell.getCellType() == HSSFCell.CELL_TYPE_STRING) {
			newCell.setCellValue(oldCell.getStringCellValue());
		} else {
			System.out.println("error");
		}
	}
}
