package test2;
 
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DecimalFormat;

import jxl.Sheet;   
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
  
public class FileOperate {
	void operate()
	{
		

		
		
		
//�����׼������	
		Workbook rwb = null;
		//����������
	    InputStream stream = null;
		try {
			stream = new FileInputStream("test.xls");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    //��ȡExcel�ļ�����
	    try {
			rwb = Workbook.getWorkbook(stream);
		} catch (BiffException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    //��ȡ�ļ���ָ��������( Ĭ�ϵĵ�һ��)
	    Sheet sheet = rwb.getSheet(0);  
	    //��������   
        String [][]str=new String [26][10];
        for(int i=0;i<26;i++){
		    for(int j=0;j<10;j++){
					str[i][j]=sheet.getCell(j,i).getContents();
				}
			}
        rwb.close();

        

        
        
//�õģ���ʽ��ʼ�ˡ�
        //�Գɼ����дӸߵ�������
	    for(int i=1;i<26;i++){
		    for(int j=1;j<26-i;j++){
			    if(Integer.valueOf(str[j][9])<Integer.valueOf(str[j+1][9])){
				   String []temp=str[j];
				   str[j]=str[j+1];
				   str[j+1]=temp;
				 }
			   }
			}
      
	
	    double average=0.0;
        double gpa=0.0;
		double a=0.0;//�����洢������ѧ�ֳ˻��ĺ�
		double b=0.0;//�����洢������ѧ�ֳ˻��ĺ�
		double c=0.0;//�����洢ѧ�ֺ�
		
		//����average��gpa
		for(int i=1;i<26;i++)
		{
			a=a+Double.valueOf(str[i][3])*Double.valueOf(str[i][9]);
			double grade=0.0;	//grade�����洢����
			
			//ȫ�����ε����
			if(Double.valueOf(str[i][9])>=90 && Double.valueOf(str[i][9])<=100) grade=4.0;
			if(Double.valueOf(str[i][9])>=85 && Double.valueOf(str[i][9])<=89) grade=3.7;
			if(Double.valueOf(str[i][9])>=82 && Double.valueOf(str[i][9])<=84) grade=3.3;
			if(Double.valueOf(str[i][9])>=78 && Double.valueOf(str[i][9])<=81) grade=3.0;
			if(Double.valueOf(str[i][9])>=75 && Double.valueOf(str[i][9])<=77) grade=2.7;
			if(Double.valueOf(str[i][9])>=72 && Double.valueOf(str[i][9])<=74) grade=2.3;
			if(Double.valueOf(str[i][9])>=68 && Double.valueOf(str[i][9])<=71) grade=2.0;
			if(Double.valueOf(str[i][9])>=64 && Double.valueOf(str[i][9])<=67) grade=1.5;
			if(Double.valueOf(str[i][9])>=60 && Double.valueOf(str[i][9])<=63) grade=1.0;
			if(Double.valueOf(str[i][9])>=0 && Double.valueOf(str[i][9])<=59) grade=0.0;
			b=b+grade*Double.valueOf(str[i][3]);
			c=c+Double.valueOf(str[i][3]);
 		}
		
		average=a/c;
		gpa=b/c;
		
          

		

		
//д���׼������
        // �����excel��·��   
        String filePath = "newtest.xls";   
         // ����Excel������   
        WritableWorkbook wwb = null;   
         // �½���һ��excel�ļ�,����d��������newtest.xls   
        OutputStream os = null;
		try {
			os = new FileOutputStream(filePath);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}   
        try {
			wwb=Workbook.createWorkbook(os);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}    
        // ���ӵ�һ�������������õ�һ��Sheet������   
        WritableSheet sheet1 = wwb.createSheet("new", 0);
        

        
        
        
 //�õģ���ʽ��ʼ��
		for(int i=0;i<26;i++)
		{
			for(int j=0;j<10;j++)
			{
				try {
					sheet1.addCell(new Label(j,i,str[i][j]));
				} catch (RowsExceededException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (WriteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 }
		}
		DecimalFormat df=new DecimalFormat("#.00");	//��Ȩƽ���ֺ�GPA������λС��
		try {
			sheet1.addCell(new Label(0,26,"��Ȩƽ����"));
		} catch (RowsExceededException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (WriteException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			sheet1.addCell(new Label(1,26,df.format(average)+""));
		} catch (RowsExceededException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (WriteException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			sheet1.addCell(new Label(0,27,"GPA"));
		} catch (RowsExceededException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (WriteException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			sheet1.addCell(new Label(1,27,df.format(gpa)+""));
		} catch (RowsExceededException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (WriteException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			wwb.write();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			wwb.close();
		} catch (WriteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
