package test2;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import javax.swing.JTextPane;
import java.awt.Font;

public class MainPage extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			MainPage dialog = new MainPage();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public MainPage() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JButton btnNewButton = new JButton("\u5F00\u59CB\u6392\u5E8F\u4E0E\u8BA1\u7B97GPA");
			btnNewButton.setForeground(Color.BLUE);
			btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
				public void mouseClicked(MouseEvent arg0) {
				FileOperate one= new FileOperate();
				one.operate();
				PageOne dialog = new PageOne();
				dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				dialog.setVisible(true);
				}
			});
			btnNewButton.setBounds(86, 113, 251, 59);
			contentPanel.add(btnNewButton);
		}
		{
			JTextPane textPane = new JTextPane();
			textPane.setFont(new Font("����", Font.PLAIN, 20));
			textPane.setForeground(Color.BLUE);
			textPane.setText("\u7406\u8BBA\u8BFE\u7B2C\u4E00\u6B21\u4F5C\u4E1A");
			textPane.setBounds(123, 47, 166, 36);
			contentPanel.add(textPane);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
		}
	}

}
