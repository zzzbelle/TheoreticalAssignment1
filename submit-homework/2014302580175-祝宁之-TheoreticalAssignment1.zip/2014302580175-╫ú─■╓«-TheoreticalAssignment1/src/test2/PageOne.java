package test2;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextPane;
import java.awt.Font;
import java.awt.Color;

public class PageOne extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */

	/**
	 * Create the dialog.
	 */
	public PageOne() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JTextPane txtpnnewtestxls = new JTextPane();
		txtpnnewtestxls.setForeground(Color.BLUE);
		txtpnnewtestxls.setFont(new Font("����", Font.PLAIN, 26));
		txtpnnewtestxls.setText("\u5DF2\u7ECF\u751F\u6210\u4E86\u65B0\u7684newtest.xls\uFF0C\u8BF7\u5728\u76EE\u5F55\u4E2D\u70B9\u51FB\u67E5\u770B\u3002");
		txtpnnewtestxls.setBounds(62, 37, 321, 173);
		contentPanel.add(txtpnnewtestxls);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
		}
	}
}
