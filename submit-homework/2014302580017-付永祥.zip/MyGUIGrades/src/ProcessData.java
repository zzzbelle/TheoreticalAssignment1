import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;


public class ProcessData {
	private static String [] temp;
	private static String [] heads = new String[12];//�����ͷ
	private static double zero = 0.000001;
	private static double[] fen;
	
	public static String[] getHeads(){
		heads[10] = "��Ȩƽ����";
		heads[11] = "GPA";
		return heads;
	}
	
	public static ArrayList<Course> Input(File sou){
		try {
			Document doc = Jsoup.parse(sou,"gb2312");
			
			Element mytable = doc.getElementsByTag("table").first();
			Elements rows = mytable.getElementsByTag("tr");
			
			ArrayList<Course> courses = new ArrayList<Course>();//�ɼ�����
			
			for(Element e:rows){
				temp = new String[12];//���³�ʼ��
				
				Elements tableHead = e.getElementsByTag("th");//�õ���ͷԪ����
				Elements cols = e.getElementsByTag("td");//�õ�����Ԫ����
				
				int i = 0;
				if(!tableHead.isEmpty()) {
					//continue;//���Ǳ�ͷ��������
					for(Element el:tableHead)
						heads[i++] = el.text().trim();
				}
				
				else {
					for(Element el:cols) 
						temp[i++] = el.text().trim();
					add(courses);
				}
				

			}
			
			return courses;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
		
	}
	
	private static void add(ArrayList<Course> courses){
		if(temp[9].isEmpty()) temp[9] = "0";//���ǻ�û�гɼ��Ŀ�Ŀ����0��
		
		Course c = new Course(Long.parseLong(temp[0]), temp[1], temp[2], 
				Double.parseDouble(temp[3]), temp[4], temp[5], temp[6],
				Integer.parseInt(temp[7]), temp[8], Double.parseDouble(temp[9]));
		courses.add(c);
	}
	
	public static void sort(ArrayList<Course> courses){
		SortByScore sbs = new SortByScore();
		Collections.sort( courses,sbs);
	}
	
	public static boolean Output(ArrayList<Course> courses,File destination){
		WritableWorkbook workbook;
		try {
			workbook = Workbook.createWorkbook(destination);
			//�����µ�һҳ
	        WritableSheet sheet = workbook.createSheet("First Sheet",0);
	        
	        //�����ͷ
	        getHeads();
	        int i = 0;
	        for(int j = 0;j<10;j++)
	        {
	        	sheet.addCell(new Label(j,i,heads[j]));
	        }
	        
	        //�ж��Ƿ����˼��㰴ť,��δ�����������
	        if(fen != null){
	        	//��ͷ
	        	sheet.addCell(new Label(10,i,heads[10]));
	        	sheet.addCell(new Label(11,i,heads[11]));
	        	
	        	sheet.addCell(new Label(10,1,fen[0]+""));
	        	sheet.addCell(new Label(11,1,fen[1]+""));
	        }
	        	
	        
	        i = 1;
	        for(Course c:courses){
	        	for(int j=0;j<10;j++){
	        		sheet.addCell(new Label(j,i,getData(c,j)));
	        	}
	        	i++;
	        }
	        
	        workbook.write();
	        workbook.close();
	        
	        
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
        
		return true;
	}
	
	public static String getData(Course c,int j){

		String s;
		switch(j){
		case 0:
			s = c.getId() +"";
			break;
		case 1:
			s = c.getName() +"";
			break;
		case 2:
			s = c.getCourseType() +"";
			break;
		case 3:
			s = c.getCredit() +"";
			break;	
		case 4:
			s = c.getTeacher() +"";
			break;	
		case 5:
			s = c.getSchool() +"";
			break;	
		case 6:
			s = c.getStudyType() +"";
			break;	
		case 7:
			s = c.getXuenian() +"";
			break;	
		case 8:
			s = c.getXueqi() +"";
			break;	
		case 9:
			s = c.getScore() +"";
			break;	
		default:
			s = null;
			break;
		}
		return s;
	}
	
	public static double[] Calc(ArrayList<Course> courses){
		double WeightedAverage = 0.0 , GPA = 0.0, credits = 0.0;
		
		
		
		for(Course c:courses){
			if(c.getScore() <= zero && c.getScore() >= -zero)
				continue;
			credits += c.getCredit();//��ѧ��
			WeightedAverage += c.getCredit() * c.getScore();
			GPA += c.getCredit() * jidian(c);
		}
		WeightedAverage  /= credits;
		GPA /= credits;
		fen = new double[]{WeightedAverage,GPA};
		return fen;
	}
	
	
	private static double jidian(Course c){
		double score = c.getScore();
		if(score >= 90 - zero) return 4.0;
		else if(score >= 85 - zero) return 3.7;
		else if(score >= 82 - zero) return 3.3;
		else if(score >= 78 - zero) return 3.0;
		else if(score >= 75 - zero) return 2.7;
		else if(score >= 72 - zero) return 2.3;
		else if(score >= 68 - zero) return 2.0;
		else if(score >= 64 - zero) return 1.5;
		else if(score >= 60 - zero) return 1.0;
		else return 0;
	}
}
