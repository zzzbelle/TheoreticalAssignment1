
public class Course {
	private long id;
	private String name;
	private String courseType;
	private double credit;//ѧ��
	private String teacher;
	private String school;
	private String studyType;
	private int xuenian;//�಻��ȥ��
	private String xueqi;
	private double score;
	
	
	public Course(long id, String name, String courseType, double credit, String teacher, String school, String studyType,
			int xuenian, String xueqi, double score) {
		super();
		this.id = id;
		this.name = name;
		this.courseType = courseType;
		this.credit = credit;
		this.teacher = teacher;
		this.school = school;
		this.studyType = studyType;
		this.xuenian = xuenian;
		this.xueqi = xueqi;
		this.score = score;
	}


	@Override
	public String toString() {
		return "Course [id=" + id + ", name=" + name + ", courseType=" + courseType + ", credit=" + credit
				+ ", teacher=" + teacher + ", school=" + school + ", studyType=" + studyType + ", xuenian=" + xuenian
				+ ", xueqi=" + xueqi + ", Score=" + score + "]";
	}
	
	public String forTest() {
		return "name="+name+"score"+score;
	}


	public double getScore() {
		return score;
	}


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getCourseType() {
		return courseType;
	}


	public void setCourseType(String courseType) {
		this.courseType = courseType;
	}


	public double getCredit() {
		return credit;
	}


	public void setCredit(double credit) {
		this.credit = credit;
	}


	public String getTeacher() {
		return teacher;
	}


	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}


	public String getSchool() {
		return school;
	}


	public void setSchool(String school) {
		this.school = school;
	}


	public String getStudyType() {
		return studyType;
	}


	public void setStudyType(String studyType) {
		this.studyType = studyType;
	}


	public int getXuenian() {
		return xuenian;
	}


	public void setXuenian(int xuenian) {
		this.xuenian = xuenian;
	}


	public String getXueqi() {
		return xueqi;
	}


	public void setXueqi(String xueqi) {
		this.xueqi = xueqi;
	}


	public void setScore(double score) {
		score = score;
	}
	
	
}
