package java1; 
import java.io.FileInputStream;
import java.io.File;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
public class ReadDoc {
    private POIFSFileSystem fs;
    private HSSFWorkbook wb;
    private HSSFSheet sheet;
    private HSSFRow row;
    public Map<Integer, String> readExcelContent(InputStream is) {
        Map<Integer, String> content = new HashMap<Integer, String>();
        String str = "";
        try {
            fs = new POIFSFileSystem(is);
            wb = new HSSFWorkbook(fs);
        } catch (IOException e) {
            e.printStackTrace();
        }
        sheet = wb.getSheetAt(0);
        row = sheet.getRow(0);
        // �õ�������
       int rowNum=sheet.getLastRowNum();
        row = sheet.getRow(0);
        int colNum = row.getPhysicalNumberOfCells();
        // ��������Ӧ�ôӵڶ��п�ʼ,��һ��Ϊ��ͷ�ı���
        for (int i = 1; i <= rowNum; i++) {
            row = sheet.getRow(i);
            int j = 0;
            while (j < colNum) {
                // ÿ����Ԫ�������������"-"�ָ���Ժ���Ҫʱ��String���replace()������ԭ����
                str += getCellFormatValue(row.getCell(j)).trim() + "    ";
                j++;
            }
            content.put(i, str);
            str = "";
        }
        return content;
    }
 String getCellFormatValue(HSSFCell cell) {
        String cellvalue = "";
        if (cell != null) {
            // �жϵ�ǰCell��Type
            switch (cell.getCellType()) {
            // �����ǰCell��TypeΪNUMERIC
            case HSSFCell.CELL_TYPE_NUMERIC:
            case HSSFCell.CELL_TYPE_FORMULA: {
                // �жϵ�ǰ��cell�Ƿ�ΪDate
                if (HSSFDateUtil.isCellDateFormatted(cell)) {
                    // �����Date������ת��ΪData��ʽ
                    //����2�������ӵ�data��ʽ�ǲ�����ʱ����ģ�2011-10-12
                    Date date = cell.getDateCellValue();
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    cellvalue = sdf.format(date);
                    
                }
                // ����Ǵ�����
                else {
                    // ȡ�õ�ǰCell����ֵ
                    cellvalue = String.valueOf(cell.getNumericCellValue());
                }
                break;
            }
            // �����ǰCell��TypeΪSTRIN
            case HSSFCell.CELL_TYPE_STRING:
                // ȡ�õ�ǰ��Cell�ַ���
                cellvalue = cell.getRichStringCellValue().getString();
                break;
            // Ĭ�ϵ�Cellֵ
            default:
                cellvalue = " ";
            }
        } else {
            cellvalue = "";
        }
        return cellvalue;

    }
 public double avarage(InputStream is){
     double sum=0;
     double marks=0;
     sheet = wb.getSheetAt(0);
     // �õ�������
     int rowNum = sheet.getLastRowNum();
     row = sheet.getRow(0);
     int m=1;
     // ��������Ӧ�ôӵڶ��п�ʼ,��һ��Ϊ��ͷ�ı���
     for (int i = 1; i <rowNum; i++) {
         row = sheet.getRow(i);
        String grade=getCellFormatValue(row.getCell(9)).trim();
        String mark=getCellFormatValue(row.getCell(3)).trim();
        if(m<=24){
        	 sum+=Double.parseDouble(grade)*Double.parseDouble(mark);
        	 m++;
        	marks+=Double.parseDouble(mark);
         }
         }
	 return sum/marks;
	 
 }
 public double avgGPA(InputStream is){
     double sum=0;
     double marks=0;
     sheet = wb.getSheetAt(0);
     // �õ�������
     int rowNum = sheet.getLastRowNum();
     row = sheet.getRow(0);
     // ��������Ӧ�ôӵڶ��п�ʼ,��һ��Ϊ��ͷ�ı���
     for (int i = 1; i <24; i++) {
         row = sheet.getRow(i);
        String grade=getCellFormatValue(row.getCell(9)).trim();
        double score=Double.parseDouble(grade);
        double gpa=0;
        String mark=getCellFormatValue(row.getCell(3)).trim();
        	if(score>=90&&score<=100)
    		{
    			gpa = 4.0;
    		}
    		if(score>=85&&score<=89)
    		{
    			gpa = 3.7;
    		}
    		if(score>=82&&score<=84)
    		{
    			gpa = 3.3;
    		}
    		if(score>=78&&score<=81)
    		{
    			gpa = 3.0;
    		}
    		if(score>=75&&score<=77)
    		{
    			gpa = 2.7;
    		}
    		if(score>=72&&score<=74)
    		{
    			gpa = 2.3;
    		}
    		if(score>=68&&score<=71)
    		{
    			gpa = 2.0;
    		}
    		if(score>=64&&score<=67)
    		{
    			gpa = 1.5;
    		}
    		if(score>=60&&score<=63)
    		{
    			gpa = 1.0;
    		}
    		if(score<60)
    		{
    			gpa = 0;
    		}
        	 sum+=gpa*Double.parseDouble(mark);
        	marks+=Double.parseDouble(mark);
         }
	 return sum/marks;
	 
 }
 public Map<Integer, String> sort( InputStream is){
	  Map<Integer, String> contentc = new HashMap<Integer, String>();
	  int rowNum = sheet.getLastRowNum();
	  for (int i = 1; i <= rowNum; i++) {
		  int j=1;
		  HSSFRow row1 = sheet.getRow(i);
		  HSSFRow row2=sheet.getRow(j);
		  String str1=" ";
		  String str2=" ";
		  int jj = 0;
		  int colNum = row.getPhysicalNumberOfCells();
          while (jj < colNum) {
              // ÿ����Ԫ�������������"-"�ָ���Ժ���Ҫʱ��String���replace()������ԭ����
              str1 += getCellFormatValue(row1.getCell(jj)).trim() + "    ";
              str2 += getCellFormatValue(row2.getCell(jj)).trim() + "    ";
              jj++;
          }
          String min=getCellFormatValue(row1.getCell(9)).trim();
          int n=i;
          String grade2=getCellFormatValue(row2.getCell(9)).trim(); 
          for(j=i+1;j<contentc.size();j++){
           if(Double.parseDouble(min)>Double.parseDouble(grade2)){
        	   contentc.put(j, str1);
        	   n=j;
        	   
           }
          }
          contentc.put(i, str2);
          }
	 return contentc;
	 
 }
 public void processScoreTable(File input) throws IOException{
	 try {
         InputStream is = new FileInputStream("d:\\Book1.xls");
         ReadDoc excelReader = new ReadDoc();
		 Map<Integer, String> map = excelReader.readExcelContent(is);
        double avg=excelReader.avarage(is);
         double GPA=excelReader.avgGPA(is);
////         HSSFWorkbook wb1= new HSSFWorkbook();
////         HSSFSheet sheet2=wb1.createSheet("score");
////         HSSFRow row=sheet2.createRow(0);
////         HSSFCell cell=row.createCell(0);
        BufferedWriter bw = new BufferedWriter(new FileWriter(input,true));
        for (int i = 1; i <= map.size(); i++) {
           bw.write(map.get(i)+"\r\n");
       }
         bw.write("��Ȩƽ������");
         bw.write(String.valueOf(avg));
         bw.write("������");
         bw.write(String.valueOf(GPA));
         bw.close();
     } catch (FileNotFoundException e) {
         System.out.println("δ�ҵ�ָ��·�����ļ�!");
         e.printStackTrace();
     }
 }
    public static void main(String[] args) throws IOException{
    	File file1 = new File("ScoreList.txt");
    	ReadDoc doc=new ReadDoc();
    	doc.processScoreTable(file1);
    }
}
