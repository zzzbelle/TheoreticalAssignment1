

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class MainOutPut {
	public String[][] data = new String[100][20];
	public int dataNum = 0;
	
	public void processScoreTable(File input){
		BufferedReader reader = null;
		try{
			reader = new BufferedReader(new FileReader(input));
			String str;
			while((str = reader.readLine()) != null){

				data[dataNum] = str.split("\\t+");
				dataNum++;
				
			}
			reader.close();
		} catch (IOException e){
			
		}
		
		sortGrade();
		
		File output = new File("output.txt");
		BufferedWriter writer = null;
		try{
			writer = new BufferedWriter(new FileWriter(output));
			for (int i = 0; i < dataNum; i++)
			{
				String str = "";
				for (int j = 0; j < 10; j++){
					str += data[i][j] + "  ";
				}
				writer.write(str+'\n');
			}
			
			writer.write("加权GPA: "+ String.valueOf(GPA()) + '\n');
			writer.write("加权平均分: "+ String.valueOf(averageGrade())+'\n');
			writer.close();
		} catch (IOException e){
			
		}
		
		
	}
	
	public void sortGrade(){
		for(int i = 1;i < dataNum-1;i++){
			for(int j = i+1;j < dataNum;j++){
				if(Double.valueOf(data[i][9]) < Double.valueOf(data[j][9])){
					String[] a = data[i];
					data[i] = data[j];
					data[j] = a;
				}
			}		
		}
	}
	
	public double averageGrade(){
		double sum = 0;
		double credit = 0;
		for(int i = 1;i < dataNum;i++ ){
			sum = sum + Double.valueOf(data[i][3]) * Double.valueOf(data[i][9]);
			credit = credit + Double.valueOf(data[i][3]);
		}
		return (sum/credit);	
	}
	
	public double getGPA(double score){
		if(score < 60){
			return 0;
		}
		if(score == 60){
			return 1;
		}
		if((score > 60)&&(score < 64 )){
			return 1.3;
		}
		if(score == 64 ){
			return 1.5;
		}
		if((score > 64)&&(score < 68)){
			return 1.7;
		}
		if((score >= 68)&&(score < 72)){
			return 2;
		}
		if((score >= 72)&&(score < 75)){
			return 2.3;
		}
		if((score >= 75)&&(score < 79)){
			return 2.7;
		}
		if((score >= 79)&&(score < 82)){
			return 3;
		}
		if((score >=82)&&(score < 85)){
			return 3.3;
		}
		if((score >= 85)&&(score <90)){
			return 3.7;
		}
		if(score >=90){
			return 4;
		}
		return -1;
	}
	
	public double GPA(){
		double sum = 0;
		double credit = 0;
		for(int i = 1;i < dataNum;i++ ){
			sum = sum + Double.valueOf(data[i][3]) * getGPA(Double.valueOf(data[i][9]));
			credit = credit + Double.valueOf(data[i][3]);
		}
		return (sum/credit);
	}
}


