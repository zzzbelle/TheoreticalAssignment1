

import java.io.File;

public class scores {

	public static void main(String[] args) {

		MainOutPut run = new MainOutPut();
		File input = new File("scores.txt");
		run.processScoreTable(input);
		System.out.print("finish");
	}

}
